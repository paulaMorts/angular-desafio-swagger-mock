exports.models = {
    "getFiliaisResponseItem": {
        "id": "getFiliaisResponseItem",
        "properties": {
            "idFilial": {
                "type": "string",
                "description": "Código da filial",
                "required": true
            },
            "nmFilial": {
                "type": "string",
                "description": "Nome da filial",
                "required": true
            }
        }
    },
    "getFiliaisResponse": {
        "id": "getFiliaisResponse",
        "properties": {
            "listaFiliais": {
                "type": "array",
                "items": {
                    "$ref": "getFiliaisResponseItem"
                },
                "description": "Lista de filiais.",
                "required": true
            }
        }
    }
};
