exports.models = {
    "senhaUsuarioRequest": {
        "id": "senhaUsuarioRequest",
        "properties": {
            "senhaAtual": {
                "type": "string"
            },
            "senhaNova": {
                "type": "string"
            },
            "senhaConfirmacao": {
                "type": "string"
            }
        }
    },
    "putAlterarSenhaResponse": {
        "id": "putAlterarSenhaResponse",
        "properties": {
            "retorno": {
                "$ref": "putAlterarSenhaResponseItem"
            }
        }
    },
    "putAlterarSenhaResponseItem": {
        "id": "putAlterarSenhaResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};