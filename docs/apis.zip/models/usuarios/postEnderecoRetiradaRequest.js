exports.models = {
  "postEnderecoRetiradaRequestItem": {
    "id": "postEnderecoRetiradaRequestItem",
    "properties": {
      "cdTab": {
        "type": "number",
        "description": "Código da Loja",
        "required": true
      },
      "idFilial": {
        "type": "number",
        "description": "Código da Filial.",
        "required": true
      },
      "cdCep": {
        "type": "string",
        "description": "Código postal.",
        "required": true
      },
      "dsLogradouro": {
        "type": "string",
        "description": "Logradouro da Tab.",
        "required": true
      },
      "dsBairro": {
        "type": "string",
        "description": "Bairro do endereço.",
        "required": true
      },
      "idMunicipio": {
        "type": "number",
        "description": "Identificador da município do endereço.",
        "required": true
      },
      "dsMunicipio": {
        "type": "string",
        "description": "Descrição do município do endereço.",
        "required": true
      },
      "idUf": {
        "type": "string",
        "description": "Estado (UF) do endereço.",
        "required": true
      },
      "numero":{
        "type": "number",
        "description": "Número do endereço.",
        "required": false
      },
      "dsComplemento": {
        "type":"string",
        "description":"Descrição do complemento do endereço.",
        "required":false
      }
    }
  },
  "postEnderecoRetiradaRequest": {
    "id": "postEnderecoRetiradaRequest",
    "properties": {
      "enderecoRetirada": {
        "$ref": "postEnderecoRetiradaRequestItem",
        "description": "Dados do endereço de retirada para gravação.",
        "required": true
      }
    }
  }
};
