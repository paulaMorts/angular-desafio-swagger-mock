exports.models = {
    "getTabResponse": {
        "id": "getTabResponse",
        "properties": {
            "usuario": {
                "type": "array",
                "items": {
                    "$ref": "usuario"
                }
            }
        }
    },
    "usuario": {
        "id": "usuario",
        "properties": {
            "tab": {
                "type": "string",
                "description": "Descrição da Tab",
                "required": true
            },
            "nome": {
                "type": "string",
                "description": "Nome do Usuário",
                "required": true
            },
            "canal": {
                "type": "string",
                "description": "Canal do Usuário",
                "required": true
            }
        }
    }
};