/**
 * Created by edjan.santos on 25/05/2016.
 */
exports.models = {
    "getDetalhesRequest": {
        "id": "usuarioNovoRequest",
        "properties": {
            "identificadorFilial": {
                "type": "number"
            },
            "nrCPF": {
                "type": "string"
            },
            "nomeUsuario": {
                "type": "string"
            },
            "email": {
                "type": "string"
            },
            "nrCelular": {
                "type": "string"
            },
            "nrTelComercial": {
                "type": "string"
            },
            "idMarca": {
                "type": "number"
            },
            "idModelo": {
                "type": "number"
            },
            "idUf": {
                "type": "string"
            },
            "cdTab": {
            "type": "number"
            }
        }
    },
    "postNovoUsuarioResponse": {
        "id": "postNovoUsuarioResponse",
        "properties": {
            "retorno": {
                "$ref": "postNovoUsuarioResponseItem"
            }
        }
    },
    "postNovoUsuarioResponseItem": {
        "id": "postNovoUsuarioResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};