exports.models = {
    "putEditarUsuarioResponse": {
        "id": "putEditarUsuarioResponse",
        "properties": {
            "retorno": {
                "$ref": "putEditarUsuarioResponseItem"
            }
        }
    },
    "putEditarUsuarioResponseItem": {
        "id": "putEditarUsuarioResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};