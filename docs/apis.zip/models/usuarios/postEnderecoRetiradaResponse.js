exports.models = {
    "postEnderecoRetiradaResponse": {
        "id": "postEnderecoRetiradaResponse",
        "properties": {
            "retorno": {
                "$ref": "postEnderecoRetiradaResponseItem",
                "description": "Retorno do envio do endereço de retirada.",
                "required": true
            }
        }
    },
    "postEnderecoRetiradaResponseItem": {
        "id": "postEnderecoRetiradaResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Mensagem de retorno.",
                "required": true
            }
        }
    }
};
