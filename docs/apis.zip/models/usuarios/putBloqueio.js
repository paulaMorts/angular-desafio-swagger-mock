exports.models = {
    "putBloqueioUsuarioResponse": {
        "id": "putBloqueioUsuarioResponse",
        "properties": {
            "retorno": {
                "$ref": "putBloqueioUsuarioResponseItem"
            }
        }
    },
    "putBloqueioUsuarioResponseItem": {
        "id": "putBloqueioUsuarioResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};