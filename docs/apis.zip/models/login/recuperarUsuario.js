exports.models = {
    "recuperarUsuarioResponse": {
        "id": "recuperarUsuarioResponse",
        "properties": {
            "retorno": {
                "$ref": "recuperarUsuarioItem",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    },
    "recuperarUsuarioItem": {
        "id": "recuperarUsuarioItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};