exports.models = {
    "postLoginRequest": {
        "id": "postLoginRequest",
        "properties": {
            "login": {
                "$ref": "loginItem",
                "description": "Objeto de login",
                "required": true
            }
        }
    },
    "loginItem": {
        "id": "loginItem",
        "properties" : {
            "id_user": {
                "type": "string",
                "description": "Usuario para login",
                "required": true
            },
            "ds_password": {
                "type": "string",
                "description": "Senha para login",
                "required": true
            },
            "version": {
                "type": "number",
                "description": "Versão",
                "required": true
            },
            "captcha": {
                "$ref": "recaptcha",
                "description": "Captcha para verificação",
                "required": false
            }
        }
    },
    "recaptcha": {
        "id": "recaptcha",
        "properties": {
            "challenge": {
                "type": "string",
                "description": "Identificador do captcha gerado",
                "required": true
            },
            "response": {
                "type": "string",
                "description": "Resposta do captcha pelo usuário",
                "required": true
            }
        }
    }
};