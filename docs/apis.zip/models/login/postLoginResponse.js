exports.models = {
    "postLoginResponse": {
        "id": "postLoginResponse",
        "properties": {
            "login": {
                "$ref": "loginResponseItem",
                "description": "Resposta de login.",
                "required": true
            },
            "authorization-identity": {
                "$ref": "authorizationResponseItem",
                "description": "Resposta de autorizacao.",
                "required": true
            }
        }
    },
    "loginResponseItem": {
        "id": "loginResponseItem",
        "properties": {
            "ds_url": {
                "type": "string",
                "description": "URL a ser direcionado.",
                "required": true
            },
            "aviso": {
                "type": "string",
                "description": "Mensagem de aviso.",
                "required": true
            },
            "areaNegocio": {
                "type": "array",
                "items": {
                    "$ref": "listaAreaNegocioItem"
                },
                "description": "Lista de areas negocio",
                "required": true
            }
        }
    },
     "listaAreaNegocioItem": {
        "id": "listaAreaNegocioItem",
        "properties": {
            "id": {
                "type": "number",
                "description": "id area negocio.",
                "required": true
            },
            "isDefault": {
                "type": "boolean",
                "description": "isDefault area negocio.",
                "required": true
            },
            "nome": {
                "type": "string",
                "description": "nome area negocio.",
                "required": true
            }
        }
    },
    "authorizationResponseItem": {
        "id": "authorizationResponseItem",
        "properties": {
            "identity": {
                "type": "string",
                "description": "Token de autenticação.",
                "required": true
            }
        }
    }
};