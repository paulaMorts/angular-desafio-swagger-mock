exports.models = {
    "revokeLoginResponse": {
        "id": "revokeLoginResponse",
        "properties": {
            "logout": {
                "$ref": "logoutItem",
                "description": "Resposta de logout.",
                "required": true
            }
        }
    },
    "logoutItem": {
        "id": "logoutItem",
        "properties": {
            "revoked": {
                "type": "boolean",
                "description": "Flag que identifica se o logout foi realizado com sucesso.",
                "required": true
            }
        }
    }
};