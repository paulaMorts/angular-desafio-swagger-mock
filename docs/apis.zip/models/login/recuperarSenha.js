exports.models = {
    "recuperarSenhaResponse": {
        "id": "recuperarSenhaResponse",
        "properties": {
            "retorno": {
                "$ref": "retornoItem",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    },
    "retornoItem": {
        "id": "retornoItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};