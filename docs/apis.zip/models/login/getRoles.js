exports.models = {
    "getRolesResponse": {
        "id": "getRolesResponse",
        "properties": {
            "perfil": {
                "$ref": "getRolesResponseItem"
            }
        }
    },
    "getRolesResponseItem": {
        "id": "getRolesResponseItem",
        "properties": {
            "id_usuario": {
                "type": "string"
            },
            "role": {
                "type": "string"
            }
        }
    }
};