exports.models = {
    "senhaUsuarioRequest": {
        "id": "senhaUsuarioRequest",
        "properties": {
            "senhaAtual": {
                "type": "string"
            },
            "senhaNova": {
                "type": "string"
            },
            "senhaConfirmacao": {
                "type": "string"
            }
        }
    },
    "alterarSenhaResponse": {
        "id": "alterarSenhaResponse",
        "properties": {
            "retorno": {
                "$ref": "alterarSenhaResponseItem"
            }
        }
    },
    "alterarSenhaResponseItem": {
        "id": "alterarSenhaResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};