exports.models = {
    "serasaListObj": {
        "id": "serasaListObj",
        "properties": {
            "nrCpfCnpj": {
                "type": "string",
                "description": "Número CPF/CNPJ",
                "required": true
            },
            "descricaoTimestampConsultaCPC": {
                "type": "string",
                "description": "Timestamp",
                "required": true
            },
            "codigoTipoPendencia": {
                "type": "string",
                "description": "Código da Situação da Pendência",
                "required": true
            }

        }
    }
    ,
    "getPendenciasRequest": {
        "id": "getPendenciasRequest",
        "properties": {
            "serasaLista": {
                "$ref": "serasaListObj",
                "description": "Detalhes Itens do Serasa",
                "required": true
            }
        }
    }
};
