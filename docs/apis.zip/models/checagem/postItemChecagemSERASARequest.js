exports.models = {
    "postItemChecagemSERASARequest": {
        "id": "postItemChecagemSERASARequest",
        "properties": {
            "nrCpfCnpj": {
                "type": "string",
                "description": "Documento doc cliente.",
                "required": true
            }
        }
    }
};