exports.models = {
    "parecerObj": {
        "id": "parecerObj",
        "properties": {
            "parecerList": {
                "type": "array",
                "items": {
                    "$ref": "parecerArray"
                },
                "description": "Lista de pareceres",
                "required": true
            }
        }
    },
    "parecerArray": {
        "id": "parecerArray",
        "properties": {
            "cdPerfilUsuario": {
                "type": "string",
                "description": "Código do perfil de usuário.",
                "required": true
            },
            "cdUsuario": {
                "type": "string",
                "description": "Código do usuário.",
                "required": true
            },
            "nmUsuario": {
                "type": "string",
                "description": "Nome do usuário.",
                "required": true
            },
            "dtParecer": {
                "type": "date",
                "description": "Data do parecer.",
                "required": true
            },
            "dsParecer1": {
                "type": "string",
                "description": "Descrição do parecer 1.",
                "required": true
            },
            "dsParecer2": {
                "type": "string",
                "description": "Descrição do parecer 2.",
                "required": true
            },
            "dsParecer3": {
                "type": "string",
                "description": "Descrição do parecer 3.",
                "required": true
            },
            "dsParecer4": {
                "type": "string",
                "description": "Descrição do parecer 4.",
                "required": true
            },
            "dsParecer5": {
                "type": "string",
                "description": "Descrição do parecer 5.",
                "required": true
            },
            "dsParecer6": {
                "type": "string",
                "description": "Descrição do parecer 6.",
                "required": true
            },
            "dsParecer7": {
                "type": "string",
                "description": "Descrição do parecer 7.",
                "required": true
            },
            "dsParecer8": {
                "type": "string",
                "description": "Descrição do parecer 8.",
                "required": true
            },
            "dsParecer9": {
                "type": "string",
                "description": "Descrição do parecer 9.",
                "required": true
            },
            "dsParecer10": {
                "type": "string",
                "description": "Descrição do parecer 10.",
                "required": true
            },
            "dsParecer11": {
                "type": "string",
                "description": "Descrição do parecer 11.",
                "required": true
            },
            "dsParecer12": {
                "type": "string",
                "description": "Descrição do parecer 12.",
                "required": true
            }
        }
    },
    "getParecerResponse": {
        "id": "getParecerResponse",
        "properties": {
            "parecer": {
                "$ref": "parecerObj",
                "description": "Detalhes dos itens de checagem.",
                "required": true
            }
        }
    }
};
