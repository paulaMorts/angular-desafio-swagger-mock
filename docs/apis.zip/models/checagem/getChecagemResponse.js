exports.models = {
    "checagemObj": {
        "id": "checagemObj",
        "properties": {
            "vlMercado": {
                "type": "number",
                "description": "Valor de mercado.",
                "required": true
            },
            "dsAvaliacaoRisco": {
                "type": "string",
                "description": "Avaliação de risco da proposta.",
                "required": true
            },
            "proponente": {
                "$ref": "pessoaChecagem",
                "description": "Detalhes das informações do proponente.",
                "required": true
            },
            "avalistaList": {
                "type": "array",
                "items": {
                    "$ref": "pessoaChecagem"
                },
                "description": "Lista de detalhes .",
                "required": true
            }
        }
    },
    "pessoaChecagem": {
        "id": "pessoaChecagem",
        "properties": {
            "dsNome": {
                "type": "string",
                "description": "Nome da pessoa.",
                "required": true
            },
            "dsTipo": {
                "type": "string",
                "description": "Tipo da pessoa (Proponente ou Avalista).",
                "required": true
            },
            "nrCpfCnpj": {
                "type": "string",
                "description": "Número do documento da pessoa",
                "required": true
            },
            "nrGrauSeveridade": {
                "type": "number",
                "description": "Grau de severidade.",
                "required": true
            },
            "dsExperiencia": {
                "type": "string",
                "description": "Experiência com a pessoa.",
                "required": true
            },
            "avaliacao": {
                "type": "avaliacaoChecagem",
                "description": "Avaliação da pessoa",
                "required": true
            }
        }
    },
    "avaliacaoChecagem": {
        "id": "avaliacaoChecagem",
        "properties": {
            "lr1": {
                "type": "string",
                "description": "Item LR1.",
                "enum": ["S", "N"],
                "required": true
            },
            "lt2": {
                "type": "string",
                "description": "Item LT2.",
                "enum": ["S", "N"],
                "required": true
            },
            "lt1": {
                "type": "string",
                "description": "Item LT1.",
                "enum": ["S", "N"],
                "required": true
            },
            "lr2": {
                "type": "string",
                "description": "Item LR2.",
                "enum": ["S", "N"],
                "required": true
            },
            "cr": {
                "type": "string",
                "description": "Item CR.",
                "enum": ["S", "N"],
                "required": true
            },
            "spc": {
                "type": "string",
                "description": "Item SPC.",
                "enum": ["S", "N"],
                "required": true
            },
            "rf1": {
                "type": "string",
                "description": "Item RF1.",
                "enum": ["S", "N"],
                "required": true
            },
            "rf2": {
                "type": "string",
                "description": "Item RF2.",
                "enum": ["S", "N"],
                "required": true
            },
            "bc": {
                "type": "string",
                "description": "Item BC.",
                "enum": ["S", "N"],
                "required": true
            },
            "ser": {
                "type": "string",
                "description": "Item SER.",
                "enum": ["S", "N"],
                "required": true
            }
        }
    },
    "getChecagemResponse": {
        "id": "getChecagemResponse",
        "properties": {
            "checagem": {
                "$ref": "checagemObj",
                "description": "Detalhes dos itens de checagem.",
                "required": true
            }
        }
    }
};