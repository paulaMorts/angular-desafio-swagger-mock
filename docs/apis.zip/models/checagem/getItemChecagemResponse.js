exports.models = {
    "itemChecagemObj": {
        "id": "itemChecagemObj",
        "properties": {
            "comentarios": {
                "type": "array",
                "items": {
                    "$ref": "comentarioChecagem"
                },
                "description": "Lista de comentarios de um item de checagem.",
                "required": false
            },
            "resumo": {
                "type": "resumoChecagem",
                "description": "Resumo de um item de checagem.",
                "required": false
            }
        }
    },
    "resumoChecagem": {
        "id": "resumoChecagem",
        "properties": {
            "nome": {
                "type": "string",
                "description": "Nome do responsável pela avaliação.",
                "required": true
            },
            "cpf": {
                "type": "string",
                "description": "Documento do responsável pela avaliação.",
                "required": true
            },
            "nascimento": {
                "type": "date",
                "description": "Data de nascimento do responsável pela avaliação.",
                "required": true
            },
            "endereco": {
                "type": "string",
                "description": "Endereço do responsável pela avaliação.",
                "required": true
            },
            "dataInfo": {
                "type": "date",
                "description": "Data e hora da avaliação.",
                "required": true
            },
            "usuario": {
                "type": "string",
                "description": "Código do usuário que realizou a avaliação.",
                "required": true
            },
            "classificacao": {
                "type": "string",
                "description": "Classificação do usuário que realizou a avaliação.",
                "required": true
            },
            "quantidade": {
                "type": "number",
                "description": "Quantidade da avaliação.",
                "required": true
            },
            "situacao": {
                "type": "string",
                "description": "Situação da avaliação.",
                "required": true
            },
            "avaliacaoList": {
                "type": "array",
                "items": {
                    "$ref": "resumoChecagemItem"
                },
                "description": "Lista de avaliação",
                "required": true
            }
        }
    },
    "resumoChecagemItem": {
        "id": "resumoChecagemItem",
        "properties": {
            "quantidade": {
                "type": "number",
                "description": "Quantidade do item.",
                "required": true
            },
            "descricao": {
                "type": "string",
                "description": "Descrição do item.",
                "required": true
            },
            "desde": {
                "type": "date",
                "description": "Date e hora de início.",
                "required": true
            },
            "ate": {
                "type": "date",
                "description": "Date e hora do término.",
                "required": true
            },
            "menor": {
                "type": "number",
                "description": "Menor valor.",
                "required": true
            },
            "maior": {
                "type": "number",
                "description": "Maior valor.",
                "required": true
            }
        }
    },
    "comentarioChecagem": {
        "id": "comentarioChecagem",
        "properties": {
            "codigo": {
                "type": "string",
                "description": "Código do usuário que realizou o comentário.",
                "required": true
            },
            "dataHora": {
                "type": "string",
                "description": "Data e hora do comentário.",
                "required": true
            },
            "descricao": {
                "type": "string",
                "description": "Descrição do comentário.",
                "required": true
            },
            "usuario": {
                "type": "string",
                "description": "Usuário que realizou o comentário.",
                "required": true
            },
            "comentario": {
                "type": "string",
                "description": "Texto do comentário.",
                "required": true
            }
        }
    },
    "getItemChecagemResponse": {
        "id": "getItemChecagemResponse",
        "properties": {
            "checagem": {
                "$ref": "itemChecagemObj",
                "description": "Informações sobre o item da checagem.",
                "required": true
            }
        }
    }
};