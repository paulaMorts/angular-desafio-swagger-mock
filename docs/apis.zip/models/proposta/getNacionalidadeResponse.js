exports.models = {
    "getNacionalidadeResponse": {
        "id": "getNacionalidadeResponse",
        "properties": {
            "nacionalidade": {
                "type": "array",
                "items": {
                    "$ref": "nacionalidadeItem"
                },
                "description": "Lista de opções de nacionalidades",
                "required": true
            }
        }
    },
    "nacionalidadeItem": {
        "id": "nacionalidadeItem",
        "properties": {
            "idNacLocalNasc": {
                "type": "number",
                "description": "Identificador da nacionalidade",
                "required": true
            },
            "dsNacionalidade": {
                "type": "string",
                "description": "Descrição da nacionalidade",
                "required": true
            }
        }
    }
};