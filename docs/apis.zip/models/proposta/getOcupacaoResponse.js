exports.models = {
    "getOcupacaoResponse": {
        "id": "getOcupacaoResponse",
        "properties": {
            "ocupacao": {
                "type": "array",
                "items": {
                    "$ref": "ocupacaoItem"
                },
                "description": "Lista de ocupações.",
                "required": true
            }
        }
    },
    "ocupacaoItem": {
        "id": "ocupacaoItem",
        "properties": {
            "cdNatOcup": {
                "type": "number",
                "description": "Código da ocupação",
                "required": true
            },
            "dsNatuOcup": {
                "type": "string",
                "description": "Descrição da ocupação",
                "required": true
            }
        }
    }
};