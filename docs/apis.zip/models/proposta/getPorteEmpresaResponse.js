exports.models = {
    "getPorteEmpresaResponse": {
        "id": "getPorteEmpresaResponse",
        "properties": {
            "porteEmpresa": {
                "type": "array",
                "items": {
                    "$ref": "porteEmpresaItem"
                },
                "description": "Lista de portes de empresa.",
                "required": true
            }
        }
    },
    "porteEmpresaItem": {
        "id": "porteEmpresaItem",
        "properties": {
            "idPorteEmpresa": {
                "type": "number",
                "description": "Identificador do porte da empresa",
                "required": true
            },
            "dsPorteEmpresa": {
                "type": "string",
                "description": "Descrição do porte da empresa",
                "required": true
            }
        }
    }
};