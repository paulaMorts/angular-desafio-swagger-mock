exports.models = {
    "getCargoResponse": {
        "id": "getCargoResponse",
        "properties": {
            "cargo": {
                "type": "array",
                "items": {
                    "$ref": "cargoItem"
                },
                "description": "Lista de cargos.",
                "required": true
            }
        }
    },
    "cargoItem": {
        "id": "cargoItem",
        "properties": {
            "idCargo": {
                "type": "number",
                "description": "Código do cargo",
                "required": true
            },
            "dsCargo": {
                "type": "string",
                "description": "Descrição do cargo",
                "required": true
            }
        }
    }
};