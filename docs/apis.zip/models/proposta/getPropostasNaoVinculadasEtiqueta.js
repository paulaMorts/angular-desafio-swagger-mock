exports.models = {
    "getPropostasNaoVinculadasEtiquetaResponseItem": {
        "id": "getPropostasNaoVinculadasEtiquetaResponseItem",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Id da proposta",
                "required": true
            },
            "dtInclusao": {
                "type": "date",
                "description": "Data de inclusão da proposta",
                "required": true
            },
            "nmCliente": {
                "type": "string",
                "description": "Nome do Cliente",
                "required": true
            },
            "nrCpfCnpj": {
                "type": "number",
                "description": "Numero do CPF/CNPJ",
                "required": true
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "getPropostasNaoVinculadasEtiquetaResponse": {
        "id": "getPropostasNaoVinculadasEtiquetaResponse",
        "properties": {
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            },
            "propostasList": {
                "type": "array",
                "items": {
                    "$ref": "getPropostasNaoVinculadasEtiquetaResponseItem"
                },
                "description": "Lista de propostas não vinculadas a etiqueta.",
                "required": true
            }
        }
    }
};
