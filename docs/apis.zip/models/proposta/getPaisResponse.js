exports.models = {
    "getPaisResponse": {
        "id": "getPaisResponse",
        "properties": {
            "paises": {
                "type": "array",
                "items": {
                    "$ref": "paisItem"
                },
                "description": "Lista de países.",
                "required": true
            }
        }
    },
    "paisItem": {
        "id": "paisItem",
        "properties": {
            "cdPais": {
                "type": "number",
                "description": "Código do país",
                "required": true
            },
            "nmPais": {
                "type": "string",
                "description": "Nome do país",
                "required": true
            }
        }
    }
};