exports.models = {
    "getAtividadeEconomicaResponse": {
        "id": "getAtividadeEconomicaResponse",
        "properties": {
            "atividadeEconomica": {
                "type": "array",
                "items": {
                    "$ref": "atividadeEconomicaItem"
                },
                "description": "Lista de opções de atividade econômica.",
                "required": true
            }
        }
    },
    "atividadeEconomicaItem": {
        "id": "atividadeEconomicaItem",
        "properties": {
            "idAtividadeEconomica": {
                "type": "number",
                "description": "Identificador da atividade econômica",
                "required": true
            },
            "dsAtividadeEconomica": {
                "type": "string",
                "description": "Descrição da atividade econômica",
                "required": true
            }
        }
    }
};