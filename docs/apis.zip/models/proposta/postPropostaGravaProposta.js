exports.models = {
    "postPropostaGravaPropostaRequest": {
        "id": "postPropostaGravaPropostaRequest",
        "properties": {
            "proposta": {
                "$ref": "postPropostaGravaPropostaItem",
                "description": "Detalhes da Proposta",
                "required": true
            }
        }
    },
    "dadosPessoaisItem": {
        "id":"dadosPessoaisItem",
        "properties": {
            "nmCliente": {"type": "string", "description": "Nome do cliente", "required": true},
            "idDocumentoIdent": {"type": "number", "description": "Tipo do documento de identidade", "required": true},
            "nrDocumento": {"type": "string", "description": "Número do documento de identidade", "required": true},
            "dtExpDocumento": {
                "type": "string",
                "description": "Data de expiração do documento de identidade",
                "required": true
            },
            "cdOeDocumento": {
                "type": "string",
                "description": "Código do órgão expeditor do documento de identidade",
                "required": true
            },
            "idUfDocumento": {
                "type": "string",
                "description": "Identificador da UF expeditora do documento de identidade",
                "required": true
            },
            "dtVencDocumento": {
                "type": "string",
                "description": "Data de vencimento do documento de identidade",
                "required": true
            },
            "cdPaisDocumento": {
                "type": "number",
                "description": "Código do país do documento de identidade",
                "required": true
            },
            "idSexo": {"type": "string", "description": "Identificador do sexo do cliente", "required": true},
            "fgDeficFisico": {
                "type": "string",
                "description": "Flag se o cliente é deficiente físico",
                "required": true
            },
            "idNacLocalNasc": {
                "type": "number",
                "description": "Identificador do local de nascimento",
                "required": true
            },
            "idUfLocalNasc": {"type": "string", "description": "Identificador da UF de nascimento", "required": true},
            "idMunLocalNasc": {
                "type": "number",
                "description": "Identificador do município de nascimento",
                "required": true
            },
            "vlPatrimonio": {"type": "number", "description": "Valor do patrimônio", "required": true},
            "vlRendaMensal": {"type": "number", "description": "Valor da renda mensal", "required": true},
            "cdEmail": {"type": "string", "description": "E-mail", "required": true},
            "nrTelefoneCelular": {"type": "string", "description": "Número do telefone celular", "required": true},
            "nrTelefoneFixo": {"type": "string", "description": "Número do telefone fixo", "required": true},
            "tpTelefone": {"type": "number", "description": "Tipo do telefone principal", "required": true},
            "nmMae": {"type": "string", "description": "Nome da mãe", "required": true},
            "nmPai": {"type": "string", "description": "Nome do pai", "required": true},
            "idEstadoCivil": {"type": "number", "description": "Identificador do estado civil", "required": true},
            "nmConjuge": {"type": "string", "description": "Nome do cônjuge", "required": true},
            "nrCpfConjuge": {"type": "string", "description": "CPF do cônjuge", "required": true}
        }
    },
    "dadosEnderecoResidencialItem": {
        "id": "dadosEnderecoResidencialItem",
        "properties": {
            "cdCepResidencial": {"type": "string", "description": "CEP residencial", "required": true},
            "dsLogradouroResidencial": {"type": "string", "description": "Logradouro residencial", "required": true},
            "nrLogradouroResidencial": {"type": "string", "description": "Número residencial", "required": true},
            "dsComplementoResidencial": {"type": "string", "description": "Complemento residencial", "required": true},
            "dsBairroResidencial": {"type": "string", "description": "Bairro residencial", "required": true},
            "idUfResidencial": {"type": "string", "description": "UF residencial", "required": true},
            "idMunicipioResidencial": {"type": "number", "description": "Município residencial", "required": true}
        }
    },
    "dadosProfissionaisItem": {
        "id": "dadosProfissionaisItem",
        "properties": {
            "tpEndeCorresp": {"type": "string", "description": "Tipo de endereço de correspondência", "required": true},
            "cdNatOcup": {"type": "number", "description": "Ocupação", "required": true},
            "dsRazaoSocial": {"type": "string", "description": "Razão social", "required": true},
            "nrCnpj": {"type": "string", "description": "CNPJ da empresa", "required": true},
            "nmProfissao": {"type": "string", "description": "Profissão", "required": true},
            "dtAdmissaoAtu": {"type": "string", "description": "Data de admissão", "required": true},
            "nrTelefoneComercial": {"type": "string", "description": "Telefone comercial", "required": true}
        }
    },
    "dadosEnderecoProfissionalItem": {
        "id": "dadosEnderecoProfissionalItem",
        "properties": {
            "cdCepComercial": {"type": "string", "description": "CEP comercial", "required": true},
            "dsLogradouroComercial": {"type": "string", "description": "Logradouro comercial", "required": true},
            "nrLogradouroComercial": {"type": "string", "description": "Número comercial", "required": true},
            "dsComplementoComercial": {"type": "string", "description": "Complement comercial", "required": true},
            "dsBairroComercial": {"type": "string", "description": "Bairro comercial", "required": true},
            "idUfComercial": {"type": "string", "description": "UF comercial", "required": true},
            "idMunicipioComercial": {"type": "number", "description": "Município residencial", "required": true}
        }
    },
    "dadosReferenciaItem": {
        "id": "dadosReferenciaItem",
        "properties": {
            "nmReferencia": {"type": "string", "description": "Nome de contato de referência", "required": true},
            "nrTelefoneReferencia": {
                "type": "string",
                "description": "Telefone de contato de referência",
                "required": true
            }
        }
    },
    "dadosObservacaoItem": {
        "id": "dadosObservacaoItem",
        "properties": {
            "dsObservacao": {"type": "string", "description": "Comentários", "required": true}
        }
    },
    "postPropostaGravaPropostaItem": {
        "id": "postPropostaGravaPropostaItem",
        "properties": {
            "dadosPessoais": {"type": "dadosPessoaisItem", "description": "Dados pessoais", "required": true},
            "dadosEnderecoResidencial": {"type": "dadosEnderecoResidencialItem", "description": "Dados de endereço residencial", "required": true},
            "dadosProfissionais": {"type": "dadosProfissionaisItem", "description": "Dados profisisionais", "required": true},
            "dadosEnderecoProfissional": {"type": "dadosEnderecoProfissionalItem", "description": "Dados endereço profissional", "required": true},
            "dadosReferencia": {"type": "dadosReferenciaItem", "description": "Dados referenciais", "required": true},
            "dadosObservacao": {"type": "dadosObservacaoItem", "description": "Dados observacao", "required": true}
        }
    }
};