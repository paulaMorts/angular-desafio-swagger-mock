exports.models = {
    "getTipoTelefoneResponse": {
        "id": "getTipoTelefoneResponse",
        "properties": {
            "tipoTelefone": {
                "type": "array",
                "items": {
                    "$ref": "tipoTelefoneItem"
                },
                "description": "Lista de tipos de telefones.",
                "required": true
            }
        }
    },
    "tipoTelefoneItem": {
        "id": "tipoTelefoneItem",
        "properties": {
            "tpTelefone": {
                "type": "number",
                "description": "Identificador do tipo de telefone",
                "required": true
            },
            "dsTpTelefone": {
                "type": "string",
                "description": "Descrição do tipo de telefone",
                "required": true
            }
        }
    }
};