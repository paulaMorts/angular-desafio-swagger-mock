exports.models = {
    "getSexoResponse": {
        "id": "getSexoResponse",
        "properties": {
            "sexo": {
                "type": "array",
                "items": {
                    "$ref": "sexoItem"
                },
                "description": "Lista de opções de sexo.",
                "required": true
            }
        }
    },
    "sexoItem": {
        "id": "sexoItem",
        "properties": {
            "idSexo": {
                "type": "string",
                "description": "Sigla que identifica o sexo",
                "required": true
            },
            "dsSexo": {
                "type": "string",
                "description": "Descrição do sexo",
                "required": true
            }
        }
    }
};