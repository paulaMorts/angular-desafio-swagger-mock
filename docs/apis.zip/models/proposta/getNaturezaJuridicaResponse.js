exports.models = {
    "getNaturezaJuridicaResponse": {
        "id": "getNaturezaJuridicaResponse",
        "properties": {
            "naturezaJuridica": {
                "type": "array",
                "items": {
                    "$ref": "naturezaJuridicaItem"
                },
                "description": "Lista de opções de natureza jurídica.",
                "required": true
            }
        }
    },
    "naturezaJuridicaItem": {
        "id": "naturezaJuridicaItem",
        "properties": {
            "idNaturezaJuridica": {
                "type": "number",
                "description": "Identificador da natureza jurídica",
                "required": true
            },
            "dsNaturezaJuridica": {
                "type": "string",
                "description": "Descrição da natureza jurídica",
                "required": true
            }
        }
    }
};