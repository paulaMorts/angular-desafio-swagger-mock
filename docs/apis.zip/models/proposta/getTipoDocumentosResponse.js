exports.models = {
    "getTipoDocumentosResponse": {
        "id": "getTipoDocumentosResponse",
        "properties": {
            "tipoDocumento": {
                "type": "array",
                "items": {
                    "$ref": "tipoDocumentoItem"
                },
                "description": "Lista de tipos de documentos.",
                "required": true
            }
        }
    },
    "tipoDocumentoItem": {
        "id": "tipoDocumentoItem",
        "properties": {
            "idDocumento": {
                "type": "number",
                "description": "Identificador do tipo de documento",
                "required": true
            },
            "nmDocumento": {
                "type": "string",
                "description": "Descrição do tipo de documento",
                "required": true
            }
        }
    }
};