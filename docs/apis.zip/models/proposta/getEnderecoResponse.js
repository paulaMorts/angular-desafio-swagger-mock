exports.models = {
    "getEnderecoResponse": {
        "id": "getEnderecoResponse",
        "properties": {
            "cep": {
                "type": "array",
                "items": {
                    "$ref": "enderecoItem"
                },
                "description": "Lista de endereços com CEP.",
                "required": true
            }
        }
    },
    "enderecoItem": {
        "id": "enderecoItem",
        "properties": {
            "cep": {
                "type": "string",
                "description": "Código postal",
                "required": true
            },
            "endereco": {
                "type": "string",
                "description": "Endereco",
                "required": true
            },
            "Bairoo": {
                "type": "string",
                "description": "Bairro do endereço",
                "required": true
            },
            "idCidade": {
                "type": "number",
                "description": "Identificador da cidade do endereco",
                "required": true
            },
            "cidade": {
                "type": "string",
                "description": "Cidade do endereco",
                "required": true
            },
            "uf": {
                "type": "string",
                "description": "Estado (UF) do endereco",
                "required": true
            }
        }
    }
};