exports.models = {

    "getEtiquetaVinculadaPropostaResponse": {
        "id": "getEtiquetaVinculadaPropostaResponse",
        "properties": {
            "idEtiqueta": {
                "type": "number",
                "description": "Identificador da Etiqueta",
                "required": false
            }
          }
    }

};
