exports.models = {
    "getEstadoCivilResponse": {
        "id": "getEstadoCivilResponse",
        "properties": {
            "estadoCivil": {
                "type": "array",
                "items": {
                    "$ref": "estadoCivilItem"
                },
                "description": "Lista de opções de estado civil.",
                "required": true
            }
        }
    },
    "estadoCivilItem": {
        "id": "estadoCivilItem",
        "properties": {
            "idEstadoCivil": {
                "type": "number",
                "description": "Identificador do estado civil",
                "required": true
            },
            "dsEstadoCivil": {
                "type": "string",
                "description": "Descrição do estado civil",
                "required": true
            }
        }
    }
};