exports.models = {
    "getGrupoAtividadeEconomicaResponse": {
        "id": "getGrupoAtividadeEconomicaResponse",
        "properties": {
            "grupoAtividadeEconomica": {
                "type": "array",
                "items": {
                    "$ref": "grupoAtividadeEconomicaItem"
                },
                "description": "Lista de opções de grupo para atividade econômica.",
                "required": true
            }
        }
    },
    "grupoAtividadeEconomicaItem": {
        "id": "grupoAtividadeEconomicaItem",
        "properties": {
            "idGrpAtividadeEconomica": {
                "type": "number",
                "description": "Identificador do grupo da atividade econômica",
                "required": true
            },
            "dsGrpAtividadeEconomica": {
                "type": "string",
                "description": "Descrição do grupo da atividade econômica",
                "required": true
            }
        }
    }
};