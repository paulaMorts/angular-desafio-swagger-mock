exports.models = {
    "getMunicipioResponse": {
        "id": "getMunicipioResponse",
        "properties": {
            "municipio": {
                "type": "array",
                "items": {
                    "$ref": "municipioItem"
                },
                "description": "Lista de municipios de um estado",
                "required": true
            }
        }
    },
    "municipioItem": {
        "id": "municipioItem",
        "properties": {
            "idMunLocalNasc": {
                "type": "number",
                "description": "Identificador do municipio",
                "required": true
            },
            "nmMunicipio": {
                "type": "string",
                "description": "Nome do municipio",
                "required": true
            }
        }
    }
};