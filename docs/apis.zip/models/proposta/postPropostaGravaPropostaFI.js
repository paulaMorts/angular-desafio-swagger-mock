exports.models = {
    "postPropostaGravaPropostaFIRequest": {
        "id": "postPropostaGravaPropostaFIRequest",
        "properties": {
            "proposta": {
                "$ref": "postPropostaGravaPropostaFIItem",
                "description": "Detalhes da Proposta F&I",
                "required": true
            }
        }
    },
    "postPropostaGravaPropostaFIItem": {
        "id": "postPropostaGravaPropostaFIItem",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Dados proposta F&I",
                "required": true
            }
        }
    }
};