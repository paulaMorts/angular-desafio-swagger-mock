exports.models = {
    "getGrauParentescoResponse": {
        "id": "getGrauParentescoResponse",
        "properties": {
            "grauParentesco": {
                "type": "array",
                "items": {
                    "$ref": "grauParentescoItem"
                },
                "description": "Lista de graus de parentesco.",
                "required": true
            }
        }
    },
    "grauParentescoItem": {
        "id": "grauParentescoItem",
        "properties": {
            "idGrauParentesco": {
                "type": "number",
                "description": "Código do grau de parentesco",
                "required": true
            },
            "dsGrauParentesco": {
                "type": "string",
                "description": "Descrição do grau de parentesco",
                "required": true
            }
        }
    }
};