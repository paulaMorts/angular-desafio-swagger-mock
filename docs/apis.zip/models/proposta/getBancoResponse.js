exports.models = {
    "getBancoResponse": {
        "id": "getBancoResponse",
        "properties": {
            "banco": {
                "type": "array",
                "items": {
                    "$ref": "bancoItem"
                },
                "description": "Lista de bancos.",
                "required": true
            }
        }
    },
    "bancoItem": {
        "id": "bancoItem",
        "properties": {
            "cdBanco": {
                "type": "number",
                "description": "Código do banco",
                "required": true
            },
            "nmBanco": {
                "type": "string",
                "description": "Nome do banco",
                "required": true
            }
        }
    }
};