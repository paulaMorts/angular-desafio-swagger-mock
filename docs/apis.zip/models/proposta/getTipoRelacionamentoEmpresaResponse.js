exports.models = {
    "getTipoRelacionamentoEmpresaResponse": {
        "id": "getTipoRelacionamentoEmpresaResponse",
        "properties": {
            "tipoRelacionamentoEmpresa": {
                "type": "array",
                "items": {
                    "$ref": "tipoRelEmpresaItem"
                },
                "description": "Lista de tipos de relacionamento com a empresa.",
                "required": true
            }
        }
    },
    "tipoRelEmpresaItem": {
        "id": "tipoRelEmpresaItem",
        "properties": {
            "idTipoRelEmpresa": {
                "type": "number",
                "description": "Código do tipo de relacionamento",
                "required": true
            },
            "dsTipoRelEmpresa": {
                "type": "string",
                "description": "Descrição do tipo de relacionamento",
                "required": true
            }
        }
    }
};