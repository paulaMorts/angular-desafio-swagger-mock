exports.models = {
    "getAgenteCertificado": {
        "id": "getAgenteCertificado",
        "properties": {
            "agenteCertificado": {
                "type": "array",
                "items": {
                    "$ref": "agenteCertificadoItem"
                },
                "description": "Lista de agentes certificados.",
                "required": true
            }
        }
    },
    "agenteCertificadoItem": {
        "id": "agenteCertificadoItem",
        "properties": {
            "idAgCertificado": {
                "type": "number",
                "description": "Código do agente certificado",
                "required": true
            },
            "nmAgCertificado": {
                "type": "string",
                "description": "Nome do agente certificado",
                "required": true
            },
            "nrCpfAgCertificado": {
                "type": "string",
                "description": "CPF do agente certificado",
                "required": true
            }
        }
    }
};