exports.models = {
    "getCabecalhoPropostaResponse": {
        "id": "getCabecalhoPropostaResponse",
        "properties": {
            "cabecalho": {
                "$ref": "cabecalhoPropostaItem",
                "description": "Cabeçalho da proposta",
                "required": true
            }
        }
    },
    "cabecalhoPropostaItem": {
        "id": "cabecalhoPropostaItem",
        "properties": {
            "nrCpfCnpj": {
                "type": "string",
                "description": "Número do CPF/CNPJ",
                "required": true
            },
            "dsMarca": {
                "type": "string",
                "description": "Marca do Veículo",
                "required": true
            },
            "dsModelo": {
                "type": "string",
                "description": "Modelo do Veículo",
                "required": true
            },
            "dsAno": {
                "type": "number",
                "description": "Ano do Veículo",
                "required": true
            },
            "dsCombust": {
                "type": "string",
                "description": "Combustível do Veículo",
                "required": true
            },
            "dsZero": {
                "type": "string",
                "description": "Km do Veículo",
                "required": true
            },
            "vlFinanciamento": {
                "type": "number",
                "description": "Valor do financiamento do Veículo",
                "required": true
            },
            "dtDataNascFund": {
                "type": "int",
                "description": "Data de Nascimento",
                "required": true
            },
            "dsAnoFabricacao": {
                "type": "number",
                "description": "Ano de fabricação do veículo",
                "required": true
            },
            "vlVeiculo": {
                "type": "number",
                "description": "Valor total do veículo",
                "required": true
            },
            "idUfLicencia": {
                "type": "string",
                "description": "UF de licenciamento do veiculo",
                "required": true
            },
            "nmProduto": {
                "type": "string",
                "description": "Produto contratado",
                "required": true
            },
            "qtParcPagamento": {
                "type": "number",
                "description": "Quantidade de aprcelas do financiamento",
                "required": true
            },
            "vlPrestacao": {
                "type": "number",
                "description": "Valor de cada prestação",
                "required": true
            },
            "vlEntrada": {
                "type": "number",
                "description": "Valor da entrada",
                "required": true
            },
            "cdStatus": {
                "type": "string",
                "description": "Status da proposta",
                "required": true
            },
            "vlPrestacaoMin": {
                "type": "number",
                "description": "Valor prestação maxima",
                "required": true
            },
            "vlPrestacaoMax": {
                "type": "number",
                "description": "Valor prestação mínima",
                "required": true
            },
            "dsPacoteFlex": {
                "type": "string",
                "description": "Descrição pacote flex",
                "required": true
            }
        }
    }
};
