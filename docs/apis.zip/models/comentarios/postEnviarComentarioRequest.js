exports.models = {
    "postEnviarComentarioRequest": {
        "id": "postEnviarComentarioRequest",
        "properties": {
            "comentario": {
                "type": "array",
                "items": {
                    "$ref": "enviarComentarioItem"
                },
                "description": "Lista de comentários",
                "required": true
            }
        }
    },
    "enviarComentarioItem": {
        "id": "enviarComentarioItem",
        "properties" : {
            "idProposta": {
                "type": "number",
                "description": "Número da proposta sendo comentada",
                "required": true
            },
            "tpComentario": {
                "type": "string",
                "description": "Tipo do comentário sendo enviado",
                "required": true
            },
            "dsComentario": {
                "type": "string",
                "description": "Texto do comentário sendo enviado",
                "required": true
            }
        }
    }
};