exports.models = {
    "postEnviarComentarioResponse": {
        "id": "postEnviarComentarioResponse",
        "properties": {
            "mensagem": {
                "type": "array",
                "items": {
                    "$ref": "mensagemComentarioItem"
                },
                "description": "Lista de mensagens retornadas por um comentário",
                "required": true
            }
        }
    },
    "mensagemComentarioItem": {
        "id": "mensagemComentarioItem",
        "properties" : {
            "nmTitulo": {
                "type": "string",
                "description": "Título do comentário",
                "required": true
            },
            "dsMensagem": {
                "type": "string",
                "description": "Texto do comentário sendo enviado",
                "required": true
            }
        }
    }
};