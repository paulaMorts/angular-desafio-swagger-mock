exports.models = {
    "getTipoComentarioResponse": {
        "id": "getTipoComentarioResponse",
        "properties": {
            "tipoComentario": {
                "type": "array",
                "items": {
                    "$ref": "tipoComentarioItem"
                },
                "description": "Lista de tipos de comentários",
                "required": true
            }
        }
    },
    "tipoComentarioItem": {
        "id": "tipoComentarioItem",
        "properties" : {
            "cdTpComentario": {
                "type": "string",
                "description": "Código do tipo de comentário",
                "required": true
            },
            "dsTpComentario": {
                "type": "string",
                "description": "Tipo do comentário",
                "required": true
            }
        }
    }
};