exports.models = {
    "getComentariosResponse": {
        "id": "getComentariosResponse",
        "properties": {
            "comentarioProposta": {
                "$ref": "comentarioPropostaObj",
                "description": "Comentários de uma proposta",
                "required": true
            }
        }
    },
    "comentarioPropostaObj": {
      "id": "comentarioPropostaObj",
        "properties": {
            "dsComentario": {
                "type": "string",
                "description": "Comentário de crédito",
                "required": false
            },
            "listaComentario": {
                "type": "array",
                "items": {
                    "$ref": "comentarioPropostaItem"
                },
                "description": "Lista de comentários de uma proposta",
                "required": true
            }
        }
    },
    "comentarioPropostaItem": {
        "id": "comentarioPropostaItem",
        "properties" : {
            "tpObservacao": {
                "type": "string",
                "description": "Tipo do comentário",
                "required": true
            },
            "dhObservacao": {
                "type": "string",
                "description": "Data e hora do comentário",
                "required": true
            },
            "cdOperVarejo": {
                "type": "string",
                "description": "Código da operação",
                "required": true
            },
            "dsObservacao": {
                "type": "string",
                "description": "Texto da operação",
                "required": true
            }
        }
    }
};