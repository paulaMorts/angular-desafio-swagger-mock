exports.models = {
    "postGravarPreAnaliseRequest": {
        "id": "postGravarPreAnaliseRequest",
        "properties": {
            "idProposta": {
                "type": "string",
                "description": "ID da proposta para atualização"
            },
			"nrCpfCnpj": {
                "type": "string",
                "description": "Número de documento CPF/CNPJ informado",
                "required": true
            },
            "dtDataNascFund": {
                "type": "string",
                "description": "Data de nascimento",
                "required": true
            },
            "idTipoVeiculo": {
                "type": "number",
                "description": "Identificador do tipo de veículo",
                "required": true
            },
            "idMarca": {
                "type": "number",
                "description": "Identificador da marca do veículo",
                "required": true
            },
            "idModelo": {
                "type": "number",
                "description": "Identificador do modelo do veículo",
                "required": true
            },
            "idAnoCombust": {
                "type": "number",
                "description": "Identificador do ano/modelo do veículo",
                "required": true
            },
            "dsAnoFabricacao": {
                "type": "number",
                "description": "Ano/fabricação do veículo",
                "required": true
            },
            "vlFinanciamento": {
                "type": "number",
                "description": "Valor do financiamento",
                "required": true
            },
            "idUf": {
                "type": "string",
                "description": "Sigla do estado",
                "required": true
            },
            "fgAdaptado": {
                "type": "string",
                "description": "Flag que identifica se o veículo foi adaptado",
                "enum": ["S", "N"],
                "required": true
            },
            "fgTaxi": {
                "type": "string",
                "description": "Flag que identifica se o veículo é um taxi",
                "enum": ["S", "N"],
                "required": true
            }
        }
    }
};