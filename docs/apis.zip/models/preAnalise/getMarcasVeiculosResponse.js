exports.models = {
    "marcaVeiculoItem": {
        "id": "marcaVeiculoItem",
        "properties": {
            "idMarca": {
                "type": "number",
                "description": "Identificador da marca do veículo",
                "required": true
            },
            "dsMarca": {
                "type": "string",
                "description": "Descrição da marca do veículo",
                "required": true
            },
			"fgDefault": {
				"type": "boolean",
                "description": "Flag que identifica se o valor é o padrão para o campo",
                "required": true
			}
        }
    },
    "getMarcasVeiculosResponse": {
        "id": "getMarcasVeiculosResponse",
        "properties": {
            "marcaVeiculo": {
                "type": "array",
                "items": {
                    "$ref": "marcaVeiculoItem"
                },
                "description": "Lista de marcas de veículos.",
                "required": true
            }
        }
    }
};