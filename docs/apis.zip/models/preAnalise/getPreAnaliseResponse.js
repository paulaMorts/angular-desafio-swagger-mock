exports.models = {
	"getPreAnaliseResponse": {
		"id": "getPreAnaliseResponse",
		"properties": {
			"proposta": {
				"$ref": "getPreAnaliseResponseItem",
				"description": "Objeto sendo recuperado",
				"required": true
			}
		}
	},
    "getPreAnaliseResponseItem": {
        "id": "getPreAnaliseResponseItem",
        "properties": {
            "nrCpfCnpj": {
                "type": "string",
                "description": "Número de documento CPF/CNPJ informado",
                "required": true
            },
            "dtDataNascFund": {
                "type": "da",
                "description": "Data de nascimento",
                "required": true
            },
            "idTipoVeiculo": {
                "type": "number",
                "description": "Identificador do tipo de veículo",
                "required": true
            },
            "idMarca": {
                "type": "number",
                "description": "Identificador da marca do veículo",
                "required": true
            },
            "idModelo": {
                "type": "number",
                "description": "Identificador do modelo do veículo",
                "required": true
            },
            "idAnoCombust": {
                "type": "number",
                "description": "Identificador do ano/modelo do veículo",
                "required": true
            },
            "dsAnoFabricacao": {
                "type": "string",
                "description": "Ano/fabricação do veículo",
                "required": true
            },
            "vmBem": {
                "type": "number",
                "description": "Valor do financiamento",
                "required": true
            },
            "idUf": {
                "type": "string",
                "description": "Sigla do estado",
                "required": true
            },
            "fgAdaptado": {
                "type": "boolean",
                "description": "Flag que identifica se o veículo foi adaptado",
                "required": true
            },
            "fgTaxi": {
                "type": "boolean",
                "description": "Flag que identifica se o veículo é um taxi",
                "required": true
            }
        }
    }
};