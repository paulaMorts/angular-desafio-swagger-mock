exports.models = {
    "anoModeloVeiculoItem": {
        "id": "anoModeloVeiculoItem",
        "properties": {
            "idAnoCombust": {
                "type": "number",
                "description": "Identificador do ano/modelo do veículo",
                "required": true
            },
            "dsAno": {
                "type": "number",
                "description": "Ano do modelo",
                "required": true
            },
            "dsCombust": {
                "type": "string",
                "description": "Tipo de combustível",
                "required": true
            },
            "dsZero": {
                "type": "string",
                "description": "Identifica se o ano/modelo é zero KM"
            }
        }
    },
    "getAnoModelosVeiculosResponse": {
        "id": "getAnoModelosVeiculosResponse",
        "properties": {
            "modeloVeiculo": {
                "type": "array",
                "items": {
                    "$ref": "anoModeloVeiculoItem"
                },
                "description": "Lista de ano/modelos de veículos.",
                "required": true
            }
        }
    }
};