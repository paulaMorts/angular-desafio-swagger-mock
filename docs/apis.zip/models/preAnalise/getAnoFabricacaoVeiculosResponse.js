exports.models = {
    "anoFabricacaoVeiculoItem": {
        "id": "anoFabricacaoVeiculoItem",
        "properties": {
            "dsAnoFabricacao": {
                "type": "number",
                "description": "Ano de fabricação do veículo",
                "required": true
            }
        }
    },
    "getAnoFabricacaoVeiculosResponse": {
        "id": "getAnoFabricacaoVeiculosResponse",
        "properties": {
            "anoFabricacao": {
                "type": "array",
                "items": {
                    "$ref": "anoFabricacaoVeiculoItem"
                },
                "description": "Lista de ano/fabricacao de veículos.",
                "required": true
            }
        }
    }
};