exports.models = {
    "modeloVeiculoItem": {
        "id": "modeloVeiculoItem",
        "properties": {
            "idModelo": {
                "type": "number",
                "description": "Identificador do modelo do veículo",
                "required": true
            },
            "dsModelo": {
                "type": "string",
                "description": "Descrição do modelo do veículo",
                "required": true
            },
			"fgDefault": {
				"type": "boolean",
                "description": "Flag que identifica se o valor é o padrão para o campo",
                "required": true
			}
        }
    },
    "getModelosVeiculosResponse": {
        "id": "getModelosVeiculosResponse",
        "properties": {
            "modeloVeiculo": {
                "type": "array",
                "items": {
                    "$ref": "modeloVeiculoItem"
                },
                "description": "Lista de modelos de veículos.",
                "required": true
            }
        }
    }
};