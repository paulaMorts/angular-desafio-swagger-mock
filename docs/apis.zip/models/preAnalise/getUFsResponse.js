exports.models = {
    "UFItem": {
        "id": "UFItem",
        "properties": {
            "idUf": {
                "type": "string",
                "description": "Sigla do estado (UF)",
                "required": true
            },
            "dsUf": {
                "type": "string",
                "description": "Descrição do estado (UF)",
                "required": true
            },
			"fgDefault": {
				"type": "boolean",
                "description": "Flag que identifica se o valor é o padrão para o campo",
                "required": true
			}
        }
    },
    "getUFsResponse": {
        "id": "getUFsResponse",
        "properties": {
            "UFItem": {
                "type": "array",
                "items": {
                    "$ref": "UFItem"
                },
                "description": "Lista de UFs.",
                "required": true
            }
        }
    }
};