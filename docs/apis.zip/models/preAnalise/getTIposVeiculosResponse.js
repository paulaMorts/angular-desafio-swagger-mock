exports.models = {
    "tipoVeiculoItem": {
        "id": "tipoVeiculoItem",
        "properties": {
            "idTipoVeiculo": {
                "type": "number",
                "description": "Identificador do tipo de veículo",
                "required": true
            },
            "dsTipoVeiculo": {
                "type": "string",
                "description": "Descrição do tipo de veículo",
                "required": true
            }
        }
    },
    "getTiposVeiculosResponse": {
        "id": "getTiposVeiculosResponse",
        "properties": {
            "tipoVeiculo": {
                "type": "array",
                "items": {
                    "$ref": "tipoVeiculoItem"
                },
                "description": "Lista de tipos de veículos.",
                "required": true
            }
        }
    }
};