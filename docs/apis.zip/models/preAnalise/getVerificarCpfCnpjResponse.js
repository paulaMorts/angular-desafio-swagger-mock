exports.models = {
    "getVerificarCpfCnpjResponse": {
        "id": "getVerificarCpfCnpjResponse",
        "properties": {
            "valido": {
                "type": "boolean",
                "description": "Identificador se o documento informado é válido.",
                "required": true
            },
            "cpfCnpj": {
                "type": "string",
                "description": "Documento CPF/CNPJ informado na requisição.",
                "required": true
            }
        }
    }
};