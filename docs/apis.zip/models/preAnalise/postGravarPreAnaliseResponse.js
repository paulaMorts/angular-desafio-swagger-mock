exports.models = {
    "postGravarPreAnaliseResponse": {
        "id": "postGravarPreAnaliseResponse",
		"properties": {
            "proposta": {
                "$ref": "propostaItem",
                "description": "Objeto de propost",
                "required": true
            }
        }
    },
	"propostaItem": {
		"id": "propostaItem",
		"properties": {
            "idProposta": {
                "type": "number",
                "description": "Identificador da proposta gerado",
                "required": true
            },
            "dsMensagemRepesc": {
                "type": "string",
                "description": "Mensagem RESPEC",
                "required": true
            },
            "cdErro": {
                "type": "number",
                "description": "Código da mensagem de erro durante a criação da proposta"
            },
            "dsMensagem": {
                "type": "string",
                "description": "Descrição da mensagem de erro durante a criação da proposta"
            }
        }
	}
};
