exports.models = {
    "getEtiquetasResponseItem": {
        "id": "getEtiquetasResponseItem",
        "properties": {
            "idEtiqueta": {
                "type": "number",
                "description": "Id da etiqueta",
                "required": true
            },
            "cdBarras": {
                "type": "number",
                "description": "Codigo de Barras",
                "required": true
            },
            "dtGeracao": {
                "type": "date",
                "description": "Data de geração da etiqueta",
                "required": false
            },
            "dtEnvio": {
                "type": "date",
                "description": "Data de envio ",
                "required": false
            },
            "dtRecebimentoEmpresaGuarda": {
                "type": "date",
                "description": "Data de recebimento da empresa de guarda",
                "required": false
            },
            "dsStatus": {
                "type": "string",
                "description": "Status da etiqueta (Gerada, Enviada, Cancelada, Finalizada – recebida, Finalizada – não recebida)",
                "required": false
            },
            "dsModal": {
                "type": "string",
                "description": "Modal (Correios, Motoboy)",
                "required": true
            },
            "dsMensagem": {
                "type": "string",
                "description": "Orientação sobre o envio do envelope",
                "required": false
            },
            "nrServicoPac": {
                "type": "number",
                "description": "Código do serviço de PAC",
                "required": false
            },
            "nrObjetoRastreio": {
                "type": "number",
                "description": "Número de objeto (rastreabilidade dos correios) ",
                "required": false
            },
            "qtdPropostasVinculadas": {
                "type": "number",
                "description": "Quantidade de Propostas Vinculadas",
                "required": false
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "getEtiquetasResponse": {
        "id": "getEtiquetasResponse",
        "properties": {
            "tipoEnvio": {
                "type": "string",
                "description": "Tipo de forma de envio.",
                "required": true
            },
            "etiquetasList": {
                "type": "array",
                "items": {
                    "$ref": "getEtiquetasResponseItem"
                },
                "description": "Lista de etiquetas.",
                "required": true
            },
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            }
        }
    }
};
