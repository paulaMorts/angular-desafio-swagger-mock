exports.models = {
    "getEtiquetaImpressaoResponse": {
        "id": "getEtiquetaImpressaoResponse",
        "properties": {
            "file": {
                "type": "getEtiquetaImpressaoResponseItem",
                "description": "Documento",
                "required": true
            }
        }
    },
    "getEtiquetaImpressaoResponseItem": {
        "id": "getEtiquetaImpressaoResponseItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Base64 do documento",
                "required": true
            },
            "nmFile": {
                "type": "string",
                "description": "Nome do documento",
                "required": true
            }
        }
    }
};
