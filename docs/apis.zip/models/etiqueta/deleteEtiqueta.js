exports.models = {

    "postEtiquetaResponse": {
        "id": "postEtiquetaResponse",
        "properties": {
            "idEtiqueta": {
                "type": "number",
                "description": "Identificador da Etiqueta",
                "required": false
            }
          }
    }

};
