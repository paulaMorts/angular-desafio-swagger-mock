exports.models = {
    "propostasVinculadasItem": {
        "id": "propostasVinculadasItem",
        "properties": {
              "idProposta": {
                  "type": "number",
                  "description": "Id da proposta vinculada",
                  "required": true
              }

        }
    },
    "postEtiquetaRequest": {
        "id": "postEtiquetaRequest",
        "properties": {
            "cdBarras": {
                "type": "number",
                "description": "Codigo de Barras",
                "required": true
            },
            "dtGeracao": {
                "type": "date",
                "description": "Data de geração da etiqueta",
                "required": false
            },
            "dtEnvio": {
                "type": "date",
                "description": "Data de envio ",
                "required": false
            },
            "dtRecebimentoEmpresaGuarda": {
                "type": "date",
                "description": "Data de recebimento da empresa de guarda",
                "required": false
            },
            "dsStatus": {
                "type": "string",
                "description": "Status da etiqueta (Gerada, Enviada, Cancelada, Finalizada – recebida, Finalizada – não recebida)",
                "required": false
            },
            "dsModal": {
                "type": "string",
                "description": "Modal (Correios, Motoboy)",
                "required": true
            },
            "dsMensagem": {
                "type": "string",
                "description": "Orientação sobre o envio do envelope",
                "required": false
            },
            "nrServicoPac": {
                "type": "number",
                "description": "Código do serviço de PAC",
                "required": false
            },
            "nrObjetoRastreio": {
                "type": "number",
                "description": "Número de objeto (rastreabilidade dos correios) ",
                "required": false
            },


            "propostasVinculadasList": {
                "type": "array",
                "items": {
                    "$ref": "propostasVinculadasItem"
                },
                "description": "Lista de propostas vinculadas.",
                "required": true
            }
        }
    },
    "postEtiquetaResponse": {
        "id": "postEtiquetaResponse",
        "properties": {
            "idEtiqueta": {
                "type": "number",
                "description": "Identificador da Etiqueta",
                "required": false
            }
          }
    }

};
