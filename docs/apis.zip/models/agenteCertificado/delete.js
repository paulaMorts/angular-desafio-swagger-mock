exports.models = {
    "deleteAgenteCertificadoResponse": {
        "id": "deleteAgenteCertificadoResponse",
        "properties": {
            "retorno": {
                "$ref": "deleteAgenteCertificadoResponseItem"
            }
        }
    },
    "deleteAgenteCertificadoResponseItem": {
        "id": "deleteAgenteCertificadoResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};