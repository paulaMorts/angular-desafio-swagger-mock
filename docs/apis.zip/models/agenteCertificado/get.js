exports.models = {
    "getAgenteCertificadoResponse": {
        "id": "getAgenteCertificadoResponse",
        "properties": {
			"agenteCertificado": {
				"$ref": "getAgenteCertificadoResponseItem"
			}
        }
    },
	"getAgenteCertificadoResponseItem": {
		"id": "getAgenteCertificadoResponseItem",
		"properties": {
			"cdAgente": {
                "type": "number"
            },
            "cdIntermediario": {
                "type": "number"
            },
            "cdSituacao": {
                "type": "string"
            },
            "fgDefaultInterm": {
                "type": "boolean"
            },
            "dtValidadeCert": {
                "type": "string",
                "format": "date"
            },
            "nmAgente": {
                "type": "string"
            },
            "nrCertificado": {
                "type": "string"
            },
            "nrCpf": {
                "type": "string"
            }
		}
	}
};