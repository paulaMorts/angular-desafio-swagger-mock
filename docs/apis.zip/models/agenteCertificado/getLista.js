exports.models = {
    "getListaAgenteCertificadoResponse": {
        "id": "getListaAgenteCertificadoResponse",
        "properties": {
            "agentesCertificados": {
                "type": "array",
                "items": {
                    "$ref": "getListaAgenteCertificadoResponseItem"
                }
            },
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "getListaAgenteCertificadoResponseItem": {
        "id":"getListaAgenteCertificadoResponseItem",
        "properties": {
            "idAgCertificado": {
                "type": "number"
            },
            "nmAgente": {
                "type": "string"
            },
            "nrCpf": {
                "type": "string"
            },
            "dtValidadeCert": {
                "type": "string"
            },
            "cdAgente": {
                "type": "number"
            },
            "cdSituacao": {
                "type": "string"
            }
        }
    }
};