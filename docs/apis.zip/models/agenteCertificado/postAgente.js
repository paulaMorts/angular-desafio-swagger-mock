exports.models = {
    "postAgenteRequest": {
        "id": "postAgenteRequest",
        "properties": {
			"agenteCertificado": {
				"$ref": "agenteCertificadoRequestItem"
			}
        }
    },
	"agenteCertificadoRequestItem": {
        "id": "agenteCertificadoRequestItem",
        "properties": {
			"cdAgente": {
                "type": "number"
            },
            "cdIntermediario": {
                "type": "number"
            },
            "cdSituacao": {
                "type": "string"
            },
            "fgDefaultInterm": {
                "type": "boolean"
            },
            "dtValidadeCert": {
                "type": "string",
                "format": "date"
            },
            "nmAgente": {
                "type": "string"
            },
            "nrCertificado": {
                "type": "string"
            },
            "nrCpf": {
                "type": "number"
            }
        }
    },
    "postAgenteResponse": {
        "id": "postAgenteResponse",
        "properties": {
            "retorno": {
                "$ref": "postAgenteResponseItem"
            }
        }
    },
    "postAgenteResponseItem": {
        "id": "postAgenteResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno de sucesso",
                "required": true
            }
        }
    }
};