/**
 * Created by dalton.leonardo on 10/5/2016.
 */
exports.models = {
    "getDadosCessaoResponse": {
        "id": "getDadosCessaoResponse",
        "properties": {
            "qtdMaximoParcelas": {
                "type": "number",
                "description": "Quantidade máxima de parcelas.",
                "required": true
            },
            "produto": {
                "$ref": "produtosResponse",
                "description": "Resposta de produto.",
                "required": true
            }
        }
    },
    "produtosResponse": {
        "id": "produtosResponse",
        "properties": {
            "id": {
                "type": "number",
                "description": "Código produto.",
                "required": true
            },
            "nome": {
                "type": "string",
                "description": "Nome produto.",
                "required": true
            }
        }
    }
};