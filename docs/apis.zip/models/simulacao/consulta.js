exports.models = {
    "consultaRequest": {
        "id": "consultaRequest",
        "properties": {
            "parameter": {
                "$ref": "parameterItem",
                "description": "Objeto de consulta.",
                "required": true
            }
        }
    },
    "parameterItem": {
        "id": "parameterItem",
        "properties": {
            "idProposta": {
                "type": "string",
                "description": "Identificador da proposta",
                "required": true
            },
            "idFormaPagamento": {
                "type": "string",
                "description": "Id da forma de pagamento",
                "required": true
            },
            "cdModalidade": {
                "type": "string",
                "description": "Código da modalidade de pagamento",
                "required": true
            },
            "nrPacote": {
                "type": "string",
                "description": "Número do pacote",
                "required": true
            },
            "cdCupom": {
                "type": "string",
                "description": "Código do Cupom",
                "required": true
            }
        }
    },
    "consultaResponse": {
        "id": "consultaResponse",
        "properties": {
            "tabelaPreco": {
                "$ref": "tabelaPrecoItem",
                "description": "Tabela de preço.",
                "required": true
            },
            "consultaAtx": {
                "$ref": "consultaResponseItem",
                "description": "Objeto de consulta.",
                "required": true
            }
        }
    },
    "consultaResponseItem": {
        "id": "consultaResponseItem",
        "properties": {
            "idFormaPagamento": {
                "type": "string",
                "description": "Tipo forma de pagamento",
                "required": true
            },
            "dtRecomendadaPrimeiraParcela": {
                "type": "string",
                "description": "Data para pagamento de primeira parcela Data considerando carência recomendada da tabela",
                "required": true
            },
            "dtMaxPrimeiraParcela": {
                "type": "string",
                "description": "Data do primeiro vencimento maxima",
                "required": true
            },
            "dtMinPrimeiraParcela": {
                "type": "string",
                "description": "Data do primeiro vencimento minima",
                "required": true
            },
            "fgOfertaSeguroPermitida": {
                "type": "string",
                "description": "Indicação se, para a Tabela de Preço informada, permite-se ofertar seguro",
                "required": true
            },
            "prazosDisponiveis": {
                "type": "array",
                "items": {
                    "$ref": "prazosDisponiveisItem"
                },
                "description": "Prazo disponiveis.",
                "required": true
            },
            "faixaBarraEntrada": {
                "type": "number",
                "description": "Valor a ser usado como escala mínima da barra",
                "required": true
            },
            "vlMaxEntrada": {
                "type": "number",
                "description": "Valor maximo de entrada",
                "required": true
            },
            "idFrotaRecomendada": {
                "type": "number",
                "description": "Identificador da frota recomendada",
                "required": true
            },
            "vlMinEntrada": {
                "type": "number",
                "description": "Valor minimo de entrada",
                "required": true
            },
            "vlRecomendadaEntrada": {
                "type": "number",
                "description": "Valor recomendado de entrada",
                "required": true
            },
            "ofertaSeguro": {
                "type": "array",
                "items": {
                    "$ref": "ofertaSeguroItem"
                },
                "description": "Grupo consulta oferta de seguros.",
                "required": true
            },
            "pacotesCdcFlex": {
                "type": "array",
                "items": {
                    "$ref": "pacotesCdcFlexItem"
                },
                "description": "Grupo pacotes CDC Flex.",
                "required": true
            },
            "dadosIsencao": {
                "type": "array",
                "items": {
                    "$ref": "dadosIsencaoItem"
                },
                "description": "Grupo dados de isenção",
                "required": true
            },
            "fgHabilitaFrota": {
                "type": "string",
                "description": "Flag para habilitação do campo de seleção de frota.",
                "enum": ["S", "N"],
                "required": true
            },
            "frota": {
                "type": "array",
                "items": {
                    "$ref": "frotaItem"
                },
                "description": "Lista de frota.",
                "required": true
            },
            "formaPagamento": {
                "type": "array",
                "items": {
                    "$ref": "formaPagamentoItem"
                },
                "description": "Lista de formas de pagamento.",
                "required": true
            }
        }
    },
    "formaPagamentoItem": {
        "id": "formaPagamentoItem",
        "properties": {
            "idFormaPagto": {
                "type": "number",
                "description": "Identificador da forma pagamento",
                "required": true
            },
            "dsFormaPagto": {
                "type": "string",
                "description": "Descrição forma de pagamento",
                "required": true
            }
        }
    },
    "tabelaPrecoItem": {
        "id": "tabelaPrecoItem",
        "properties": {
            "cdTabela": {
                "type": "string",
                "description": "Codigo da Tabela",
                "required": true
            }
        }
    },
    "prazosDisponiveisItem": {
        "id": "prazosDisponiveisItem",
        "properties": {
            "nrPrazoDisponivel": {
                "type": "number",
                "description": "Numero prazo disponivel",
                "required": true
            }
        }
    },
    "ofertaSeguroItem": {
        "id": "ofertaSeguroItem",
        "properties": {
            "cdSeguro": {
                "type": "string",
                "description": "Codigo do seguro",
                "required": true
            },
            "dsSeguro": {
                "type": "string",
                "description": "Descrição do seguro",
                "required": true
            },
            "dsCaracteristica": {
                "type": "string",
                "description": "Descrição caracteristica do seguro",
                "required": true
            },
            "dsJustificativa": {
                "type": "string",
                "description": "Descrição justificativa do seguro",
                "required": true
            },
            "fgSeguroPadrao": {
                "type": "string",
                "description": "Flag seguro padrão",
                "required": true
            }
        }
    },
    "pacotesCdcFlexItem": {
        "id": "pacotesCdcFlexItem",
        "properties": {
            "nrPacoteFinanc": {
                "type": "number",
                "description": "Numero pacote financiamento",
                "required": true
            },
            "nmPacoteFinanc": {
                "type": "string",
                "description": "Nome do pacote financiamento",
                "required": true
            }
        }
    },
    "dadosIsencaoItem": {
        "id": "dadosIsencaoItem",
        "properties": {
            "fgIsencaoTab": {
                "type": "string",
                "description": "Flag isenção TAB",
                "required": true
            },
            "fgPagamentoTabAvista": {
                "type": "string",
                "description": "Flag isenção TAB pagamento a vista",
                "required": true
            },
            "fgIsencaoTc": {
                "type": "string",
                "description": "Flag isenção TC",
                "required": true
            },
            "fgPagamentoTcAvista": {
                "type": "string",
                "description": "Flag isenção TC pagamento a vista",
                "required": true
            },
            "dsMensagem": {
                "type": "string",
                "description": "Descrição mensagem",
                "required": true
            }
        }
    },
    "frotaItem": {
        "id": "frotaItem",
        "properties": {
            "idFrota": {
                "type": "number",
                "description": "Identificador da frota",
                "required": true
            },
            "dsFrota": {
                "type": "string",
                "description": "Descrição da frota",
                "required": true
            }
        }
    }
};
