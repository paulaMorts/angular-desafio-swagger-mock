exports.models = {
    "getCabecalhoResponse": {
        "id": "getCabecalhoResponse",
        "properties": {
            "nrCpfCnpj": {
                "type": "string",
                "description": "Número do CPF/CNPJ",
                "required": true
            },
            "dsMarca": {
                "type": "string",
                "description": "Marca do Veículo",
                "required": true
            },
            "dsModelo": {
                "type": "string",
                "description": "Modelo do Veículo",
                "required": true
            },
            "dsAno": {
                "type": "number",
                "description": "Ano do Veículo",
                "required": true
            },
            "dsCombust": {
                "type": "string",
                "description": "Combustível do Veículo",
                "required": true
            },
            "dsZero": {
                "type": "string",
                "description": "Km do Veículo",
                "required": true
            },
            "vlFinanciamento": {
                "type": "number",
                "description": "Valor do financiamento do Veículo",
                "required": true
            },
            "dtDataNascFund": {
                "type": "int",
                "description": "Data de Nascimento",
                "required": true
            },
            "dsAnoFabricacao": {
                "type": "number",
                "description": "Ano de fabricação do veículo",
                "required": true
            }
        }
    }
};