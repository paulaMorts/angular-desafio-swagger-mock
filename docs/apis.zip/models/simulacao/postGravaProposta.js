exports.models = {
    "postGravaPropostaResponse": {
        "id": "postGravaPropostaResponse",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Identificador da proposta",
                "required": true
            },
            "cdErro": {
                "type": "number",
                "description": "Código de erro",
                "required": true
            },
            "dsMensagem": {
                "type": "string",
                "description": "Descrição do erro",
                "required": true
            }
        }
    },
    "postGravaPropostaRequest": {
        "id": "postGravaPropostaRequest",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Identificador da proposta",
                "required": true
            },
            "vlFinanciamento": {
                "type": "number",
                "description": "Valor para financiamento",
                "required": true
            },
            "vlPrestacao": {
                "type": "number",
                "description": "Valor da prestação do financiamento",
                "required": true
            },
            "qtParcPagamento": {
                "type": "number",
                "description": "Quantidade de parcelas",
                "required": true
            },
            "dtPrim_Parc": {
                "type": "string",
                "description": "Data da primeira parcela",
                "required": true
            },
            "vlEntrada": {
                "type": "number",
                "description": "Valor da entrada",
                "required": true
            },
            "vlSeguro": {
                "type": "number",
                "description": "Valor do Seguro",
                "required": true
            },
            "idFormaPagto": {
                "type": "number",
                "description": "Identificador da forma de pagamento",
                "required": true
            }
        }
    }
};
