exports.models = {
    "getSimulacaoResponse": {
        "id": "getSimulacaoResponse",
        "properties": {
            "simulacao": {
                "$ref": "getSimulacaoResponseItem",
                "description": "Objeto de simulação.",
                "required": true
            },
            "CET": {
                "$ref": "CETItem",
                "description": "Objeto de CET.",
                "required": true
            }
        }
    },
    "CETItem": {
        "id": "CETItem",
        "properties": {
            "content": {
                "type": "string",
                "description": "Base 64 do CET",
                "required": true
            }
        }
    },
    "getSimulacaoResponseItem": {
        "id": "getSimulacaoResponseItem",
        "properties": {
            "vlParcela": {
                "type": "number",
                "description": "Valor da parcela do financiamento",
                "required": true
            },
            "faixaBarraEntrada": {
                "type": "number",
                "description": "Indicador de salto na barra de slide",
                "required": true
            },
            "qtParcPagamento": {
                "type": "number",
                "description": "Quantidade de parcelas",
                "required": true
            },
            "vlEntrada": {
                "type": "number",
                "description": "Valor de entrada",
                "required": true
            },
            "vlVeiculo": {
                "type": "number",
                "description": "Valor do veículo",
                "required": true
            },
            "vlSeguro": {
                "type": "number",
                "description": "Valor do seguro",
                "required": true
            },
            "dominioParcelas": {
                "type": "array",
                "items": {
                    "$ref": "dominioParcelasItem"
                },
                "description": "Lista de parcelas.",
                "required": true
            }
        }
    },
    "dominioParcelasItem": {
        "id": "dominioParcelasItem",
        "properties": {
            "quantidade": {
                "type": "number",
                "description": "Quantidade de parcelas.",
                "required": true
            },
            "vlPadrao": {
                "type": "number",
                "description": "Valor das parcelas.",
                "required": true
            },
            "vlParcelaInicio": {
                "type": "number",
                "description": "Valor da parcela inicial.",
                "required": true
            },
            "vlParcelaFim": {
                "type": "number",
                "description": "Valor da parcela final.",
                "required": true
            }
        }
    }
};
