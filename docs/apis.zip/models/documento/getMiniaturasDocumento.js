exports.models = {
    "getMiniaturasDocumentoResponse": {
        "id": "getMiniaturasDocumentoResponse",
        "properties": {
            "listaImagens": {
                "type": "array",
                "items": {
                    "$ref": "getMiniaturasDocumentoResponseItem"
                },
                "description": "Lista de miniaturast",
                "required": true
            },
            "dataAtualizacao": {
                "type": "string"
            }
        }
    },
    "getMiniaturasDocumentoResponseItem": {
        "id": "getMiniaturasDocumentoResponseItem",
        "properties": {
            "bsThumb": {
                "type": "string",
                "description": "Base64 da miniatura",
                "required": true
            },
            "idArtefato": {
                "type": "string",
                "description": "Identificador do artefato",
                "required": true
            },
            "idImagem": {
                "type": "number",
                "description": "Identificador da imagem",
                "required": true
            }
        }
    }
};