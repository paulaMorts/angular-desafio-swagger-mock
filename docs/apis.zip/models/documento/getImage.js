exports.models = {
    "getImageResponse": {
        "id": "getImageResponse",
        "properties": {
            "file": {
                "type": "getImageResponseItem",
                "description": "Documento",
                "required": true
            }
        }
    },
    "getImageResponseItem": {
        "id": "getImageResponseItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Base64 do documento",
                "required": true
            },
            "nmFile": {
                "type": "string",
                "description": "Nome do documento",
                "required": true
            }
        }
    }
};