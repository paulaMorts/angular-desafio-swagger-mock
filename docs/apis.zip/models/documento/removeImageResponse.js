exports.models = {
    "removeImageRequest": {
        "id": "removeImageRequest",
        "properties": {
            "idImagem": {
                "type": "number",
                "description": "Identificador da imagem",
                "required": true
            },
            "idChecklist": {
                "type": "number",
                "description": "Identificador do checklist",
                "required": true
            }
        }
    },
    "removeImageResponse": {
        "id": "removeImageResponse",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Sucesso na exclusao",
                "required": true
            }
        }
    }
};