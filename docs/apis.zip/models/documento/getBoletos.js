exports.models = {
    "getBoletosResponse": {
        "id": "getBoletosResponse",
        "properties": {
            "boletosList": {
                "type": "getBoletosItem"
            }
        }
    },
    "getBoletosItem": {
        "id": "getBoletosItem",
        "properties": {
            "dsDocumento": {
                "type": "string",
                "description": "Base64 do documento"
            },
            "tipo": {
                "type": "string",
                "description": "Tipo de documento"
            }
        }
    },
    "getBoletosRequest": {
        "id": "getBoletosRequest",
        "properties": {
            "boletoTC": {
                "type": "boolean"
            },
            "boletoTab": {
                "type": "boolean"
            }
        }
    }
};