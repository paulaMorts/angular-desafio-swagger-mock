exports.models = {
    "getContratosResponse": {
        "id": "getContratosResponse",
        "properties": {
            "contratosList": {
                "type": "getContratosItem"
            }
        }
    },
    "getContratosItem": {
        "id": "getContratosItem",
        "properties": {
            "dsDocumento": {
                "type": "string",
                "description": "Base64 do documento"
            },
            "dsName": {
                "type": "string",
                "description": "Nome do documento"
            }
        }
    },
    "getContratosRequest": {
        "id": "getContratosRequest",
        "properties": {
            "contratoFinanciamento": {
                "type": "boolean"
            },
            "compraCerta": {
                "type": "boolean"
            }
        }
    }
};
