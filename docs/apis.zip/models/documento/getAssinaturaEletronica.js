exports.models = {
    "getAssinaturaEletronicaResponse": {
        "id": "getAssinaturaEletronicaResponse",
        "properties": {
            "dsUrl": {
                "type": "string"
            }
        }
    }
};