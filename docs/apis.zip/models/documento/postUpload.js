exports.models = {
    "postUploadRequest": {
        "id": "postUploadRequest",
        "properties": {
            "idChecklist": {
                "type": "number",
                "description": "Número do checklist",
                "required": true
            },
            "content": {
                "type": "string",
                "description": "Base64 do arquivo",
                "required": true
            },
            "contentType": {
                "type": "string",
                "description": "Tipo de conteúdo do arquivo",
                "required": true
            },
            "fileName": {
                "type": "string",
                "description": "Nome do arquivo",
                "required": true
            }
        }
    },
    "postUploadResponse": {
        "id": "postUploadResponse",
        "properties": {
            "retorno": {
				"$ref": "postUploadResponseMsg",
				"description": "Mensagem de sucesso de upload",
				"required": true
			},
			"ocrResponse": {
                "type": "array",
                "items": {
                    "$ref": "postUploadResponseItem"
                },
                "description": "Retorno do upload",
                "required": true
            }
        }
    },
	"postUploadResponseMsg": {
		"id": "postUploadResponseMsg",
		"properties": {
			"dsMensagem": {
                "type": "string",
                "description": "Mensagem de upload",
                "required": true
            }
		}
	},
    "postUploadResponseItem": {
        "id": "postUploadResponseItem",
        "properties": {
            "nome": {
                "type": "string",
                "description": "Nome do campo",
                "required": true
            },
            "valor": {
                "type": "string",
                "description": "Valor do campo em questão",
                "required": true
            },
            "exibir": {
                "type": "string",
                "description": "Flag que identifica se o campo deve ser exibido.",
                "required": true
            }
        }
    }
};
