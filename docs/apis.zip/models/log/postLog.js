exports.models = {
    "postLogRequest": {
        "id": "postLogRequest",
        "properties": {
            "log": {
                "$ref": "postLogItem",
                "description": "Detalhes do Log",
                "required": true
            }
        }
    },
    "postLogItem": {
        "id": "postLogItem",
        "properties": {
            "dtRegistro": {
                            "type": "string",
                            "description": "Data de Registro",
                            "required": true
            },
            "idUsuario": {
                            "type": "string",
                            "description": "Id do Usuário",
                            "required": true
            },
            "cdTab": {
                "type": "string",
                "description": "Código da Tab",
                "required": true
            },
            "dsRequest": {
                "type": "string",
                "description": "Parâmetros de Request",
                "required": false
            },
            "dsResponse": {
                "type": "string",
                "description": "Parâmetros de Response",
                "required": false
            },
            "dsErro": {
                "type": "string",
                "description": "Descrição do Erro",
                "required": false
            }
        }
    }
};