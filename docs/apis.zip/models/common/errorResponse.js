exports.models = {
    "errorResponse": {
        "id": "errorResponse",
        "properties": {
			"code": {
                "type": "string",
                "description": " O codigo interno de erro mapeapeado pela aplicação. Esse código tem que fazer sentido para o negócio e poder ser facilmente identificado por um recurso funcional.",
				"required": true
            },
            "message": {
                "type": "string",
                "description": "Mensagem amigável de erro que será apresentado na tela para o usuário final.",
				"required": true
            },
			"causedBy": {
                "type": "string",
                "description": "O componente que causou o erro do lado do servidor. Essa informação só será enviada pelo servidor quando executado em modo de debug."
            },
			"stacktrace": {
                "type": "string",
                "description": "A stacktrace do erro ocorrido no servidor. Essa informação só será enviada pelo servidor quando executado em modo de debug."
            }
        }
    }
};