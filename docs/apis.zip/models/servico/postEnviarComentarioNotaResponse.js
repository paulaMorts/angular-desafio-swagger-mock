exports.models = {
    "postEnviarComentarioNotaResponse": {
        "id": "postEnviarComentarioNotaResponse",
        "properties": {
            "retorno": {
                "$ref": "mensagemComentarioNotaItem",
                "description": "Mensagem ok",
                "required": true
            }
        }
    },
    "mensagemComentarioNotaItem": {
        "id": "mensagemComentarioNotaItem",
        "properties" : {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno",
                "required": true
            }
        }
    }
};