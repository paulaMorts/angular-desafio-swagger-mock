exports.models = {
    "getContratoResponse": {
        "id": "getContratoResponse",
        "properties": {
            "detalheContrato": {
                "type": "getContratoResponseItem"
            }
        }
    },
    "getContratoResponseItem": {
        "id": "getContratoResponseItem",
        "properties": {
            "idContrato": {
                "type": "string"
            },
            "nmCliente": {
                "type": "string"
            },
            "dsPosicaoAtual": {
                "type": "string"
            }
        }
    }
};
