exports.models = {
    "getNotasDigitalizadasListItem": {
        "id": "getNotasDigitalizadasListItem",
        "properties": {
                     "dsContent": {
                          "type": "string",
                          "description": "Conteudo base64 da imagem.",
                          "required": true
                      },
					  "dsNome": {
                          "type": "string",
                          "description": "Nome do arquivo.",
                          "required": true
                      },
                      "idNotaDigitalizada": {
                          "type": "string",
                          "description": "Id da Nota Fiscal digitalizada",
                          "required": true
                      }
        }
      },




    "getNotasDigitalizadasResponse": {
        "id": "getNotasDigitalizadasResponse",
        "properties": {
                      "notasDigitalizadasList": {
                            "type": "array",
                            "items": {
                                "$ref": "getNotasDigitalizadasListItem"
                            },
                      "description": "Lista do Extrato Consolidado de Notas Fiscais.",
                      "required": true
                     }
        }
    }
};
