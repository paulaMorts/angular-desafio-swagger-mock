exports.models = {
          "getExtratoNotasFiscaisResponseItem": {
              "id": "getExtratoNotasFiscaisResponseItem",
              "properties": {
                  "idExtratoNotaFiscal": {
                      "type": "number",
                      "description": "Id do extrato da Nota Fiscal",
                      "required": false
                  },
                  "dtPeriodo": {
                      "type": "date",
                      "description": "Data do Período",
                      "required": false
                  },
                  "nrCNPJTomador": {
                      "type": "string",
                      "description": "Número CNPJ do Tomador",
                      "required": false
                  },
                  "nrCNPJBeneficiario": {
                      "type": "string",
                      "description": "Número CNPJ do Benficiário",
                      "required": false
                  },
                  "nrCpfCnpjCliente": {
                      "type": "string",
                      "description": "Número do CPF/CNPJ do cliente",
                      "required": false
                  },
                  "vlBrutoEmissaoNF": {
                      "type": "number",
                      "description": "Valor Bruto Emissão da Nota Fiscal",
                      "required": true
                  },
                  "dtLimiteEnvioNF": {
                      "type": "date",
                      "description": "Data Limite de Envio da Nota Fiscal",
                      "required": false
                  },
                  "dsStatus": {
                      "type": "string",
                      "description": "Status da Nota Fiscal (Nota Fiscal pendente de inclusão, Nota Fiscal em análise, Nota Fiscal irregular ,Nota Fiscal aprovada, aguardando documento físico ,Nota Fiscal aprovada, documento físico recebido, Nota Fiscal aprovada, documento físico irregular ,Nota Fiscal aprovada ,Contrato(s) estornado(s), Nota Fiscal enviada no mês anterior, Registro duplicado indevidamente)",
                      "required": false
                  }
              }
          },

          "getTotalExtratoNotasFiscaisStatusResponseItem": {
              "id": "getTotalExtratoNotasFiscaisStatusResponseItem",
              "properties": {
                  "idStatus": {
                      "type": "number",
                      "description": "Id do status do Extrato da Nota Fiscal",
                      "required": false
                  },
                  "dsStatus": {
                      "type": "string",
                      "description": "Descrição do status do Extrato da Nota Fiscal",
                      "required": false
                  },
                  "nrQtdTotalNF": {
                      "type": "number",
                      "description": "Quantidade Total de Notas Fiscais",
                      "required": false
                  }
              }
          },

          "getExtratoNotasFiscaisResponse": {
              "id": "getExtratoNotasFiscaisResponse",
              "properties": {
                  "extratoNotasFiscaisList": {
                      "type": "array",
                      "items": {
                          "$ref": "getExtratoNotasFiscaisResponseItem"
                      },
                      "description": "Lista de notas fiscais.",
                      "required": true
                  },

                      "totalExtratoNotasFiscaisStatusList": {
                          "type": "array",
                          "items": {
                              "$ref": "getTotalExtratoNotasFiscaisStatusResponseItem"
                          },
                          "description": "Lista com os totalizdores de Notas Ficais por Status.",
                          "required": true
                      }
              }
          }

};
