exports.models = {
    "getDetalheExtratoNotasFiscaisListItem": {
        "id": "getDetalheExtratoNotasFiscaisListItem",
        "properties": {
                      "idContrato": {
                          "type": "string",
                          "description": "Identificador do Contrato",
                          "required": false
                      },
                      "nrCpfCnpjCliente": {
                          "type": "string",
                          "description": "Número do CPF/CPNJ do cliente",
                          "required": false
                      },
                      "dsTipoComissao": {
                          "type": "string",
                          "description": "Descrição do tipo de comissão",
                          "required": false
                      },
                      "dtPagamento": {
                          "type": "date",
                          "description": "Data de Pagamento da comissão",
                          "required": false
                      },
                      "vlBrutoEmissaoNF": {
                          "type": "number",
                          "description": "Valor Bruto da Emissão da Nota Fiscal",
                          "required": false
                      },
                      "vlILA": {
                          "type": "number",
                          "description": "Valor ILA",
                          "required": false
                      },
                      "vlIR": {
                          "type": "number",
                          "description": "Valor IR",
                          "required": false
                      },
                      "vlISS": {
                          "type": "number",
                          "description": "Valor IR",
                          "required": false
                      },
                      "nrChassi": {
                          "type": "number",
                          "description": "Numero do Chassi",
                          "required": false
                      }
        }
    },

    
    "getExtratoNotasFiscaisResponse": {
        "id": "getExtratoNotasFiscaisResponse",
        "properties": {
                      "dtPeriodo": {
                          "type": "date",
                          "description": "Data do Periodo",
                          "required": false
                      },

                        "idStatus": {
                            "type": "number",
                            "description": "Identificador do Status do Extrato da Nota Fiscal",
                            "required": false
                      },

                          "dsStatus": {
                            "type": "string",
                            "description": "Descricao do Status do Extrato da Nota Fiscal",
                            "required": false
                      },

                        "vlBruto": {
                            "type": "number",
                            "description": "Valor Bruto do Extrato Consolidado de Notas Fiscais",
                            "required": false
                      },

                        "vlLiquido": {
                            "type": "number",
                            "description": "Valor Liquido do Extrato Consolidado de Notas Fiscais",
                            "required": false
                      },

                        "detalheExtratoNotasFiscaisList": {
                            "type": "array",
                            "items": {
                                "$ref": "getDetalheExtratoNotasFiscaisListItem"
                            },
                      "description": "Lista de Detalhes das Notas Fiscais do Extrato Consolidado de Notas Fiscais.",
                      "required": false
                     }
        }
    }
};
