exports.models = {
    "getListaStatusNotasFiscaisItem": {
        "id": "getListaStatusNotasFiscaisItem",
        "properties": {
                      "dsStatus": {
                          "type": "string",
                          "description": "Descrição do status da Nota Fiscal",
                          "required": true
                      },
                      "idStatus": {
                          "type": "string",
                          "description": "Id do status da Nota Fiscal",
                          "required": true
                      }
        }
    },
    "getListaStatusNotasFiscaisResponse": {
        "id": "getListaStatusNotasFiscaisResponse",
        "properties": {
            "statusNotasFiscaisList": {
                "type": "array",
                "items": {
                    "$ref": "getListaStatusNotasFiscaisItem"
                },
                "description": "Lista de status de notas fiscais.",
                "required": true
            }
        }
    }
};
