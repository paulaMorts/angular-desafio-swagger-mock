exports.models = {
    "faqNotaFiscalItem": {
        "id": "faqNotaFiscalItem",
        "properties": {
            "dsQuestao": {
                "type": "string"
            },
            "dsResposta": {
                "type": "string"
            }
        }
    },
    "getFaqNotaFiscalResponse": {
        "id": "getFaqNotaFiscalResponse",
        "properties": {
            "faqNotaFiscal": {
                "type": "array",
                "items": {
                    "$ref": "faqNotaFiscalItem"
                }
            }
        }
    }
};
