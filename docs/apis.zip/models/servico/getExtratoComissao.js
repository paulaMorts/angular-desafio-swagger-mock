exports.models = {
    "listaExtratoComissaoItem": {
        "id": "listaExtratoComissaoItem",
        "properties": {
            "idExtrato": {
                "type": "string"
            },
            "dtExtrato": {
                "type": "date"
            },
            "idFilial": {
                "type": "number"
            },
            "nrCnpjTomador": {
                "type": "string"
            },
            "vlBruto": {
                "type": "number"
            },
            "vlLiquido": {
                "type": "number"
            },
            "dsTipo": {
                "type": "string"
            },
            "idTipo": {
                "type": "string"
            },
            "cdTab": {
                "type": "number"
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "resumoExtratoComissaoItem": {
        "id": "resumoExtratoComissaoItem",
        "properties": {
            "vlBrutoTotal": {
                "type": "number"
            },
            "vlLiquidoTotal": {
                "type": "number"
            }
        }
    },
    "getExtratoComissaoResponse": {
        "id": "getExtratoComissaoResponse",
        "properties": {
            "listaExtratoComissao": {
                "type": "array",
                "items": {
                    "$ref": "listaExtratoComissaoItem"
                }
            },
            "resumoExtratoComissao": {
                "$ref": "resumoExtratoComissaoItem",
                "description": "Paginação",
                "required": true
            },
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            }
        }
    }
};
