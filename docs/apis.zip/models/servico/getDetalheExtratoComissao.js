exports.models = {
    "listaExtratoComissaoDetalheItem": {
        "id": "listaExtratoComissaoDetalheItem",
        "properties": {
            "idContrato": {
                "type": "string"
            },
            "nrCpfCnpj": {
                "type": "string"
            },
            "nrChassi": {
                "type": "string"
            },
            "vlLiquido": {
                "type": "number"
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "resumoExtratoComissaoDetalheItem": {
        "id": "resumoExtratoComissaoDetalheItem",
        "properties": {
            "dtInicial": {
                "type": "date"
            },
            "dtFinal": {
                "type": "date"
            },
            "vlLiquidoTotal": {
                "type": "number"
            }
        }
    },
    "getExtratoComissaoDetalheResponse": {
        "id": "getExtratoComissaoDetalheResponse",
        "properties": {
            "listaExtratoComissaoDetalhe": {
                "type": "array",
                "items": {
                    "$ref": "listaExtratoComissaoDetalheItem"
                }
            },
            "resumoExtratoComissaoDetalhe": {
                "$ref": "resumoExtratoComissaoDetalheItem"
            },
            "paginacao": {
                "$ref": "paginacaoItem"
            }
        }
    }
};
