exports.models = {
    "listaExtratoLiberacaoItem": {
        "id": "listaExtratoLiberacaoItem",
        "properties": {
            "idLiberacao": {
                "type": "string"
            },
            "dtLiberacao": {
                "type": "date"
            },
            "nmCliente": {
                "type": "string"
            },
            "nrCpfCnpj": {
                "type": "string"
            },
            "vlLiberado": {
                "type": "number"
            },
            "nmParticipante": {
                "type": "string"
            },
            "qtParcelas": {
                "type": "number"
            },
            "vlParcela": {
                "type": "number"
            },
            "dtPrimeiroVencimento": {
                "type": "date"
            },
            "cdAprovacao": {
                "type": "number"
            },
            "vlTC": {
                "type": "number"
            },
            "idFilial": {
                "type": "number"
            },
            "cdBordero": {
                "type": "number"
            },
            "dsModalidade": {
                "type": "string"
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "getExtratoLiberacaoResponse": {
        "id": "getExtratoLiberacaoResponse",
        "properties": {
            "listaExtratoLiberacao": {
                "type": "array",
                "items": {
                    "$ref": "listaExtratoLiberacaoItem"
                }
            },
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            },
            "dtAtualizacao": {
                "type":"date"
            }
        }
    }
};
