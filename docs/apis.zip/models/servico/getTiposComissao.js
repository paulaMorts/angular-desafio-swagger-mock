exports.models = {
    "tiposComissaoItem": {
        "id": "tiposComissaoItem",
        "properties": {
            "idTipo": {
                "type": "number"
            },
            "dsTipo": {
                "type": "string"
            }
        }
    },
    "getTiposComissaoResponse": {
        "id": "getTiposComissaoResponse",
        "properties": {
            "tiposComissao": {
                "type": "array",
                "items": {
                    "$ref": "tiposComissaoItem"
                }
            }
        }
    }
};
