exports.models = {
    "postEnviarComentarioNotaRequest": {
        "id": "postEnviarComentarioNotaRequest",
        "properties": {
            "comentario": {
                "type": "array",
                "items": {
                    "$ref": "enviarComentarioNotaItem"
                },
                "description": "Lista de comentários",
                "required": true
            }
        }
    },
    "enviarComentarioNotaItem": {
        "id": "enviarComentarioNotaItem",
        "properties" : {
            "idNotaFiscal": {
                "type": "number",
                "description": "Número da nota fiscal sendo comentada",
                "required": true
            },
            "dsComentario": {
                "type": "string",
                "description": "Texto do comentário sendo enviado",
                "required": true
            }
        }
    }
};