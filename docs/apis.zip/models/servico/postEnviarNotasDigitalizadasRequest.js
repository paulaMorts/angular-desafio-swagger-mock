exports.models = {
    "postEnviarNotasDigitalizadasRequest": {
        "id": "postEnviarNotasDigitalizadasRequest",
        "properties": {
            "notasFiscaisDigitalizadas": {
                "type": "array",
                "items": {
                    "$ref": "notasFiscaisDigitalizadasItem"
                },
                "description": "Lista de notas fiscais digitalizadas",
                "required": true
            }
        }
    },
    "notasFiscaisDigitalizadasItem": {
        "id": "notasFiscaisDigitalizadasItem",
        "properties" : {
            "dsConteudo": {
                "type": "string",
                "description": "Conteúdo base64 da nota fiscal",
                "required": false
            },
			"dsNome": {
                "type": "string",
                "description": "Nome do arquivo sendo carregado",
                "required": true
            },
            "dsLink": {
                "type": "string",
                "description": "Link para arquivo sendo carregado",
                "required": false
            }
        }
    }
};