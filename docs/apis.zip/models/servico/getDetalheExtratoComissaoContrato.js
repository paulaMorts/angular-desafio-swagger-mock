exports.models = {
    "extratoComissaoDetalheContratoItem": {
        "id": "extratoComissaoDetalheContratoItem",
        "properties": {
            "contrato": {
                "$ref": "extratoComissaoContratoItem"
            },
            "dadosCliente": {
                "$ref": "dadosClienteContratoItem"
            },
            "acordo": {
                "$ref": "acordoContratoItem"
            }
        }
    },
    "acordoContratoItem": {
        "id": "acordoContratoItem",
        "properties": {
            "nrAcordo": {
                "type": "string"
            },
            "dsTipoComissao": {
                "type": "string"
            },
            "vlBruto": {
                "type": "number"
            },
            "vlIR": {
                "type": "number"
            },
            "vlISS": {
                "type": "number"
            },
            "pcIla": {
                "type": "number"
            },
            "vlIla": {
                "type": "number"
            }
        }
    },
    "dadosClienteContratoItem": {
        "id": "dadosClienteContratoItem",
        "properties": {
            "nrCpfCnpj": {
                "type": "string"
            },
            "nmCliente": {
                "type": "string"
            },
            "nrChassi": {
                "type": "string"
            }
        }
    },
    "extratoComissaoContratoItem": {
        "id": "extratoComissaoContratoItem",
        "properties": {
            "idContrato": {
                "type": "string"
            },
            "vlLiquido": {
                "type": "number"
            },
            "dtEmissao": {
                "type": "date"
            },
            "dtLiberacao": {
                "type": "date"
            },
            "dtPagamento": {
                "type": "date"
            }
        }
    },
    "resumoExtratoComissaoContratoDetalheItem": {
        "id": "resumoExtratoComissaoContratoDetalheItem",
        "properties": {
            "dtInicial": {
                "type": "date"
            },
            "dtFinal": {
                "type": "date"
            },
            "vlLiquidoTotal": {
                "type": "number"
            }
        }
    },
    "getExtratoComissaoDetalheContratoResponse": {
        "id": "getExtratoComissaoDetalheContratoResponse",
        "properties": {
            "extratoComissaoDetalheContrato": {
                "$ref": "extratoComissaoDetalheContratoItem"
            },
            "resumoExtratoComissaoContratoDetalheItem": {
                "$ref": "resumoExtratoComissaoContratoDetalheItem"
            }
        }
    }
};
