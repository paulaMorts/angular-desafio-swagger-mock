exports.models = {
    "getComentariosListItem": {
        "id": "getComentariosListItem",
        "properties": {
                      "dtComentario": {
                          "type": "date",
                          "description": "Data do Comentário",
                          "required": false
                      },
                      "dsComentario": {
                          "type": "string",
                          "description": "Descrição do Comentário",
                          "required": false
                      }
        }
    },

    "getComentariosNotasFiscaisResponse": {
        "id": "getComentariosNotasFiscaisResponse",
        "properties": {
                    "comentariosList": {
                           "type": "array",
                           "items": {
                               "$ref": "getComentariosListItem"
                           },
                     "description": "Lista de Comentários das Notas Fiscais do Extrato Consolidado de Notas Fiscais.",
                     "required": false
                    }
        }
    }
};
