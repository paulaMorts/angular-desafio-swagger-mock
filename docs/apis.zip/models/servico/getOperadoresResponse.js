exports.models = {
	"operadorItem": {
		"id": "operadorItem",
		"properties": {
            "dsNome": {
                "type": "string"
            }
		}
	},
    "tabItem": {
        "id": "tabItem",
        "properties": {
            "dsNome": {
                "type": "string"
            },
            "listaOperadores": {
                "type": "array",
				"items": {
					"$ref": "operadorItem"
				}
            }
        }
    },
    "getOperadoresResponse": {
        "id": "getOperadoresResponse",
        "properties": {
            "tabs": {
                "type": "array",
                "items": {
                    "$ref": "tabItem"
                }
            }
        }
    }
};
