exports.models = {
    "postEnviarNotasDigitalizadasResponse": {
        "id": "postEnviarNotasDigitalizadasResponse",
        "properties": {
            "retorno": {
                "$ref": "enviarNotasDIgitalizadasResponseItem",
                "description": "Mensagem ok",
                "required": true
            }
        }
    },
    "enviarNotasDIgitalizadasResponseItem": {
        "id": "enviarNotasDIgitalizadasResponseItem",
        "properties" : {
            "dsMensagem": {
                "type": "string",
                "description": "Retorno",
                "required": true
            }
        }
    }
};