exports.models = {
    "getCompraCertaResponse": {
        "id": "getCompraCertaResponse",
        "properties": {
            "PCP": {
                "$ref": "compraCertaResponseItem",
                "description": "Objeto contendo o conteúdo base64 do compra certa",
                "required": true
            }
        }
    },
    "compraCertaResponseItem": {
        "id": "compraCertaResponseItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Conteúdo base64 do arquivo do compra certa",
                "required": true
            }
        }
    }
};