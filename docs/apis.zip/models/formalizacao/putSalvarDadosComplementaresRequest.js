exports.models = {
    "salvarDadosComplementaresRequestItem": {
        "id": "salvarDadosComplementaresRequestItem",
        "properties": {
            "idUfLicenca": {
                "type": "string",
                "description": "UF da placa do veículo",
                "required": true
            },
            "numeroChassi": {
                "type": "string",
                "description": "Chassi do veiculo",
                "required": true
            },
            "confirmarChassi": {
                "type": "string",
                "description": "Confirmação do chassi do veiculo"
            },
            "descricaoCor": {
                "type": "string",
                "description": "Cod do veículo",
                "required": true
            },
            "numeroRenavam": {
                "type": "number",
                "description": "Número do Renavam do veículo",
                "required": true
            },
            "numeroPlaca": {
                "type": "string",
                "description": "Placa do veículo",
                "required": true
            },
            "idSituacaoLataria": {
                "type": "number",
                "description": "Identificador da situação da lataria do veículo",
                "required": true
            },
            "idSituacaoTapecaria": {
                "type": "number",
                "description": "Identificador da situação da tapeçaria do veículo",
                "required": true
            },
            "idSituacaoPintura": {
                "type": "number",
                "description": "Identificador da situação da pintura do veículo",
                "required": true
            },
            "idSituacaoPneu": {
                "type": "number",
                "description": "Identificador da situação dos pneus do veículo",
                "required": true
            }
        }
    },
    "putSalvarDadosComplementaresRequest": {
        "id": "putSalvarDadosComplementaresRequest",
        "properties": {
            "dadosComplementares": {
                "$ref": "salvarDadosComplementaresRequestItem",
                "description": "Dados que serão salvos",
                "required": true
            }
        }
    }
};