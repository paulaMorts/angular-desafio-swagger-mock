exports.models = {
    "enviarFormalizacaoRequestItem": {
        "id": "enviarFormalizacaoRequestItem",
        "properties": {
            "cdTipoConta": {
                "type": "number",
                "description": "Identificador da conta corrente",
                "required": true
            },
            "fgContaPrincipal": {
                "type": "boolean",
                "description": "Flag que identifica se a conta é a principal",
                "required": true
            },
            "nrAgencia": {
                "type": "number",
                "description": "Número da agência da conta corrente",
                "required": true
            },
            "nrBanco": {
                "type": "number",
                "description": "Nome do banco a qual a conta pertence",
                "required": true
            },
            "nrBancoCompensacao": {
                "type": "number",
                "description": "Nome do banco de compensação",
                "required": true
            },
            "nrConta": {
                "type": "number",
                "description": "Número da conta corrente",
                "required": true
            },
            "nrDigitoAgencia": {
                "type": "number",
                "description": "Dígito verificador da agência",
                "required": true
            },
            "nrDigitoConta": {
                "type": "number",
                "description": "Dígito verificador da conta corrente",
                "required": true
            },
			"idProposta": {
				"type": "string",
                "description": "Identificador da proposta",
                "required": true
			},
            "idTabCompartilhada": {
				"type": "string",
                "description": "Id da tab para compartilhamento do pagamento.",
                "required": true
			}
            
        }
    },
    "postEnviarFormalizacaoRequest": {
        "id": "postEnviarFormalizacaoRequest",
        "properties": {
            "contaCorrente": {
                "$ref": "enviarFormalizacaoRequestItem",
                "description": "Dados que serão salvos",
                "required": true
            }
        }
    }
};