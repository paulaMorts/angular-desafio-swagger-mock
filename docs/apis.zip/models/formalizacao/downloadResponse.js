exports.models = {
    "downloadResponse": {
        "id": "downloadResponse",
        "properties": {
            "file": {
                "$ref": "downloadItem",
                "description": "Arquivo baixado",
                "required": true
            }
        }
    },
    "downloadItem": {
        "id": "downloadItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Conteúdo base64 do arquivo do contrato de financiamento",
                "required": true
            },
            "nmFile": {
                "type": "string",
                "description": "Nome do arquivo baixado",
                "required": true
            }
        }
    }
};