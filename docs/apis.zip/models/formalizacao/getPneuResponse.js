exports.models = {
    "listaSituacaoPneuItem": {
        "id": "listaSituacaoPneuItem",
        "properties": {
            "idSitPneu": {
                "type": "number",
                "description": "Identificador da situação da pneus",
                "required": true
            },
            "dsSitPneu": {
                "type": "string",
                "description": "Descrição da situação da pneus",
                "required": true
            }
        }
    },
    "getPneuResponse": {
        "id": "getPneuResponse",
        "properties": {
            "listaSituacaoPneu": {
                "type": "array",
                "items": {
                    "$ref": "listaSituacaoPneuItem"
                },
                "description": "Lista de situações de pneus",
                "required": true
            }
        }
    }
};