exports.models = {
    "listaSituacaoPinturaItem": {
        "id": "listaSituacaoPinturaItem",
        "properties": {
            "idSitPintura": {
                "type": "number",
                "description": "Identificador da situação da pintura",
                "required": true
            },
            "dsSitPintura": {
                "type": "string",
                "description": "Descrição da situação da pintura",
                "required": true
            }
        }
    },
    "getPinturaResponse": {
        "id": "getPinturaResponse",
        "properties": {
            "listaSituacaoPintura": {
                "type": "array",
                "items": {
                    "$ref": "listaSituacaoPinturaItem"
                },
                "description": "Lista de situações de pinturas",
                "required": true
            }
        }
    }
};