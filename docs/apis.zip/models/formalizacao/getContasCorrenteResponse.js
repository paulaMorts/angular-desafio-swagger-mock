exports.models = {
    "contaCorrenteItem": {
        "id": "contaCorrenteItem",
        "properties": {
            "cdTipoConta": {
                "type": "number",
                "description": "Identificador da conta corrente",
                "required": true
            },
            "fgContaPrincipal": {
                "type": "boolean",
                "description": "Flag que identifica se a conta é a principal",
                "required": true
            },
            "nrAgencia": {
                "type": "number",
                "description": "Número da agência da conta corrente",
                "required": true
            },
            "nrBanco": {
                "type": "number",
                "description": "Nome do banco a qual a conta pertence",
                "required": true
            },
			"dsNomeBanco": {
                "type": "string",
                "description": "Nome do banco",
                "required": true
            },
            "nrBancoCompensacao": {
                "type": "number",
                "description": "Nome do banco de compensação",
                "required": true
            },
            "nrConta": {
                "type": "number",
                "description": "Número da conta corrente",
                "required": true
            },
            "nrDigitoAgencia": {
                "type": "number",
                "description": "Dígito verificador da agência",
                "required": true
            },
            "nrDigitoConta": {
                "type": "number",
                "description": "Dígito verificador da conta corrente",
                "required": true
            }
        }
    },
    "boletoObj": {
        "id": "boletoObj",
        "properties": {
            "exibeFlagBoleto": {
                "type": "string",
                "description": "Flag para exibição de boleto",
                "required": true
            }
        }
    },
    "getContasCorrenteResponse": {
        "id": "getContasCorrenteResponse",
        "properties": {
            "contasCorrentes": {
                "type": "array",
                "items": {
                    "$ref": "contaCorrenteItem"
                },
                "description": "Lista de contas correntes para pagamento",
                "required": true
            },
            "boleto": {
                "$ref": "boletoObj",
                "description": "Boleto de pagamento",
                "required": true
            },
            "fgPagamentoCompartilhado": {
                "type": "string",
                "description": "Flag para habilitação do pagamento compartilhado com outras tabs.",
                "enum": ["S", "N"],
                "required": true
            },
            "tabsCompartilhadas": {
                "type": "array",
                "items": {
                    "$ref": "tabsCompartilhadasItem"
                },
                "description": "Lista de tabs que podem receber o pagamento compartilhado.",
                "required": true
            }
            
        }
    },
    "tabsCompartilhadasItem": {
        "id": "tabsCompartilhadasItem",
        "properties": {
            "cdTab": {
                "type": "string",
                "description": "Código da Loja",
                "required": true
            },
            "dsTab": {
                "type": "string",
                "description": "Nome da Loja",
                "required": true
            }
        }
    }
};