exports.models = {
    "checklistItem": {
        "id": "checklistItem",
        "properties": {
            "idChecklist": {
                "type": "number",
                "description": "Identificador do item do checklist.",
                "required": true
            },
            "nmDocumento": {
                "type": "string",
                "description": "Nome do documento.",
                "required": true
            },
            "dsOrientacao": {
                "type": "string",
                "description": "Orientação para upload do documento",
                "required": true
            },
            "fgIndexado": {
                "type": "boolean",
                "description": "Flag que identifica se o documento já foi indexado.",
                "required": true
            },
            "tipoDocumento": {
                "type": "string",
                "description": "Tipo do documento",
                "required": true
            },
            "tipoCaptura": {
                "$ref": "tipoCapturaItem"
            },
            "fgRequired": {
                "type": "boolean",
                "description": "Flag que identifica se o documento é requerido.",
                "required": true
            },
            "dataAtualizacao": {
                "type": "boolean",
                "description": "Data da atualização do documento.",
                "required": true
            }
        }
    },
    "tipoCapturaItem":{
        "id": "tipoCapturaItem",
        "properties": {
            "altura": {
                "type": "number",
                "description": "Altura em pixels que a imagem deverá ter levando em consideração a orientação.",
                "required": true
            },
            "largura": {
                "type": "number",
                "description": "Largura em pixels que a imagem deverá ter levando em consideração a orientação",
                "required": true
            },
            "qualidade": {
                "type": "number",
                "description": "Taxa de compressão a ser aplicada.",
                "required": true
            },
            "orientacao": {
                "type": "string",
                "description": "A orientação da imagem. A orientação da imagem. “L” para landscape, “P” para portrait.",
                "required": true
            }
        }
    },
    "boletoslistItem": {
        "id": "boletoslistItem",
        "properties": {
            "idChecklist": {
                "type": "number",
                "description": "Identificador do item do checklist.",
                "required": true
            },
            "nmDocumento": {
                "type": "string",
                "description": "Nome do documento.",
                "required": true
            },
            "dsOrientacao": {
                "type": "string",
                "description": "Orientação para upload do documento",
                "required": true
            },
            "fgIndexado": {
                "type": "boolean",
                "description": "Flag que identifica se o documento já foi indexado.",
                "required": true
            }
        }
    },
    "getChecklistResponse": {
        "id": "getChecklistResponse",
        "properties": {
            "checklist": {
                "type": "array",
                "items": {
                    "$ref": "checklistItem"
                },
                "description": "Lista de documentos para checklist de documentos",
                "required": true
            },
            "boletos": {
                "type": "array",
                "items": {
                    "$ref": "boletoslistItem"
                },
                "description": "Lista de documentos para checklist de boletos",
                "required": true
            }
        }
    }
};
