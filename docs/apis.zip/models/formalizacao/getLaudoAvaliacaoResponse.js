exports.models = {
    "getLaudoAvaliacaoResponse": {
        "id": "getLaudoAvaliacaoResponse",
        "properties": {
            "LaudoAvaliacao": {
                "$ref": "laudoAvaliacaoResponseItem",
                "description": "Objeto contendo o conteúdo base64 do laudo de avaliacao",
                "required": true
            }
        }
    },
    "laudoAvaliacaoResponseItem": {
        "id": "laudoAvaliacaoResponseItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Conteúdo base64 do arquivo do laudo de avaliacao",
                "required": true
            }
        }
    }
};