exports.models = {
    "getContratoFinanciamentoResponse": {
        "id": "getContratoFinanciamentoResponse",
        "properties": {
            "CCB": {
                "$ref": "contratoFinanciamentoResponseItem",
                "description": "Objeto contendo o conteúdo base64 do contrato de financiamento",
                "required": true
            }
        }
    },
    "contratoFinanciamentoResponseItem": {
        "id": "contratoFinanciamentoResponseItem",
        "properties": {
            "bsContent": {
                "type": "string",
                "description": "Conteúdo base64 do arquivo do contrato de financiamento",
                "required": true
            }
        }
    }
};