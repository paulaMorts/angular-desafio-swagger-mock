exports.models = {
    "postChecklistPendenteResponse": {
        "id": "postChecklistPendenteResponse",
        "properties": {
            "retorno": {
                "$ref": "postChecklistPendenteResponseItem",
                "description": "Retorno do envio dos documentos de checklist",
                "required": true
            }
        }
    },
    "postChecklistPendenteResponseItem": {
        "id": "postChecklistPendenteResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Mensagem de retorno",
                "required": true
            }
        }
    }
};