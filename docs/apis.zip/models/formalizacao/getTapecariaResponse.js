exports.models = {
    "listaSituacaoTapecariaItem": {
        "id": "listaSituacaoTapecariaItem",
        "properties": {
            "idSitTapecaria": {
                "type": "number",
                "description": "Identificador da situação da tapeçaria",
                "required": true
            },
            "dsSitTapecaria": {
                "type": "string",
                "description": "Descrição da situação da tapeçaria",
                "required": true
            }
        }
    },
    "getTapecariaResponse": {
        "id": "getTapecariaResponse",
        "properties": {
            "listaSituacaoTapecaria": {
                "type": "array",
                "items": {
                    "$ref": "listaSituacaoTapecariaItem"
                },
                "description": "Lista de situações de tapeçarias",
                "required": true
            }
        }
    }
};