exports.models = {
    "getFlagBoletosResponseItem": {
        "id": "getFlagBoletosResponseItem",
        "properties": {
            "flagBoletoTc": {
                "type": "string",
                "description": "Flag de Boleto TC",
                "required": true
            },
            "flagBoletoTab": {
                "type": "string",
                "description": "Flag de Boleto TAB",
                "required": true
            }
        }
    },
    "getFlagBoletosResponse": {
        "id": "getFlagBoletosResponse",
        "properties": {
            "retorno": {
                "$ref": "getFlagBoletosResponseItem",
                "description": "Retorno de Flags de boleto TC e TAB",
                "required": true
            }
        }
    }
};
