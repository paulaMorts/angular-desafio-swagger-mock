exports.models = {
    "postEnviarFormalizacaoResponse": {
        "id": "postEnviarFormalizacaoResponse",
        "properties": {
            "retorno": {
                "$ref": "enviarFormalizacaoResponseItem",
                "description": "Retorno do envio dos dados de formalização",
                "required": true
            }
        }
    },
    "enviarFormalizacaoResponseItem": {
        "id": "enviarFormalizacaoResponseItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Mensagem de retorno",
                "required": true
            }
        }
    }
};