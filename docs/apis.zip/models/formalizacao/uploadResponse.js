exports.models = {
    "uploadResponse": {
        "id": "uploadResponse",
        "properties": {
            "retorno": {
                "$ref": "uploadItem",
                "description": "Retorno do upload de um arquivo",
                "required": true
            }
        }
    },
    "uploadItem": {
        "id": "uploadItem",
        "properties": {
            "dsMensagem": {
                "type": "string",
                "description": "Mensagem de retorno",
                "required": true
            }
        }
    }
};