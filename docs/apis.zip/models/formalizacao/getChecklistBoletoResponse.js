exports.models = {
    "checklistBoletoItem": {
        "id": "checklistBoletoItem",
        "properties": {
            "idChecklist": {
                "type": "number",
                "description": "Identificador do item do checklist.",
                "required": true
            },
            "nmDocumento": {
                "type": "string",
                "description": "Nome do documento.",
                "required": true
            },
            "dsOrientacao": {
                "type": "string",
                "description": "Orientação para upload do documento",
                "required": true
            },
            "fgIndexado": {
                "type": "boolean",
                "description": "Flag que identifica se o documento já foi indexado.",
                "required": true
            }
        }
    },
    "getChecklistBoletoResponse": {
        "id": "getChecklistBoletoResponse",
        "properties": {
            "checklist": {
                "type": "array",
                "items": {
                    "$ref": "checklistBoletoItem"
                },
                "description": "Lista de documentos para checklist de boletos",
                "required": true
            }
        }
    }
};