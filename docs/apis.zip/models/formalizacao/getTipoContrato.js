exports.models = {
    "getTipoContratoResponse": {
        "id": "getTipoContratoResponse",
        "properties": {
            "tipoContrato": {
                "type": "string"
            },
            "boleto" : {
                "type": "boolean"
            }
        }
    }
};