exports.models = {
    "listaSituacaoLatariaItem": {
        "id": "listaSituacaoLatariaItem",
        "properties": {
            "idSitLataria": {
                "type": "number",
                "description": "Identificador da situação da lataria",
                "required": true
            },
            "dsSitLataria": {
                "type": "string",
                "description": "Descrição da situação da lataria",
                "required": true
            }
        }
    },
    "getLatariasResponse": {
        "id": "getLatariasResponse",
        "properties": {
            "listaSituacaoLataria": {
                "type": "array",
                "items": {
                    "$ref": "listaSituacaoLatariaItem"
                },
                "description": "Lista de situações de latarias",
                "required": true
            }
        }
    }
};