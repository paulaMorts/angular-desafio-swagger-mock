exports.models = {
    "putSalvarDadosComplementaresResponse": {
        "id": "putSalvarDadosComplementaresResponse",
		"properties": {
            "veiculo": {
                "$ref": "salvarDadosComplementaresResponseItem",
                "description": "Veículo sendo atualizado",
                "required": true
            }
        }
    },
	"salvarDadosComplementaresResponseItem": {
		"id": "salvarDadosComplementaresResponseItem",
		"properties": {
            "idVeiculo": {
                "type": "number",
                "description": "Identificador do veículo atualizado",
                "required": true
            },
            "cdErro": {
                "type": "number",
                "description": "Código da mensagem de erro durante a atualização"
            },
            "dsMensagem": {
                "type": "string",
                "description": "Descrição da mensagem de erro durante a atualização"
            }
        }
	}
};