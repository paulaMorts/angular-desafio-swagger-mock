exports.models = {
    "uploadRequest": {
        "id": "uploadRequest",
        "properties": {
            "documento": {
                "$ref": "uploadRequestDocumento",
                "description": "Informações de negócio relacionadas ao arquivo sendo carregado",
                "required": true
            },
            "file": {
                "$ref": "uploadRequestFile",
                "description": "Metadados do arquivo sendo carregado",
                "required": true
            }
        }
    },
    "uploadRequestDocumento": {
        "id": "uploadRequestDocumento",
        "properties": {
            "idCheckList": {
                "type": "number",
                "description": "Identificador do artefato sendo carregado",
                "required": true
            }
        }
    },
    "uploadRequestFile": {
        "id": "uploadRequestFile",
        "properties": {
            "content": {
                "type": "string",
                "description": "Conteúdo base64 do arquivo sendo carregado.",
                "required": true
            },
            "contentType": {
                "type": "string",
                "description": "Content Type do arquivo sendo carregado.",
                "required": true
            },
            "fileName": {
                "type": "string",
                "description": "Nome do arquivo sendo carregado.",
                "required": true
            }
        }
    }
};