exports.models = {
    "propostasFIItem": {
        "id": "propostasFIItem",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Id da Proposta",
                "required": true
            },
            "dtInclusao": {
                "type": "date",
                "description": "Data da Inclusão",
                "required": true
            },
            "nmCliente": {
                "type": "string",
                "description": "Nome do Cliente",
                "required": true
            },
            "nrCpfCnpj": {
                "type": "number",
                "description": "Número do CPF/CNPJ",
                "required": true
            },
            "vlVeiculo": {
                "type": "double",
                "description": "Valor do Veículo",
                "required": true
            },
            "dsMarca": {
                "type": "string",
                "description": "Descrição da Marca",
                "required": true
            },
            "dsModelo": {
                "type": "string",
                "description": "Descrição do Modelo",
                "required": true
            },
            "dsStatus": {
                "type": "string",
                "description": "Descrição do Status",
                "required": true
            }
        }
    },
    "listarFIResponse": {
        "id": "listarFIResponse",
        "properties": {
            "propostasFI": {
                "type": "array",
                "items": {
                    "$ref": "propostasFIItem"
                },
                "description": "Lista de propostas FI.",
                "required": true
            }
        }
    }
};
