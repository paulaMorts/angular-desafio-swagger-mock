exports.models = {
    "verificarAgenteCertificadoItem": {
        "id": "verificarAgenteCertificadoItem",
        "properties": {
            "msgAlerta": {
                "type": "string",
                "description": "Mensagem de validação do agente certificado.",
                "required": true
            }
        }
    },
    "getVerificarAgenteCertificado": {
        "id": "getVerificarAgenteCertificado",
        "properties": {
            "verificaAgentCertificador": {
                "$ref": "verificarAgenteCertificadoItem",
                "items": {
                    "$ref": "listaLojasItem"
                },
                "description": "Validação do agente certificado.",
                "required": false
            }
        }
    }
};
