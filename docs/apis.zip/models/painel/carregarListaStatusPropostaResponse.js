exports.models = {
    "listaStatusPropostaItem": {
        "id": "listaStatusPropostaItem",
        "properties": {
            "dsStatus": {
                "type": "string",
                "description": "Descrição do status da proposta",
                "required": true
            },
            "idStatus": {
                "type": "string",
                "description": "Id do status da proposta",
                "required": true
            }
        }
    },
    "carregarListaStatusPropostaResponse": {
        "id": "carregarListaStatusPropostaResponse",
        "properties": {
            "statusProposta": {
                "type": "array",
                "items": {
                    "$ref": "listaStatusPropostaItem"
                },
                "description": "Lista de status de uma proposta.",
                "required": true
            }
        }
    }
};
