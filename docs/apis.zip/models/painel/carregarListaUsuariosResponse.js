exports.models = {
    "listaUsuariosItem": {
        "id": "listaUsuariosItem",
        "properties": {
            "idUsuario": {
                "type": "string",
                "description": "Id do Usuário",
                "required": true
            },
            "dsUsuario": {
                "type": "string",
                "description": "Descrição do Usuário",
                "required": true
            }
        }
    },
    "carregarListaUsuariosResponse": {
        "id": "carregarListaUsuariosResponse",
        "properties": {
            "usuarios": {
                "type": "array",
                "items": {
                    "$ref": "listaUsuariosItem"
                },
                "description": "Lista de usuários.",
                "required": true
            }
        }
    }
};
