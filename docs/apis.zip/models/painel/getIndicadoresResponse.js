exports.models = {
    "getIndicadoresResponse": {
        "id": "getIndicadoresResponse",
        "properties": {
            "dashboard": {
                "$ref": "dashboardItem",
                "description": "Detalhes de indicadores do dashboard de propostas",
                "required": true
            }
        }
    },
    "dashboardItem": {
        "id": "dashboardItem",
        "properties": {
            "propostas": {
                "type": "array",
                "items": {
                    "$ref": "indicadorItem"
                },
                "description": "Lista de indicadores de propostas",
                "required": true
            },
            "pendencias": {
                "type": "array",
                "items": {
                    "$ref": "indicadorItem"
                },
                "description": "Lista de indicadores de propostas",
                "required": true
            }
        }
    },
    "indicadorItem": {
        "id": "indicadorItem",
        "properties": {
            "id": {
                "type": "number",
                "description": "Identificador do indicador",
                "required": true
            },
            "nome": {
                "type": "string",
                "description": "Nome do indicador",
                "required": true
            },
            "valor": {
                "type": "number",
                "description": "Valor do indicador",
                "required": true
            }
        }
    }
};
