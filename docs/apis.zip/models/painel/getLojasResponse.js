exports.models = {
    "listaLojasItem": {
        "id": "listaLojasItem",
        "properties": {
            "cdTab": {
                "type": "number",
                "description": "Código da Loja",
                "required": true
            },
            "nmLoja": {
                "type": "string",
                "description": "Nome da Loja",
                "required": true
            }
        }
    },
    "getLojasResponse": {
        "id": "getLojasResponse",
        "properties": {
            "listaLojas": {
                "type": "array",
                "items": {
                    "$ref": "listaLojasItem"
                },
                "description": "Lista de lojas do usuário.",
                "required": true
            }
        }
    }
};
