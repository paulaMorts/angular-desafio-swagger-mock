exports.models = {
    "propostasItem": {
        "id": "propostasItem",
        "properties": {
            "idProposta": {
                "type": "number",
                "description": "Id da Proposta",
                "required": true
            },
            "dtInclusao": {
                "type": "date",
                "description": "Data da Inclusão",
                "required": true
            },
            "nmCliente": {
                "type": "string",
                "description": "Nome do Cliente",
                "required": true
            },
            "nrCpfCnpj": {
                "type": "number",
                "description": "Número do CPF/CNPJ",
                "required": true
            },
            "vlVeiculo": {
                "type": "double",
                "description": "Valor do Veículo",
                "required": true
            },
            "dsMarca": {
                "type": "string",
                "description": "Descrição da Marca",
                "required": true
            },
            "dsModelo": {
                "type": "string",
                "description": "Descrição do Modelo",
                "required": true
            },
            "dsStatus": {
                "type": "string",
                "description": "Descrição do Status",
                "required": true
            }
        }
    },
    "paginacaoItem": {
        "id": "paginacaoItem",
        "properties": {
            "nrPagina": {
                "type": "number",
                "description": "Número da Página",
                "required": true
            },
            "qtItens": {
                "type": "number",
                "description": "Quantidade total de Itens",
                "required": true
            },
            "qtResultados": {
                "type": "number",
                "description": "Quantidade de Resultados",
                "required": true
            },
            "qtPaginas": {
                "type": "number",
                "description": "Quantidade de Páginas",
                "required": true
            }
        }
    },
    "listarResponse": {
        "id": "listarResponse",
        "properties": {
            "propostas": {
                "type": "array",
                "items": {
                    "$ref": "propostasItem"
                },
                "description": "Lista de propostas.",
                "required": true
            },
            "paginacao": {
                "$ref": "paginacaoItem",
                "description": "Paginação",
                "required": true
            }
        }
    }
};
