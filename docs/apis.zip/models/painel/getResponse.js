exports.models = {
    "dadosBasicosPropostaItem":{
        "id":"dadosBasicosPropostaItem",
        "properties":{
            "cdAprovacao":{
                "type":"number",
                "description":"Código da Aprovação",
                "required":true
            },
            "cdSeguradora":{
                "type":"number",
                "description":"Código da Seguradora",
                "required":true
            },
            "cdSeguro":{
                "type":"number",
                "description":"Código do Seguro",
                "required":true
            },
            "nrCetAno":{
                "type":"string",
                "description":"Número da Taxa de Custo Efetivo Total/Ano",
                "required":true
            },
			"dsProduto":{
                "type":"string",
                "description":"Nome do produto",
                "required":true
            },
            "nrCetMes":{
                "type":"string",
                "description":"Número da Taxa de Custo Efetivo Total/Mês",
                "required":true
            },
            "nrCnpjLojista":{
                "type":"string",
                "description":"Número do CNPJ do Lojista",
                "required":true
            },
            "nrCnpjSeguradora":{
                "type":"string",
                "description":"Número do CNPJ da Seguradora",
                "required":true
            },
            "cdComissao":{
                "type":"string",
                "description":"Código da Comissão",
                "required":true
            },
            "cdFormaPagamento":{
                "type":"string",
                "description":"Código da Forma de Pagamento",
                "required":true
            },
            "cdModalidade":{
                "type":"string",
                "description":"Código da Modalidade",
                "required":true
            },
            "cdOriginacao":{
                "type":"string",
                "description":"Código da Originação",
                "required":true
            },
            "cdStatus":{
                "type":"string",
                "description":"Código do Status",
                "required":true
            },
            "cdTelefoneLoja":{
                "type":"string",
                "description":"Código do Telefone da Loja",
                "required":true
            },
            "cdTipoMoeda":{
                "type":"number",
                "description":"Código do Tipo de Moeda",
                "required":true
            },
            "nrCpfCnpjFornecedor":{
                "type":"string",
                "description":"Número do CPF/CNPJ do Fornecedor",
                "required":true
            },
            "dtEntregaBem":{
                "type":"date",
                "description":"Data de Entrega do Bem",
                "required":true
            },
            "dtTermino":{
                "type":"date",
                "description":"Data de Término",
                "required":true
            },
            "dtVencimento1":{
                "type":"date",
                "description":"Data de Vencimento",
                "required":true
            },
            "dsLojista":{
                "type":"string",
                "description":"Descrição do Lojista",
                "required":true
            },
            "dsStatus":{
                "type":"string",
                "description":"Descrição do Status",
                "required":true
            },
            "dsDespServicosTerceiros":{
                "type":"string",
                "description":"Descrição de Despesas de Serviços de terceiros",
                "required":true
            },
            "fgIndicativoImpCarne":{
                "type":"string",
                "description":"Flag de Indicativo de Impressão de Carnê",
                "required":true
            },
            "fgIndicativoIsencaoTC":{
                "type":"string",
                "description":"Flag de Indicativo de Taxa de Cadastro",
                "required":true
            },
            "fgIndicativoIsencaoTab":{
                "type":"string",
                "description":"Flag de Indicativo de Isenção da Taxa de Avaliação do Bem",
                "required":true
            },
            "fgIndicativoTabAVista":{
                "type":"string",
                "description":"Flag de Indicativo de Taxa de Avaliação do Bem à Vista",
                "required":true
            },
            "fgIndicativoTac":{
                "type":"string",
                "description":"Flag de Indicativo de Tac",
                //tac??
                "required":true
            },
            "fgIndicativoTcAVista":{
                "type":"string",
                "description":"Flag de Indicativo de Taxa de Cadastro à Vista",
                "required":true
            },
            "nmSeguradora":{
                "type":"string",
                "description":"Nome da Seguradora",
                "required":true
            },
            "nmSeguro":{
                "type":"string",
                "description":"Nome do Seguro",
                "required":true
            },
            "nmFornecedor":{
                "type":"string",
                "description":"Nome do Fornecedor",
                "required":true
            },
            "nmVendedor":{
                "type":"string",
                "description":"Nome do Vendedor",
                "required":true
            },
            "fgNovo":{
                "type":"string",
                "description":"Flag de Veículo Novo",
                "required":true
            },
            "nrDddLoja":{
                "type":"string",
                "description":"Número do DDD da Loja",
                "required":true
            },
            "nrEmpresa2":{
                "type":"string",
                "description":"Número da Empresa",
                "required":true
            },
            "nrIdCanalCaptura":{
                "type":"number",
                "description":"Número do Id do Canal de Captura",
                "required":true
            },
            "nrIdProduto":{
                "type":"number",
                "description":"Número do Id do Produto",
                "required":true
            },
            "nrLoja":{
                "type":"number",
                "description":"Número da Loja",
                "required":true
            },
            "nrLojaFilial":{
                "type":"number",
                "description":"Número da Loja Filial",
                "required":true
            },
            "nrPropostaAdp":{
                "type":"number",
                "description":"Número da Proposta no Sistema de Administração de Propostas",
                "required":true
            },
            "nrPropostaFlv":{
                "type":"number",
                "description":"Número da Proposta no Sistema FLV",
                "required":true
            },
            "nrQuantidadeDiasCarencia":{
                "type":"number",
                "description":"Número da Quantidade de Dias de Carência",
                "required":true
            },
            "nrQuantidadePrestacoes":{
                "type":"number",
                "description":"Número da Quantidade de Prestações",
                "required":true
            },
            "nrSubSegmento":{
                "type":"number",
                "description":"Número do SubSegmento",
                "required":true
            },
            "nrTabelaFinanciamento":{
                "type":"number",
                "description":"Número da Tabela de Financiamento",
                "required":true
            },
            "nrVendedor":{
                "type":"number",
                "description":"Número do Vendedor",
                "required":true
            },
            "nrPacoteLiberacao":{
                "type":"string",
                "description":"Número do Pacote de Liberação",
                "required":true
            },
            "vlTarifaAvalBem":{
                "type":"double",
                "description":"Valor da Tarifa de Avaliação do Bem",
                "required":true
            },
            "dsTextoControleLoja":{
                "type":"string",
                "description":"Descrição do Texto de Controle da Loja",
                "required":true
            },
            "dsTextoObsLojista":{
                "type":"string",
                "description":"Descrição do Texto de Observação do Lojista",
                "required":true
            },
            "tpPessoaFornecedor":{
                "type":"string",
                "description":"Tipo de Pessoa/Fornecedor",
                "required":true
            },
            "tpReajuste":{
                "type":"string",
                "description":"Tipo de Reajuste",
                "required":true
            },
            "vlBem":{
                "type":"double",
                "description":"Valor do Bem",
                "required":true
            },
            "vlContraPrestacao":{
                "type":"double",
                "description":"Valor da ContraPrestação",
                "required":true
            },
            "vlEntrada":{
                "type":"double",
                "description":"Valor de Entrada",
                "required":true
            },
            "vlFinanciamento":{
                "type":"double",
                "description":"Valor do Financiamento",
                "required":true
            },
            "vlIOF":{
                "type":"double",
                "description":"Valor do IOF",
                "required":true
            },
            "vlIOFAdicional":{
                "type":"double",
                "description":"Valor do IOF Adicional",
                "required":true
            },
            "vlIndiceCorrecao":{
                "type":"double",
                "description":"Valor do Índice de Correção",
                "required":true
            },
            "vlPagoFornecedor":{
                "type":"double",
                "description":"Valor Pago pelo Fornecedor",
                "required":true
            },
            "vlPrestacao":{
                "type":"double",
                "description":"Valor da Prestação",
                "required":true
            },
            "vlResidualMensal":{
                "type":"double",
                "description":"Valor do Resíduo Mensal",
                "required":true
            },
            "vlSaldoOperacao":{
                "type":"double",
                "description":"Valor do Saldo da Operação",
                "required":true
            },
            "vlSeguro":{
                "type":"double",
                "description":"Valor do Seguro",
                "required":true
            },
            "vlTAC":{
                "type":"double",
                "description":"Valor da TAC",
                "required":true
            },
            "vlTaxaAnual":{
                "type":"double",
                "description":"Valor da Taxa Anual",
                "required":true
            },
            "vlTaxaMensal":{
                "type":"double",
                "description":"Valor da Taxa Mensal",
                "required":true
            },
            "vlTotalImpostoFinanc":{
                "type":"double",
                "description":"Valor Total do Imposto do Financiamento",
                "required":true
            },
            "vlParcIntermediarias":{
                "type":"double",
                "description":"Valor das Parcelas Intermediárias",
                "required":true
            },
            "vlPrincipal":{
                "type":"double",
                "description":"Valor Principal",
                "required":true
            }
        }
    },
    "dadosClienteDadosProfissionaisItem":{
        "id":"dadosClienteDadosProfissionaisItem",
        "properties":{
            "cdDocumento":{
                "type":"number",
                "description":"Código do Documento",
                "required":true
            },
            "cdEstadoNaturalidade":{
                "type":"number",
                "description":"Código do Estado de Naturalidade",
                "required":true
            },
            "cdEstadoOrgaoEmissor":{
                "type":"string",
                "description":"Código do Estado do Orgão Emissor",
                "required":true
            },
            "cdNacionalidade":{
                "type":"number",
                "description":"Código de Nacionalidade",
                "required":true
            },
            "cdNaturezaJuridica":{
                "type":"number",
                "description":"Código da Natureza Jurídica",
                "required":true
            },
            "cdPaisDocumento":{
                "type":"number",
                "description":"Código do País do Documento",
                "required":true
            },
            "cdSedePropria":{
                "type":"number",
                "description":"Código da Sede Própria",
                "required":true
            },
            "idSexo":{
                "type":"string",
                "description":"Id do Sexo",
                "required":true
            },
            "cdTipoPessoa":{
                "type":"number",
                "description":"Código do Tipo de Pessoa",
                "required":true
            },
            "cdTipoRelacionamento":{
                "type":"number",
                "description":"Código do Tipo de Relacionamento",
                "required":true
            },
            "dtAdmissao":{
                "type":"date",
                "description":"Data de Admissão",
                "required":true
            },
            "dtEmissaoDocumento":{
                "type":"date",
                "description":"Data de Emissão do Documento",
                "required":true
            },
            "dtNascimento":{
                "type":"date",
                "description":"Data de Nascimento",
                "required":true
            },
            "dtValidadeDocumento":{
                "type":"date",
                "description":"Data de Validade do Documento",
                "required":true
            },
            "dsAtividadeEconomica":{
                "type":"string",
                "description":"Descrição da Atividade Econômica",
                "required":true
            },
            "dsComprovanteRenda":{
                "type":"string",
                "description":"Descrição do Comprovante de Renda",
                "required":true
            },
            "dsEstadoCivil":{
                "type":"string",
                "description":"Descrição do Estado Civil",
                "required":true
            },
            "dsFuncao":{
                "type":"string",
                "description":"Descrição da Função",
                "required":true
            },
            "dsGrauInstrucao":{
                "type":"string",
                "description":"Descrição do Grau de Instrução",
                "required":true
            },
            "dsGrupoAtivEconomica":{
                "type":"string",
                "description":"Decrição do Grupo de Atividade Econômica",
                "required":true
            },
            "dsNacionalidade":{
                "type":"string",
                "description":"Descrição da Nacinalidade",
                "required":true
            },
            "dsNaturazaJuridica":{
                "type":"string",
                "description":"Descrição da Natureza Jurídica",
                "required":true
            },
            "dsOcupacao":{
                "type":"string",
                "description":"Descrição da Ocupação",
                "required":true
            },
            "dsPorteEmpresa":{
                "type":"string",
                "description":"Descrição do Porte da Empresa",
                "required":true
            },
            "dsTipoRenda":{
                "type":"string",
                "description":"Descrição do Tipo de Renda",
                "required":true
            },
            "dsTpDocumento":{
                "type":"string",
                "description":"Descrição do Tipo de Documento",
                "required":true
            },
            "dsNaturalidade":{
                "type":"string",
                "description":"Descrição da Naturalidade",
                "required":true
            },
            "dsProfissao":{
                "type":"string",
                "description":"Descrição da Profissão",
                "required":true
            },
            "dsTelOutrasRendas":{
                "type":"string",
                "description":"Descrição de Telefone de Outras Rendas",
                "required":true
            },
            "fgIndicativoDeficienteFisico":{
                "type":"string",
                "description":"Flag de Indicativo de Deficiente Físico",
                "required":true
            },
            "fgIndicativoFuncSantander":{
                "type":"string",
                "description":"Flag de Indicativo de Funcionário Santander",
                "required":true
            },
            "nmCompleto":{
                "type":"string",
                "description":"Nome Completo",
                "required":true
            },
            "nmEmpresa":{
                "type":"string",
                "description":"Nome da Empresa",
                "required":true
            },
            "nmMae":{
                "type":"string",
                "description":"Nome da Mãe",
                "required":true
            },
            "cdOeDocumento":{
                "type":"string",
                "description":"Código do Órgão Emissor do Documento",
                "required":true
            },
            "nmPai":{
                "type":"string",
                "description":"Nome do Pai",
                "required":true
            },
            "nrAtividadeEconomica":{
                "type":"number",
                "description":"Número da Atividade Econômica",
                "required":true
            },
            "nrClienteRelac":{
                "type":"number",
                "description":"Número do Cliente Relacionamento",
                "required":true
            },
            "nrCnpjEmpresa":{
                "type":"string",
                "description":"Número do CNPJ da Empresa",
                "required":true
            },
            "nrComprovanteRenda":{
                "type":"number",
                "description":"Número do Comprovante de Renda",
                "required":true
            },
            "nrCpfCnpj":{
                "type":"string",
                "description":"Número do CPF/CNPJ",
                "required":true
            },
            "nrDddOutrasRendas":{
                "type":"string",
                "description":"Número do DDD das Outras Rendas",
                "required":true
            },
            "nrDependentes":{
                "type":"number",
                "description":"Número de Dependentes",
                "required":true
            },
            "nrEstadoCivil":{
                "type":"number",
                "description":"Número do Estado Civil",
                "required":true
            },
            "nrGrupoAtivEconomica":{
                "type":"string",
                "description":"Número do Grupo da Atividade Econômica",
                "required":true
            },
            "nrIndicativoGrauParentes":{
                "type":"number",
                "description":"Número do Indicativo de Grau de Parentes",
                "required":true
            },
            "nrInstrucao":{
                "type":"number",
                "description":"Número de Instrução",
                "required":true
            },
            "nrOcupacao":{
                "type":"number",
                "description":"Número de Ocupação",
                "required":true
            },
            "nrPessoaPoliticaExpo":{
                "type":"number",
                "description":"Número de Pessoa Política",
                "required":true
            },
            "nrPorteEmpresarial":{
                "type":"number",
                "description":"Número do Porte Empresarial",
                "required":true
            },
            "nrProfissao":{
                "type":"number",
                "description":"Número da Profissão",
                "required":true
            },
            "nrRamalOutrasRendas":{
                "type":"number",
                "description":"Número do Ramal de Outras Rendas",
                "required":true
            },
            "nrRenda":{
                "type":"number",
                "description":"Número da Renda",
                "required":true
            },
            "nrTipoDocumento":{
                "type":"number",
                "description":"Número do Tipo de Documento",
                "required":true
            },
            "nrTipoVinculoPart":{
                "type":"number",
                "description":"Número do Tipo de Vínculo de Participação",
                "required":true
            },
            "nrTpRepresentante":{
                "type":"number",
                "description":"Número do Tipo de Representante",
                "required":true
            },
            "vlOutrasRendas":{
                "type":"double",
                "description":"Valor de Outras Rendas",
                "required":true
            },
            "vlPatrimonio":{
                "type":"double",
                "description":"Valor do Patrimônio",
                "required":true
            },
            "vlRendaMensal":{
                "type":"double",
                "description":"Valor da Renda Mensal",
                "required":true
            }
        }
    },
    "referenciaPessoalBancariaItem":{
        "id":"referenciaPessoalBancariaItem",
        "properties":{
            "cdDigitoAgencia":{
                "type":"string",
                "description":"Código do Dígito da Agência",
                "required":true
            },
            "cdDigitoContaCorrente":{
                "type":"string",
                "description":"Código do Dígito da Conta Corrente",
                "required":true
            },
            "cdTipoContaBancaria":{
                "type":"number",
                "description":"Código do Tipo da Conta Bancária",
                "required":true
            },
            "dsNomeBanco":{
                "type":"string",
                "description":"Descrição do Nome do Banco",
                "required":true
            },
            "dsTipoConta":{
                "type":"string",
                "description":"Descrição do Tipo de Conta",
                "required":true
            },
            "dsEndRefer1":{
                "type":"string",
                "description":"Descrição do Endereço de Referência 1",
                "required":true
            },
            "dsEndRefer2":{
                "type":"string",
                "description":"Descrição do Endereço de Referência 2",
                "required":true
            },
            "dsTelefoneBanco":{
                "type":"string",
                "description":"Descrição do Telefone do Banco",
                "required":true
            },
            "dsTelefoneRefer1":{
                "type":"string",
                "description":"Descrição do Telefone de Referência 1",
                "required":true
            },
            "dsTelefoneRefer2":{
                "type":"string",
                "description":"Descrição do Telefone de Referência 2",
                "required":true
            },
            "nmRefer1":{
                "type":"string",
                "description":"Nome da Referência 1",
                "required":true
            },
            "nmRefer2":{
                "type":"string",
                "description":"Nome da Referência 2",
                "required":true
            },
            "nrAgencia":{
                "type":"string",
                "description":"Número da Agência",
                "required":true
            },
            "nrAnoClienteDesde":{
                "type":"number",
                "description":"Número do Ano do Cadastro do Cliente",
                "required":true
            },
            "nrBanco":{
                "type":"string",
                "description":"Número do Banco",
                "required":true
            },
            "nrClienteInterno":{
                "type":"string",
                "description":"Número do Cliente Internp",
                "required":true
            },
            "nrContaCorrente":{
                "type":"string",
                "description":"Número da Conta Corrente",
                "required":true
            },
            "nrDddRefer1":{
                "type":"string",
                "description":"Número do DDD de Referência 1",
                "required":true
            },
            "nrDddRefer2":{
                "type":"string",
                "description":"Número do DDD de Referência 2",
                "required":true
            },
            "nrDddTelefoneBanco":{
                "type":"string",
                "description":"Número do DDD do Telefône do Banco",
                "required":true
            },
            "nrMesClienteDesde":{
                "type":"number",
                "description":"Número do Mês do Cadastro do Cliente",
                "required":true
            }
        },

    },
    "dadosAgenteCertificadoItem":{
        "id":"dadosAgenteCertificadoItem",
        "properties":{
            "idAgCertificado":{
                "type":"string",
                "description":"Id do Agente Certificado",
                "required":true
            },
            "cdCertificadoAgente":{
                "type":"string",
                "description":"Código do Certificado do Agente",
                "required":true
            },
            "dtValidadeCert":{
                "type":"date",
                "description":"Data de Validade do Certificado",
                "required":true
            },
            "nmAgCertificado":{
                "type":"string",
                "description":"Nome do Agente Certificado",
                "required":true
            },
            "nrCpfAgCertificado":{
                "type":"string",
                "description":"Número do CPF do Agente Certificado",
                "required":true
            }
        },

    },
    "dadosEnderecoItem":{
        "id":"dadosEnderecoItem",
        "properties":{
            "cdEnderecoCorrespondencia":{
                "type":"number",
                "description":"Código do Endereço de Correspondência",
                "required":true
            },
            "cdPaisComercial":{
                "type":"number",
                "description":"Código do País Comercial",
                "required":true
            },
            "cdPaisResidencia":{
                "type":"number",
                "description":"Código do País Residência",
                "required":true
            },
            "cdSiglaUfComercial":{
                "type":"number",
                "description":"Código da Sigla Unidade Federal Comercial",
                "required":true
            },
            "cdSiglaUfResidencial":{
                "type":"number",
                "description":"Código da Sigla Unidade Federal Residencial",
                "required":true
            },
            "cdTelCel":{
                "type":"number",
                "description":"Código do Telefone Celular",
                "required":true
            },
            "dtAnoResideDesde":{
                "type":"date",
                "description":"Data do Ano Inicial de Residência",
                "required":true
            },
            "dtMesResideDesde":{
                "type":"date",
                "description":"Data do Mês Inicial de Residência",
                "required":true
            },
            "dsEndCorrespondencia":{
                "type":"string",
                "description":"Descrição do Endereço de Correspondência",
                "required":true
            },
            "dsTipoResidencia":{
                "type":"string",
                "description":"Descrição do Tipo de Residência",
                "required":true
            },
            "dsTipoTelefone":{
                "type":"string",
                "description":"Descrição do Tipo de Telefone",
                "required":true
            },
            "dsComplementoEndComercial":{
                "type":"string",
                "description":"Descrição do Complemento de Endereço Comercial",
                "required":true
            },
            "dsComplementoResidencia":{
                "type":"string",
                "description":"Descrição do Complemento de Residência",
                "required":true
            },
            "dsEnderecoComercial":{
                "type":"string",
                "description":"Descrição do Endereço Comercial",
                "required":true
            },
            "dsEnderecoEmail":{
                "type":"string",
                "description":"Descrição do Endereço de E-mail",
                "required":true
            },
            "dsEnderecoResidencia":{
                "type":"string",
                "description":"Descrição do Endereço de Residência",
                "required":true
            },
            "dsTelComercial":{
                "type":"string",
                "description":"Descrição do Telefone Comercial",
                "required":true
            },
            "dsTelResidencial":{
                "type":"string",
                "description":"Descrição do Telefone Residencial",
                "required":true
            },
            "dsTelFaxEmpresarial":{
                "type":"string",
                "description":"Descrição do Telefone do Fax Empresarial",
                "required":true
            },
            "nmBairroComercial":{
                "type":"string",
                "description":"Nome do Bairro Comercial",
                "required":true
            },
            "nmBairroResidencia":{
                "type":"string",
                "description":"Nome do Bairro Residencial",
                "required":true
            },
            "nmCidadeComercial":{
                "type":"string",
                "description":"Nome da Cidade Comercial",
                "required":true
            },
            "nmCidadeResidencial":{
                "type":"string",
                "description":"Nome da Cidade Residencial",
                "required":true
            },
            "nmHomepage":{
                "type":"string",
                "description":"Nome da Homepage",
                "required":true
            },
            "nrCepComercial":{
                "type":"string",
                "description":"Número do CEP Comercial",
                "required":true
            },
            "nrCepResidencial":{
                "type":"string",
                "description":"Número do CEP Residencial",
                "required":true
            },
            "nrDddCel":{
                "type":"string",
                "description":"Número do DDD do Celular",
                "required":true
            },
            "nrDddFaxEmpresarial":{
                "type":"string",
                "description":"Número do DDD do Fax Empresarial",
                "required":true
            },
            "nrDddResidencial":{
                "type":"string",
                "description":"Número do DDD Residencial",
                "required":true
            },
            "nrDddTelComercial":{
                "type":"string",
                "description":"Número do DDD do Telefone Comercial",
                "required":true
            },
            "nrEnderecoComercial":{
                "type":"string",
                "description":"Número do Endereço Comercial",
                "required":true
            },
            "nrResidencial":{
                "type":"string",
                "description":"Número Residencial",
                "required":true
            },
            "nrTelComercialRamal":{
                "type":"string",
                "description":"Número do Ramal do Telefone Comercial",
                "required":true
            },
            "nrTipoResidencia":{
                "type":"number",
                "description":"Número do Tipo de Residência",
                "required":true
            },
            "nrTipoTelefResiden":{
                "type":"number",
                "description":"Número do Tipo de Telefone de Residência",
                "required":true
            }
        },

    },
    "dadosConjugeItem":{
        "id":"dadosConjugeItem",
        "properties":{
            "cdDocumento":{
                "type":"number",
                "description":"Código do Documento",
                "required":true
            },
            "cdEstadoOrgaoEmissor":{
                "type":"string",
                "description":"Código do Estado do Órgão Emissor",
                "required":true
            },
            "cdSexo":{
                "type":"string",
                "description":"Código do Sexo",
                "required":true
            },
            "dtAdmissao":{
                "type":"date",
                "description":"Data de Admissão",
                "required":true
            },
            "dtNascimento":{
                "type":"date",
                "description":"Data de Nascimento",
                "required":true
            },
            "dsFuncao":{
                "type":"string",
                "description":"Descrição da Função",
                "required":true
            },
            "dsOcupacao":{
                "type":"string",
                "description":"Descrição da Ocupação",
                "required":true
            },
            "dsEnderecoComercial":{
                "type":"string",
                "description":"Descrição do Endereço Comercial",
                "required":true
            },
            "dsTelComercial":{
                "type":"string",
                "description":"Descrição do Telefone Comercial",
                "required":true
            },
            "nmCompleto":{
                "type":"string",
                "description":"Nome Completo",
                "required":true
            },
            "nmEmpresa":{
                "type":"string",
                "description":"Nome da Empresa",
                "required":true
            },
            "cdOeDocumento":{
                "type":"string",
                "description":"Código do Órgão Emissor do Documento",
                "required":true
            },
            "nrCpfCnpj":{
                "type":"string",
                "description":"Número do CPF/CNPJ",
                "required":true
            },
            "nrDddTelComercial":{
                "type":"string",
                "description":"Número do DDD do Telefone Comercial",
                "required":true
            },
            "cdNatOcup":{
                "type":"string",
                "description":"Código da Natureza da Ocupação",
                "required":true
            },
            "nrProfissao":{
                "type":"string",
                "description":"Número da Profissão",
                "required":true
            },
            "nrTelComercialRamal":{
                "type":"string",
                "description":"Número do Ramal do Telefone Comercial ",
                "required":true
            },
            "vlRendaMensal":{
                "type":"double",
                "description":"Valor da Renda Mensal",
                "required":true
            }
        },

    },
    "dadosGarantiaItem":{
        "id":"dadosGarantiaItem",
        "properties":{
            "cdFipe":{
                "type":"number",
                "description":"Código FIPE",
                "required":true
            },
            "cdEstadoLicenciamento":{
                "type":"number",
                "description":"Código do Estado do Licenciamento",
                "required":true
            },
            "cdEstadoPlaca":{
                "type":"number",
                "description":"Código do Estado da Placa",
                "required":true
            },
            "cdGarantia":{
                "type":"number",
                "description":"Código da Garantia",
                "required":true
            },
            "cdObjFinanciado":{
                "type":"number",
                "description":"Código do Objeto Financiado",
                "required":true
            },
            "cdRenavam":{
                "type":"number",
                "description":"Código do Renavam",
                "required":true
            },
            "cdTipoCombustivel":{
                "type":"number",
                "description":"Código do Tipo de Combustível",
                "required":true
            },
            "dsObjFinanciado":{
                "type":"string",
                "description":"Descrição do Objeto Financiado",
                "required":true
            },
            "dsProcVeiculo":{
                "type":"string",
                "description":"Descrição de Procedência do Veículo",
                "required":true
            },
            "dsTipoCombustivel":{
                "type":"string",
                "description":"Descrição do Tipo de Combustível",
                "required":true
            },
            "dsChassi":{
                "type":"string",
                "description":"Descrição do Chassi",
                "required":true
            },
            "dsCor":{
                "type":"string",
                "description":"Descrição da Cor",
                "required":true
            },
            "dsMarca":{
                "type":"string",
                "description":"Descrição da Marca",
                "required":true
            },
            "dsModelo":{
                "type":"string",
                "description":"Descrição do Modelo",
                "required":true
            },
            "dsPlaca":{
                "type":"string",
                "description":"Descrição da Placa",
                "required":true
            },
            "fgIndicativoAdaptado":{
                "type":"string",
                "description":"Flag de Indicativo de Adaptado",
                "required":true
            },
            "fgIndicativoBemFinanciado":{
                "type":"string",
                "description":"Flag do Indicativo de Bem Financiado",
                "required":true
            },
            "fgIndicativoProcVeiculo":{
                "type":"string",
                "description":"Flag de Indicativo de Procedência do Veículo",
                "required":true
            },
            "fgIndicativoTaxi":{
                "type":"string",
                "description":"Flag Indicativo de Taxi",
                "required":true
            },
            "fgIndicativoZeroKm":{
                "type":"string",
                "description":"Flag Indicativo de Zero Km",
                "required":true
            },
            "nrAnoFabricacao":{
                "type":"number",
                "description":"Número do Ano de Fabricação",
                "required":true
            },
            "nrAnoModelo":{
                "type":"number",
                "description":"Número do Ano do Modelo",
                "required":true
            },
            "nrGarantia":{
                "type":"number",
                "description":"Número da Garantia",
                "required":true
            },
            "nrTabMarca":{
                "type":"number",
                "description":"Número da Tabela da Marca",
                "required":true
            },
            "nrTabModelo":{
                "type":"number",
                "description":"Número da Tabela do Modelo",
                "required":true
            },
            "vlPorcentagemDiferVeiculo":{
                "type":"double",
                "description":"Valor da Porcentagem de Diferença do Veículo",
                "required":true
            },
            "vlPorcentagemEntrVeiculo":{
                "type":"double",
                "description":"Valor da Porcentagem de Entrada do Veículo",
                "required":true
            },
            "vlVeiculoMercado":{
                "type":"double",
                "description":"Valor do Veículo de Mercado",
                "required":true
            },
            "vlVenda":{
                "type":"double",
                "description":"Valor da Venda",
                "required":true
            }
        },

    },
    "dadosFlexItem":{
        "id":"dadosFlexItem",
        "properties":{
            "cdPctFlex":{
                "type":"number",
                "description":"Código do Pacote Flex",
                "required":true
            }
        }
    },
    "listaParcelasFlexItem":{
        "id":"listaParcelasFlexItem",
        "properties":{
            "dataVenc":{
                "type":"date",
                "description":"Data de Vencimento",
                "required":true
            },
            "numero":{
                "type":"number",
                "description":"Número",
                "required":true
            },
            "valor":{
                "type":"double",
                "description":"Valor",
                "required":true
            }
        }
    },
    "getResponse":{
        "id":"getResponse",
        "properties":{
            "dadosBasicosProposta":{
                "$ref":"dadosBasicosPropostaItem",
                "description":"Dados Basicos da proposta",
                "required":true
            },
            "dadosClienteDadosProfissionais":{
                "$ref":"dadosClienteDadosProfissionaisItem",
                "description":"Dados Profissionais do Cliente",
                "required":true
            },
            "referenciaPessoalBancaria":{
                "$ref":"referenciaPessoalBancariaItem",
                "description":"Referência Pessoal Bancaria",
                "required":true
            },
            "dadosAgenteCertificado":{
                "$ref":"dadosAgenteCertificadoItem",
                "description":"Dados do Agente Certificado",
                "required":true
            },
            "dadosEndereco":{
                "$ref":"dadosEnderecoItem",
                "description":"Dados do Endereco",
                "required":true
            },
            "dadosConjuge":{
                "$ref":"dadosConjugeItem",
                "description":"Dados do Cônjuge",
                "required":true
            },
            "dadosGarantia":{
                "$ref":"dadosGarantiaItem",
                "description":"Dados da Garantia",
                "required":true
            },
            "dadosFlex":{
                "$ref":"dadosFlexItem",
                "description":"Dados Flex",
                "required":true
            },
            "listaParcelasFlex":{
                "type":"array",
                "items":{
                    "$ref":"listaParcelasFlexItem"
                },
                "description":"Lista de Parcelas Flex",
                "required":true
            }
        }
    }
};
