exports.models = {
    "obterPdfResponse": {
        "id": "obterPdfResponse",
        "properties": {
            "CET": {
                "$ref": "CETObj",
                "description": "CET",
                "required": true
            }
        }
    },
    "CETObj": {
      "id": "CETObj",
        "properties": {
            "content": {
                "type": "string",
                "description": "CET",
                "required": false
            }
        }
    }
};
