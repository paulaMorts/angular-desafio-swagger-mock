var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o cabeçalho da proposta corrente",
        path: "/simulacao/getCabecalho",
        method: "GET",
        summary: "Retorna o cabeçalho da proposta corrente",
        notes: "Retorna o cabeçalho da proposta corrente.",
        type: "getCabecalhoResponse",
        nickname: "getCabecalho",
        produces: ["application/json"],
        parameters: [paramTypes.query("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Cabeçalho retornado com sucesso",
                responseModel: "getCabecalhoResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter cabeçalho",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if(req.query.idProposta == 20) {
            res.status(200).send({
                "nrCpfCnpj": "11111111000111",
                "dsMarca": "HONDA",
                "dsAno": "2010",
                "dsCombust": "Gasolina",
                "dsZero": "Zero Km",
                "vlFinanciamento": 53500.20,
                "dtDataNascFund": 1461768956707,
                "dsModelo": "MOTORS DO BRASIL FIT LXL 1.4/1.4 FLEX 8V/16V 5P AUT. FIT LXL 1.4/1.4 FLEX 8V/16V 5P AUT.",
                "dsAnoFabricacao": 2010,
				"dsUfLicenca": "SP",
                "fgAdaptado": true,
                "fgTaxi": true
            });
        } else {
            res.status(200).send({
                "nrCpfCnpj": "32245970896",
                "dsMarca": "HONDA",
                "dsAno": "2010",
                "dsCombust": "Gasolina",
                "dsZero": "Zero Km",
                "vlFinanciamento": 53500.20,
                "dtDataNascFund": 1461768956707,
                "dsModelo": "MOTORS DO BRASIL FIT LXL 1.4/1.4 FLEX 8V/16V 5P AUT. FIT LXL 1.4/1.4 FLEX 8V/16V 5P AUT.",
                "dsAnoFabricacao": 2010,
				"dsUfLicenca": "SP",
                "fgAdaptado": false,
                "fgTaxi": false
            });
        }
    }
};