var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Executa a gravação da proposta",
        path: "/simulacao/gravaProposta/",
        method: "POST",
        summary: "Grava proposta",
        notes: "Executa a gravação dos dados da simulação na proposta gerada anteriormente.",
        type: "postGravaPropostaResponse",
        nickname: "postGravaProposta",
        produces: ["application/json"],
        parameters: [paramTypes.body("postGravaPropostaRequest", "Parametros da proposta", "postGravaPropostaRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Proposta gravada com sucesso",
                responseModel: "postGravaPropostaResponse"
            },
            {
                code: "500",
                reason: "Erro ao gravar proposta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "idProposta":req.body.idProposta ? req.body.idProposta : 0,
            "cdErro":0,
            "dsMensagem":""
        });
    }
};