var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a consulta ao ATX",
        path: "/atx/consulta",
        method: "POST",
        summary: "Retorna a consulta ao ATX",
        notes: "Retorna a consulta ao ATX.",
        type: "consultaResponse",
        nickname: "consulta",
        produces: ["application/json"],
        parameters: [
            paramTypes.body("consultaRequest", "Parametros da consulta.", "consultaRequest")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Consulta retornada com sucesso",
                responseModel: "consultaResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter a consulta do ATX",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var pacotesBasicos = [
            {
                "nrPacoteFinanc": 0,
                "nmPacoteFinanc": "Super Pacote"
            },
            {
                "nrPacoteFinanc": 1,
                "nmPacoteFinanc": "Pacote Bom"
            },
            {
                "nrPacoteFinanc": 2,
                "nmPacoteFinanc": "Pacote Excelente"
            },
            {
                "nrPacoteFinanc": 3,
                "nmPacoteFinanc": "Pacotão"
            },
            {
                "nrPacoteFinanc": 4,
                "nmPacoteFinanc": "Pacote Supimpa"
            },
            {
                "nrPacoteFinanc": 5,
                "nmPacoteFinanc": "Pacote do Balacobaco"
            },
            {
                "nrPacoteFinanc": 6,
                "nmPacoteFinanc": "Pacote Supreme"
            },
            {
                "nrPacoteFinanc": 7,
                "nmPacoteFinanc": "Pacotaço"
            }
        ];

        var pacotesCupom = [
            {
                "nrPacoteFinanc": 0,
                "nmPacoteFinanc": "Super Pacote Cupom"
            },
            {
                "nrPacoteFinanc": 1,
                "nmPacoteFinanc": "Pacote Bom Cupom"
            },
            {
                "nrPacoteFinanc": 2,
                "nmPacoteFinanc": "Pacote Excelente Cupom Com Nome Bem Grande Para testar"
            },
            {
                "nrPacoteFinanc": 3,
                "nmPacoteFinanc": "Pacotão"
            },
            {
                "nrPacoteFinanc": 4,
                "nmPacoteFinanc": "Pacote Supimpa"
            }
        ];

        var prazosDisponiveisBasico = [
            {
                "nrPrazoDisponivel": 6
            },
            {
                "nrPrazoDisponivel": 12
            },
            {
                "nrPrazoDisponivel": 18
            },
            {
                "nrPrazoDisponivel": 24
            },
            {
                "nrPrazoDisponivel": 30
            }
        ];

        var prazosDisponiveisCupom = [
            {
                "nrPrazoDisponivel": 36
            }
        ];
        if (req.body.parameter.cdCupom == 111){
            res.status(400).send({
                "error":{
                    "code":"CANAL:atx.consulta",
                    "message":"Campo(s) inválido(s) para realizar a integração: Cupom inválido"
                }
            });
        } else if (req.body.parameter.cdCupom == 123){
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao carregar consulta."
                }
            });
        }
        else if (req.body.parameter.idProposta) {
            res.status(200).send({
                "tabelaPreco": {
                    "cdTabela": "73.000"
                },
                "consultaAtx": {
                    "idFormaPagamento": undefined,
                    "dtRecomendadaPrimeiraParcela": "2016-05-27T00:00:00-03:00",
                    "dtMaxPrimeiraParcela": "2016-06-27T00:00:00-03:00",
                    "dtMinPrimeiraParcela": "2016-04-27T00:00:00-03:00",
                    "fgOfertaSeguroPermitida": "S",
                    "prazosDisponiveis": req.body.parameter.cdCupom == 666 ? prazosDisponiveisCupom : prazosDisponiveisBasico,
                    "faixaBarraEntrada": 1000,
                    "vlMaxEntrada": 45000,
                    "vlMinEntrada": 5000,
                    "vlRecomendadaEntrada": 16510,
                    "idFrotaRecomendada": 4,
                    "ofertaSeguro": [
                        {
                            "cdSeguro" : "71",
                            "dsSeguro" : "CDC PROTEGIDO",
                            "dsCaracteristica" : "AO COMPRAR SEU VE&Iacute;CULO POR MEIO DE FINANCIAMENTO, VOC&Ecirc; PODE ADQUIRIR O SANTANDER CDC PROTEGIDO. PRINCIPAIS BENEF&Iacute;CIOS DO SANTANDER CDC PROTEGIDO:&#xa;FACILIDADE PARA COMPRAR O VE&Iacute;CULO COM SEGURAN&Ccedil;A E TRANQUILIDADE FINANCEIRA PARA ELE E A FAM&Iacute;LIA EM CASO DE IMPREVISTOS COMO DESEMPREGO INVOLUNT&Aacute;RIO E MORTE.&#xa;COBERTURA DE AT&Eacute; R&#x24; 100.000,00 PARA CASO DE MORTE NATURAL OU ACIDENTAL OU INVALIDEZ PERMANENTE TOTAL POR ACIDENTE.&#xa;COBERTURA DE AT&Eacute; 3 PARCELAS DE R&#x24; 5.000,00 CADA, PARA CASO DE DESEMPREGO INVOLUNT&Aacute;RIO OU INCAPACIDADE F&Iacute;SICA TEMPOR&Aacute;RIA POR ACIDENTE.&#xa;COBERTURAS V&Aacute;LIDAS AT&Eacute; O FINAL DO CONTRATO DO FINANCIAMENTO.&#xa;",
                            "dsJustificativa" : "ESTA SIMULA&Ccedil;&Atilde;O FOI EFETUADA SEM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO. SEM O SEGURO VOC&Ecirc;:&#xa;- N&Atilde;O CONTA COM A COBERTURA EM CASO DE MORTE OU DE INVALIDEZ PERMANENTE TOTAL POR ACIDENTE DO SEGURADO&#x3b; E DESEMPREGO INVOLUNT&Aacute;RIO OU INVALIDEZ F&Iacute;SICA TEMPOR&Aacute;RIA POR ACIDENTE.&#xa;- POR UM PEQUENO ACR&Eacute;SCIMO EM SUA PARCELA, VOC&Ecirc; PODER&Aacute; CONTAR COM A PROTE&Ccedil;&Atilde;O DO SEGURO. &#xa;CASO DESEJE CONTRATAR COM O SEGURO, ACESSE A OP&Ccedil;&Atilde;O DESEJO RETORNAR &Agrave; SIMULA&Ccedil;&Atilde;O COM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO LOCALIZADA ABAIXO E VERIFIQUE AS NOVAS CONDI&Ccedil;&Otilde;ES DO FINANCIAMENTO COM O SEGURO.&#xa;",
                            "vlSeguro" : 1450.0,
                            "fgSeguroPadrao" : "S",
                            "aliquotaSeguro" : 0.0
                        }, {
                            "cdSeguro" : "73",
                            "dsSeguro" : "CDC PROTEGIDO VIDA",
                            "dsCaracteristica" : "O CDC PROTEGIDO VIDA TEM POR OBJETIVO A PROTE&Ccedil;&Atilde;O DO SEGURADO PARA AS COBERTURAS DE MORTE E INVALIDEZ PERMANENTE TOTAL POR ACIDAMENTE &#x28;IPTA&#x29; LIMITADO &Agrave; R&#x24; 25.000,00 &#x28;VINTE E CINCO MIL REAIS&#x29; GARANTINDO AOS BENEFICI&Aacute;RIOS O VALOR TOTAL DO CONTRATO DE CR&Eacute;DITO DIRETO. O PRIMEIRO BENEFICI&Aacute;RIO DO SEGURO SER&Aacute; SEMPRE O ESTIPULANTE DO SEGURO, AT&Eacute; QUITAR O SALDO DEVEDOR DA D&Iacute;VIDA OU COMPROMISSO FINANCEIRO. HAVENDO SALDO REMANESCENTE ENTRE O CAPITAL SEGURADO CONTRATADO INICIALMENTE E O SALDO DEVEDOR, ESTE, SER&Aacute; PAGO AO SEGUNDO BENEFICI&Aacute;RIO&#x28;S&#x29; INDICADO&#x28;S&#x29; PELO SEGURADO.",
                            "dsJustificativa" : "ESTA SIMULA&Ccedil;&Atilde;O FOI EFETUADA SEM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO VIDA. SEM O SEGURO VOC&Ecirc;:&#xa;- N&Atilde;O CONTA COM A COBERTURA EM CASO DE MORTE OU DE INVALIDEZ PERMANENTE TOTAL POR ACIDENTE DO SEGURADO.&#xa;- POR UM PEQUENO ACR&Eacute;SCIMO EM SUA PARCELA, VOC&Ecirc; PODER&Aacute; CONTAR COM A PROTE&Ccedil;&Atilde;O DO SEGURO. &#xa;CASO DESEJE CONTRATAR COM O SEGURO, ACESSE A OP&Ccedil;&Atilde;O &#x3f;DESEJO RETORNAR &Agrave; SIMULA&Ccedil;&Atilde;O COM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO VIDA&#x3f; LOCALIZADA ABAIXO E VERIFIQUE AS NOVAS CONDI&Ccedil;&Otilde;ES DO FINANCIAMENTO COM O SEGURO.&#xa;",
                            "vlSeguro" : 1450.67,
                            "fgSeguroPadrao" : "N",
                            "aliquotaSeguro" : 0.0
                        }, {
                            "cdSeguro" : "75",
                            "dsSeguro" : "CDC PROTEGIDO VIDA&#x2f;DESEMPREGO  ",
                            "dsCaracteristica" : "O CDC PROTEGIDO VIDA&#x2f;DESEMPREGO  TEM POR OBJETIVO A PROTE&Ccedil;&Atilde;O DO SEGURADO PARA AS COBERTURAS DE MORTE E INVALIDEZ PERMANENTE TOTAL POR ACIDAMENTE &#x28;IPTA&#x29; LIMITADO &Agrave; R&#x24; 50.000,00 &#x28;CINQUENTA MIL REAIS&#x29; GARANTINDO AOS BENEFICI&Aacute;RIOS O VALOR TOTAL DO CONTRATO DE CR&Eacute;DITO DIRETO. O PRIMEIRO BENEFICI&Aacute;RIO DO SEGURO SER&Aacute; SEMPRE O ESTIPULANTE DO SEGURO, AT&Eacute; QUITAR O SALDO DEVEDOR DA D&Iacute;VIDA OU COMPROMISSO FINANCEIRO. HAVENDO SALDO REMANESCENTE ENTRE O CAPITAL SEGURADO CONTRATADO INICIALMENTE E O SALDO DEVEDOR, ESTE SER&Aacute; PAGO AO SEGUNDO BENEFICI&Aacute;RIO&#x28;S&#x29; INDICADO&#x28;S&#x29; PELO SEGURADO. OFERECE TAMB&Eacute;M AS COBERTURAS DE DESEMPREGO INVOLUNT&Aacute;RIO &#x28;DI&#x29; E INVALIDEZ F&Iacute;SICA TEMPOR&Aacute;RIA POR ACIDENTE &#x28;IFTA&#x29;, PARA O PAGAMENTO DE AT&Eacute; 3 &#x28;TR&Ecirc;S&#x29; PARCELAS DO FINANCIAMENTO COM IS LIMITADA &Agrave; R&#x24; 5.000,00 &#x28;CINCO MIL REAIS&#x29;.",
                            "dsJustificativa" : "ESTA SIMULA&Ccedil;&Atilde;O FOI EFETUADA SEM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO VIDA&#x2f;DESEMPREGO. SEM O SEGURO VOC&Ecirc;:&#xa;- N&Atilde;O CONTA COM A COBERTURA EM CASO DE MORTE OU DE INVALIDEZ PERMANENTE TOTAL POR ACIDENTE DO SEGURADO&#x3b; E DESEMPREGO INVOLUNT&Aacute;RIO OU INVALIDEZ F&Iacute;SICA TEMPOR&Aacute;RIA POR ACIDENTE.&#xa;- POR UM PEQUENO ACR&Eacute;SCIMO EM SUA PARCELA, VOC&Ecirc; PODER&Aacute; CONTAR COM A PROTE&Ccedil;&Atilde;O DO SEGURO. &#xa;CASO DESEJE CONTRATAR COM O SEGURO, ACESSE A OP&Ccedil;&Atilde;O DESEJO RETORNAR &Agrave; SIMULA&Ccedil;&Atilde;O COM A PROTE&Ccedil;&Atilde;O CDC PROTEGIDO VIDA&#x2f;DESEMPREGO LOCALIZADA ABAIXO E VERIFIQUE AS NOVAS CONDI&Ccedil;&Otilde;ES DO FINANCIAMENTO COM O SEGURO.&#xa;",
                            "vlSeguro" : 0.0,
                            "fgSeguroPadrao" : "N",
                            "aliquotaSeguro" : 5.5
                        }
                    ],
                    "pacotesCdcFlex": (req.body.parameter.cdCupom == 666) ?  pacotesCupom : pacotesBasicos,
                    "dadosIsencao": [{
                        "fgIsencaoTab": req.body.parameter.idProposta == 1 ? "N" : "S",
                        "fgPagamentoTabAvista": req.body.parameter.idProposta == 1 ? "N" : "S",
                        "fgIsencaoTc": req.body.parameter.idProposta == 1 ? "N" : "S",
                        "fgPagamentoTcAvista": req.body.parameter.idProposta == 1 ? "N" : "S",
                        "dsMensagem": "O cliente já possui relacionamento junto ao Santander/Santander Financiamentos sendo beneficiado com a isenção de tarifa de cadastro."
                    }],
                    "fgHabilitaFrota": "S",
                    "frota": [
                        {
                            "idFrota": "3",
                            "dsFrota": "Frota 1"
                        },
                        {
                            "idFrota": "4",
                            "dsFrota": "Frota 2"
                        },
                        {
                            "idFrota": "6",
                            "dsFrota": "Frota 3"
                        },
                        {
                            "idFrota": "9",
                            "dsFrota": "Frota 4"
                        }
                    ],
                    "formaPagamento": [
                        {
                            "idFormaPagto": 0,
                            "dsFormaPagto": "Carnê"
                        },
                        {
                            "idFormaPagto": 1,
                            "dsFormaPagto": "Cartão Credito"
                        }
                    ]
                }
            });
        }
        else {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao carregar consulta."
                }
            });
        }
    }
};
