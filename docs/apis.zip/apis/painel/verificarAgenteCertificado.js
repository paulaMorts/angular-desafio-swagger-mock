var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Verifica se o agente certificado está válido para ser utilizado.",
        path: "/painel/verificaAgenCertificador/{idAgente}",
        method: "GET",
        summary: "Com base no ID do agente certificado, garante que o mesmo está válido para ser utilizado na busca de propostas.",
        notes: "Verifica se o agente certificado está válido para ser utilizado.",
        type: "verificarAgenteCertificado",
        nickname: "getIndicadores",
        produces: ["application/json"],
        parameters: [paramTypes.path("idAgente", "Id do Agente Certificado", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Verificação realizada com sucesso.",
                responseModel: "getVerificarAgenteCertificado"
            },
            {
                code: "500",
                reason: "Erro ao realizar verificação.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(req.params.idAgente == 2 ? { "verificaAgentCertificador": {
                msgAlerta: "Loja com agente certificado a vencer/vencido!"
		}} : {});
    }
};
