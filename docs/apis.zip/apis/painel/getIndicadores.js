var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Obtém os indicadores analíticos de todas as propostas disponíveis.",
        path: "/painel/dashboard",
        method: "GET",
        summary: "Obtém os indicadores analíticos de todas as propostas disponíveis.",
        notes: "Obtém os indicadores analíticos de todas as propostas disponíveis.",
        type: "getIndicadoresResponse",
        nickname: "getIndicadores",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("dtInicio", "Data de Início", "date"),
            paramTypes.query("dtFim", "Data de Término", "date"),
            paramTypes.query("cdTab", "Código da Loja", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de indicadores para a lista de propostas",
                responseModel: "getIndicadoresResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar o dashboard com a lista de propostas",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "dashboard": {
                propostas: [
                    {
                        id: 1,
                        nome: "EFETIVADAS",
                        valor: 100
                    },
                    {
                        id: 2,
                        nome: "APROVADAS",
                        valor: 40
                    },
                    {
                        id: 3,
                        nome: "EM ANÁLISE",
                        valor: 5
                    },
                    {
                        id: 4,
                        nome: "CANCELADAS",
                        valor: 5
                    },
                    {
                        id: 5,
                        nome: "NEGADAS",
                        valor: 30
                    },
                    {
                        id: 6,
                        nome: "DADOS A COMPLEMENTAR",
                        valor: 2
                    }
                ],
                pendencias: [
                    {
                        id: 1,
                        nome: "DOCS. DIGITAIS",
                        valor: 1,
						cdPendencia: "1"
                    },
                    {
                        id: 2,
                        nome: "DOCS. FÍSICOS",
                        valor: 5,
						cdPendencia: "2"
                    },
                    {
                        id: 3,
                        nome: "GRAVAME",
                        valor: 1,
						cdPendencia: "3"
                    }
                ]
            }
        });
    }
};
