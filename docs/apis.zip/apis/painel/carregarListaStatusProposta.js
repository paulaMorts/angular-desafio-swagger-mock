var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de status de uma proposta",
        path: "/filtroProposta/carregarListaStatusProposta",
        method: "GET",
        summary: "Retorna a lista de status de uma proposta",
        notes: "Retorna a lista de status de uma proposta",
        type: "carregarListaStatusPropostaResponse",
        nickname: "carregarListaStatusProposta",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de status de proposta retornada com sucesso",
                responseModel: "carregarListaStatusPropostaResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de status de uma proposta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "statusProposta": [{
                "dsStatus": "TODOS",
                "idStatus": "ALL"
            },
            {
              "idStatus": "1",
              "dsStatus": "EM ANALISE TESTE"
            },
			{
              "idStatus": "2",
              "dsStatus": "APROVADAS"
            },
			{
              "idStatus": "6",
              "dsStatus": "DADOS A COMPLEMENTAR"
            }]
        });
    }
};
