var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var moment = require('moment');


module.exports = {
    spec: {
        description: "Retorna uma lista de propostas respeitando o filtro passado.",
        path: "/proposta/listar",
        method: "GET",
        summary: "Retorna uma lista de propostas respeitando o filtro passado",
        notes: "Retorna uma lista de propostas respeitando o filtro passado",
        type: "listarResponse",
        nickname: "listar",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("dtInicio", "Data de Início", "date"),
            paramTypes.query("dtFim", "Data de Término", "date"),
            paramTypes.query("idUsuario", "Id do Usuário", "string", true),
            paramTypes.query("idStatus", "Id do Status", "string", true),
            paramTypes.query("nrCpfCnpj", "Número do CPF/CNPJ", "number"),
            paramTypes.query("fgAtualizar", "Flag de Atualização", "boolean", true),
            paramTypes.query("nrPagina", "Número da Página", "number", true),
            paramTypes.query("dsOrdenacao", "Descrição da Ordenação", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Descrição da Direção de Ordenação", "string"),
            paramTypes.query("cdTab", "Código da Loja", "string", true),
            paramTypes.query("cdPendencia", "Identificador da pendência", "string", true)
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de propostas retornada com sucesso",
                responseModel: "listarResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de propostas",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var ordenacaoParams = ["dtInclusao", "nmCliente", "nrCpfCnpj", "vlVeiculo", "dsMarca", "dsStatus"];
        var direcaoOrdenacaoParams = ["asc", "desc"];

        var ontem = moment().add(-1, 'days');
        ontem = moment(ontem).format();
        var anteontem = moment().add(-2, 'days');
        anteontem = moment(anteontem).format();

        var propostas = [
            {
                "idProposta": 1,
                "dtInclusao": anteontem,
                "nmCliente": "Joao",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 31200,
                "dsMarca": "Mercedes",
                "dsModelo": "V8 TURBO",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 2,
                "dtInclusao": ontem,
                "nmCliente": "Bruno",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 30000,
                "dsMarca": "Monza",
                "dsModelo": "Model S",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 3,
                "dtInclusao": anteontem,
                "nmCliente": "Henrique",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 100000,
                "dsMarca": "Ferrari",
                "dsModelo": "Model T",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 4,
                "dtInclusao": ontem,
                "nmCliente": "Thiago",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 810000,
                "dsMarca": "Porsche",
                "dsModelo": "Model X",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 5,
                "dtInclusao": ontem,
                "nmCliente": "Francis",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 20000,
                "dsMarca": "Sentra",
                "dsModelo": "SL",
                "dsStatus": "Dados a Complementar"
            },
            {
                "idProposta": 6,
                "dtInclusao": ontem,
                "nmCliente": "Ricardo",
                "nrCpfCnpj": "33651110931",
                "vlVeiculo": 37500,
                "dsMarca": "Nissan",
                "dsModelo": "Vx Sl",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 7,
                "dtInclusao": ontem,
                "nmCliente": "Eduardo",
                "nrCpfCnpj": "52613488468",
                "vlVeiculo": 124000,
                "dsMarca": "Audi",
                "dsModelo": "A4",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 8,
                "dtInclusao": ontem,
                "nmCliente": "Thoamaz",
                "nrCpfCnpj": "17486420228",
                "vlVeiculo": 145400,
                "dsMarca": "Nissan",
                "dsModelo": "Mazda",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 9,
                "dtInclusao": anteontem,
                "nmCliente": "Felipe",
                "nrCpfCnpj": "41637326408",
                "vlVeiculo": 823400,
                "dsMarca": "Porsche",
                "dsModelo": "Model PS",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 10,
                "dtInclusao": ontem,
                "nmCliente": "Jefferson",
                "nrCpfCnpj": "87397312276",
                "vlVeiculo": 294300,
                "dsMarca": "Ferrari",
                "dsModelo": "X",
                "dsStatus": "Dados a Complementar"
            },
            {
                "idProposta": 11,
                "dtInclusao": ontem,
                "nmCliente": "William",
                "nrCpfCnpj": "75647496873",
                "vlVeiculo": 11900,
                "dsMarca": "Wolkswagen",
                "dsModelo": "Gol",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 12,
                "dtInclusao": ontem,
                "nmCliente": "Pelé",
                "nrCpfCnpj": "07556500772",
                "vlVeiculo": 335100,
                "dsMarca": "Wolkswagen",
                "dsModelo": "Polo",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 13,
                "dtInclusao": anteontem,
                "nmCliente": "Jonathan",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 91200,
                "dsMarca": "Ferrari",
                "dsModelo": "Inferno",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 14,
                "dtInclusao": anteontem,
                "nmCliente": "Fabrício",
                "nrCpfCnpj": "72375766407",
                "vlVeiculo": 90120,
                "dsMarca": "Audi",
                "dsModelo": "TT",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 15,
                "dtInclusao": anteontem,
                "nmCliente": "Lucas",
                "nrCpfCnpj": "80968378854",
                "vlVeiculo": 3128000,
                "dsMarca": "Ford",
                "dsModelo": "Focus",
                "dsStatus": "Dados a Complementar"
            }
        ];

        var isUltimos30Dias = function (inicio, fim, data) {
            var compareDate = moment(data, moment.ISO_8601);
            var startDate = moment(inicio, moment.ISO_8601);
            var endDate = moment(fim, moment.ISO_8601);
            return compareDate.isBetween(startDate, endDate);
        }

        if (!req.query.nrCpfCnpj && !req.query.dtInicio){
            res.status(500).send({
                error: {
                code: "101",
                message: "Favor informar a data de início e/ou cpfCnpj."
                }
            });
        }
        else if (req.query.dsOrdenacao && ordenacaoParams.indexOf(req.query.dsOrdenacao) < 0){
            res.status(500).send({
                error: {
                code: "101",
                message: "Parâmetro de ordenação inválido."
            }
            });
        }
        else if (req.query.dsDirecaoOrdenacao && direcaoOrdenacaoParams.indexOf(req.query.dsDirecaoOrdenacao) < 0){
            res.status(500).send({
                error: {
                code: "101",
                message: "Parâmetro de direção de ordenação inválido."
            }
            });
        } else if ( req.query.nrCpfCnpj && req.query.nrCpfCnpj !== "") {
            propostas = _.filter(propostas, { "nrCpfCnpj": req.query.nrCpfCnpj });
            res.status(200).send({
                "propostas":propostas,
                "paginacao": {
                    "nrPagina": "1",
                    "qtItens": "5",
                    "qtResultados": "6",
                    "qtPaginas": "2"
                }
            });
        } else if (req.query.dtInicio && req.query.dtFim && (req.query.dtInicio !== "") && (req.query.dtFim !== "")) {
            propostas = _.filter(propostas, function(o) {
                return isUltimos30Dias(req.query.dtInicio, req.query.dtFim, o.dtInclusao)
            });
            propostas = _.orderBy(propostas, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

            var start = (req.query.nrPagina*5)-5;
            propostas = propostas.slice(start, start+5);
            setTimeout(function () {
                res.status(200).send({
                    "propostas":propostas,
                    "paginacao": {
                        "nrPagina": req.query.nrPagina,
                        "qtItens": 5,
                        "qtResultados": 15,
                        "qtPaginas": 3
                    }
                });
            }, 3000);

        } else {
            if(req.query.dsOrdenacao && req.query.dsOrdenacao !== "")
            propostas = _.orderBy(propostas, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

            var start = (req.query.nrPagina*5)-5;
            propostas = propostas.slice(start, start+5);
            setTimeout(function () {
                res.status(200).send({
                    "propostas":propostas,
                    "paginacao": {
                        "nrPagina": req.query.nrPagina,
                        "qtItens": 5,
                        "qtResultados": 15,
                        "qtPaginas": 3
                    }
                });
            }, 3000);
        }
    }
};
