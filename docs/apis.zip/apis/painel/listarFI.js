var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var moment = require('moment');

module.exports = {
    spec: {
        description: "Retorna uma lista de propostas F&I respeitando o filtro passado.",
        path: "/proposta/listarFI",
        method: "GET",
        summary: "Retorna uma lista de propostas F&I respeitando o filtro passado.",
        notes: "Retorna uma lista de propostas F&I respeitando o filtro passado.",
        type: "listarFIResponse",
        nickname: "listarFI",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("nrCpfCnpj", "Número do CPF/CNPJ", "number"),
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de propostas F&I retornada com sucesso",
                responseModel: "listarFIResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de propostas",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var ontem = moment().add(-1, 'days');
        ontem = moment(ontem).format();
        var anteontem = moment().add(-2, 'days');
        anteontem = moment(anteontem).format();

        var propostasFI = [
            {
                "idProposta": 1,
                "dtInclusao": anteontem,
                "nmCliente": "Joao",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 31200,
                "dsMarca": "Mercedes",
                "dsModelo": "V8 TURBO",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 2,
                "dtInclusao": ontem,
                "nmCliente": "Bruno",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 30000,
                "dsMarca": "Monza",
                "dsModelo": "Model S",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 3,
                "dtInclusao": anteontem,
                "nmCliente": "Henrique",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 100000,
                "dsMarca": "Ferrari",
                "dsModelo": "Model T",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 4,
                "dtInclusao": ontem,
                "nmCliente": "Thiago",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 810000,
                "dsMarca": "Porsche",
                "dsModelo": "Model X",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 5,
                "dtInclusao": ontem,
                "nmCliente": "Francis",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 20000,
                "dsMarca": "Sentra",
                "dsModelo": "SL",
                "dsStatus": "Dados a Complementar"
            },
            {
                "idProposta": 6,
                "dtInclusao": ontem,
                "nmCliente": "Ricardo",
                "nrCpfCnpj": "33651110931",
                "vlVeiculo": 37500,
                "dsMarca": "Nissan",
                "dsModelo": "Vx Sl",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 7,
                "dtInclusao": ontem,
                "nmCliente": "Eduardo",
                "nrCpfCnpj": "52613488468",
                "vlVeiculo": 124000,
                "dsMarca": "Audi",
                "dsModelo": "A4",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 8,
                "dtInclusao": ontem,
                "nmCliente": "Thoamaz",
                "nrCpfCnpj": "17486420228",
                "vlVeiculo": 145400,
                "dsMarca": "Nissan",
                "dsModelo": "Mazda",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 9,
                "dtInclusao": anteontem,
                "nmCliente": "Felipe",
                "nrCpfCnpj": "41637326408",
                "vlVeiculo": 823400,
                "dsMarca": "Porsche",
                "dsModelo": "Model PS",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 10,
                "dtInclusao": ontem,
                "nmCliente": "Jefferson",
                "nrCpfCnpj": "87397312276",
                "vlVeiculo": 294300,
                "dsMarca": "Ferrari",
                "dsModelo": "X",
                "dsStatus": "Dados a Complementar"
            },
            {
                "idProposta": 11,
                "dtInclusao": ontem,
                "nmCliente": "William",
                "nrCpfCnpj": "75647496873",
                "vlVeiculo": 11900,
                "dsMarca": "Wolkswagen",
                "dsModelo": "Gol",
                "dsStatus": "Em Análise"
            },
            {
                "idProposta": 12,
                "dtInclusao": ontem,
                "nmCliente": "Pelé",
                "nrCpfCnpj": "07556500772",
                "vlVeiculo": 335100,
                "dsMarca": "Wolkswagen",
                "dsModelo": "Polo",
                "dsStatus": "Proposta Aprovada"
            },
            {
                "idProposta": 13,
                "dtInclusao": anteontem,
                "nmCliente": "Jonathan",
                "nrCpfCnpj": "32427245267",
                "vlVeiculo": 91200,
                "dsMarca": "Ferrari",
                "dsModelo": "Inferno",
                "dsStatus": "Proposta Negada"
            },
            {
                "idProposta": 14,
                "dtInclusao": anteontem,
                "nmCliente": "Fabrício",
                "nrCpfCnpj": "72375766407",
                "vlVeiculo": 90120,
                "dsMarca": "Audi",
                "dsModelo": "TT",
                "dsStatus": "Desistência de Proposta"
            },
            {
                "idProposta": 15,
                "dtInclusao": anteontem,
                "nmCliente": "Lucas",
                "nrCpfCnpj": "80968378854",
                "vlVeiculo": 3128000,
                "dsMarca": "Ford",
                "dsModelo": "Focus",
                "dsStatus": "Dados a Complementar"
            },
            {
                "idProposta": 16,
                "dtInclusao": anteontem,
                "nmCliente": "Michael Phelps",
                "nrCpfCnpj": "35065145806",
                "vlVeiculo": 49990,
                "dsMarca": "Nissan",
                "dsModelo": "Mart",
                "dsStatus": "Proposta Aprovada"
            }
        ];

        if( req.query.nrCpfCnpj && req.query.nrCpfCnpj !== ""){
            propostasFI = _.filter(propostasFI, { "nrCpfCnpj": req.query.nrCpfCnpj });
            res.status(200).send({
                "propostasFI": propostasFI
            });
        }else{
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Favor informar um CPF/CNPJ válido."
                }
            });
        }
    }
};
