var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de usuários",
        path: "/filtroProposta/carregarListaUsuarios/{cdTab}",
        method: "GET",
        summary: "Retorna a lista de usuários",
        notes: "Retorna a lista de usuários",
        type: "carregarListaUsuariosResponse",
        nickname: "carregarListaUsuarios",
        produces: ["application/json"],
        parameters: [paramTypes.path("cdTab", "Código da Loja", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de usuários retornada com sucesso",
                responseModel: "carregarListaUsuariosResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de usuários",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {

        var usuarios = {
            "1": [{
                "dsUsuario": "TODOS",
                "idUsuario": "ALL"
            },
            {
                "dsUsuario": "João",
                "idUsuario": "1"
            },
            {
                "dsUsuario": "Maria",
                "idUsuario": "2"
            },
            {
                "dsUsuario": "José",
                "idUsuario": "3"
            }],
            "2": [{
                "dsUsuario": "TODOS",
                "idUsuario": "ALL"
            },
            {
                "dsUsuario": "Neymar",
                "idUsuario": "4"
            },
            {
                "dsUsuario": "Pelé",
                "idUsuario": "5"
            },
            {
                "dsUsuario": "Ricardo Oliveira",
                "idUsuario": "6"
            }],
            "3": [{
                "dsUsuario": "TODOS",
                "idUsuario": "ALL"
            },
            {
                "dsUsuario": "David Luiz",
                "idUsuario": "7"
            },
            {
                "dsUsuario": "Luiz Suarez",
                "idUsuario": "8"
            },
            {
                "dsUsuario": "Payet",
                "idUsuario": "9"
            }]
        };

        if (req.params.cdTab) {
            res.status(200).send({
                "usuarios": usuarios[req.params.cdTab]
            });
        }
        else {
            res.status(500).send({
                error: {
                code: "101",
                message: "Erro ao carregar lista de usuários."
            }
            });
        }
    }
};
