module.exports = {
    spec: {
        description: "Retorna lista de lojas do usuário.",
        path: "/painel/getLojas",
        method: "GET",
        summary: "Retorna lista de lojas do usuário",
        notes: "Retorna lista de lojas do usuário",
        type: "getLojasResponse",
        nickname: "getLojas",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de lojas do usuário retornada com sucesso",
                responseModel: "getLojasResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de lojas do usuário",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaLojas": [
                {
                    "cdTab": "1",
                    "nmLoja": "VW Norte"
                },
                {
                    "cdTab": "2",
                    "nmLoja": "VW Centro"
                },
                {
                    "cdTab": "3",
                    "nmLoja": "VW Leste"
                }
            ]
        });
    }
};
