var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
    spec: {
        description: "Retorna uma lista de etiquetas disponíveis",
        path: "/etiqueta/getEtiquetas",
        method: "GET",
        summary: "Retorna uma lista de etiquetas disponíveis",
        notes: "Retorna uma lista de etiquetas disponíveis",
        type: "getEtiquetasResponse",
        nickname: "getEtiquetas",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("nrPagina", "Número da página requisitada.", "number"),
            paramTypes.query("dsOrdenacao", "Opções de ordenação (idEtiqueta, dtGeracao).", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Opções para direção da ordenação (asc, desc).", "string"),
            paramTypes.query("nrProposta", "Número da proposta", "string"),
            paramTypes.query("nrCpfCnpj", "Número do cpf do cliente", "string"),
            paramTypes.query("nmCliente", "Nome do cliente", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de etiquetas retornada com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao recuperar lista de etiquetas",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var etiquetas = [
            {
                "idEtiqueta": 1,
                "cdBarras": 111000000001,
                "dtGeracao": new Date("2016/06/10"),
                "dtEnvio": undefined,
                "dtRecebimentoEmpresaGuarda": undefined,
                "dsStatus": "Gerada",
                "dsModal": undefined,
                "dsMensagem": undefined,
                "nrServicoPac": undefined,
                "nrObjetoRastreio": undefined,
                "qtdPropostasVinculadas": undefined
            },
            {
                "idEtiqueta": 2,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/20"),
                "dtEnvio": new Date("2016/06/25"),
                "dtRecebimentoEmpresaGuarda": undefined,
                "dsStatus": "Enviada",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 2
            },
            {
                "idEtiqueta": 3,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/20"),
                "dtEnvio": new Date("2016/06/25"),
                "dtRecebimentoEmpresaGuarda": undefined,
                "dsStatus": "Cancelada",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 2
            },
            {
                "idEtiqueta": 4,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/20"),
                "dtEnvio": new Date("2016/06/20"),
                "dtRecebimentoEmpresaGuarda": undefined,
                "dsStatus": "Finalizada – não recebida",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 2
            },
            {
                "idEtiqueta": 5,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/01"),
                "dtEnvio": new Date("2016/06/20"),
                "dtRecebimentoEmpresaGuarda": new Date("2016/07/03"),
                "dsStatus": "Finalizada – recebida",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 4
            },
            {
                "idEtiqueta": 6,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/04"),
                "dtEnvio": new Date("2016/06/20"),
                "dtRecebimentoEmpresaGuarda": "",
                "dsStatus": "Finalizada – não recebida",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 3
            },
            {
                "idEtiqueta": 7,
                "cdBarras": 111000000010,
                "dtGeracao": new Date("2016/06/09"),
                "dtEnvio": new Date("2016/06/20"),
                "dtRecebimentoEmpresaGuarda": new Date("2016/07/03"),
                "dsStatus": "Finalizada – não recebida",
                "dsModal": "Motoboy",
                "dsMensagem": "",
                "nrServicoPac": 8888888,
                "nrObjetoRastreio": 999999,
                "qtdPropostasVinculadas": 5
            }
        ];

        var resultados = 9;
        // se foi passado, realiza a ordenacao
        if (req.query.dsOrdenacao)
            etiquetas = _.orderBy(etiquetas, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);
        if (req.query.nrProposta) {
            etiquetas = etiquetas.slice(1, 2);
            resultados = 1;
        }
        if (req.query.nrCpfCnpj) {
            etiquetas = etiquetas.slice(1, 3);
            resultados = 1;
        }
        if (req.query.nmCliente) {
            etiquetas = etiquetas.slice(1, 6);
            resultados = 1;
        }
        //se foi passado, realiza a paginacao (retorna resultados de 5 em 5)
        if (req.query.nrPagina) {
            var start = (req.query.nrPagina * 5) - 5;
            etiquetas = etiquetas.slice(start, start + 5);

            //retorna o resultado
            res.status(200).send({
                "tipoEnvio": "C",
                "etiquetasList": etiquetas,
                "paginacao": {
                    "nrPagina": req.query.nrPagina,
                    "qtItens": 5,
                    "qtResultados": resultados,
                    "qtPaginas": 2
                }
            });
            //se nao foi passada paginacao, retorna todos os resultados
        } else {
            res.status(200).send({"etiquetasList": etiquetas});
        }

    }
};
