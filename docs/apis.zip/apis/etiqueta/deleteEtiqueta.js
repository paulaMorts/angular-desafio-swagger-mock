var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Realiza o cancelamento de uma etiqueta já existente (atualização de status para 'Cancelada')",
        path: "/etiqueta/deleteEtiqueta/{idEtiqueta}",
        method: "POST",
        summary: "Realiza o cancelamento de uma etiqueta já existente (atualização de status para 'Cancelada')",
        notes: "Realiza o cancelamento de uma etiqueta já existente (atualização de status para 'Cancelada')",
        type: "deleteEtiquetaResponse",
        nickname: "deleteEtiqueta",
        produces: ["application/json"],
        parameters: [paramTypes.path("idEtiqueta", "Identificador da etiqueta", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Etiqueta cancelada com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao cancelar etiqueta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
      var etiqueta = {
                        "idEtiqueta": req.params.idEtiqueta
                     };


        if(req.params.idEtiqueta >= 500) {
          res.status(500).send({
            error: {
              code: "105",
              message: "Erro ao cancelar etiqueta!"
            }});
        } else if (req.params.idEtiqueta >= 100) {
          res.status(500).send({
            error: {
              code: "106",
              message: "Etiqueta não localizada!"
            }});
        }
        else {
            res.status(200).send(etiqueta);
        }
    }
};
