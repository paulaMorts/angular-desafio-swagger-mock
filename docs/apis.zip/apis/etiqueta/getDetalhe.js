var paramTypes = require("swagger-node-express").paramTypes;
var moment = require('moment');

module.exports = {
    spec: {
        description: "Retorna os detalhes de uma etiqueta",
        path: "/etiqueta/getDetalhe/{idEtiqueta}",
        method: "GET",
        summary: "Retorna os detalhes de uma etiqueta",
        notes: "Retorna os detalhes de uma etiqueta",
        type: "getDetalheResponse",
        nickname: "getDetalhe",
        produces: ["application/json"],
        parameters: [paramTypes.path("idEtiqueta", "Identificador da etiqueta", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Etiqueta recuperado com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao recuperar etiqueta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var etiqueta = {
            "idEtiqueta": 1,
            "tipoEnvio": "C",
            "cdBarras": undefined,
            "dtGeracao": undefined,
            "dtEnvio": undefined,
            "dtRecebimentoEmpresaGuarda": undefined,
            "dsStatus": undefined,
            "dsModal": undefined,
            "dsMensagem": undefined,
            "nrServicoPac": undefined,
            "nrObjetoRastreio": undefined,
            "propostasVinculadasList": [
                {
                    "idProposta": 444,
                    "cdProposta": 9283740293,
                    "dtInclusao": new Date("2016/06/19"),
                    "nmCliente": "Jose da Silva",
                    "nrCpfCnpj": 56496639069
                },
                {
                    "idProposta": 555,
                    "cdProposta": 1928394857,
                    "dtInclusao": new Date("2016/06/03"),
                    "nmCliente": "Pedro Alves",
                    "nrCpfCnpj": 11930293848
                },
                {
                    "idProposta": 666,
                    "cdProposta": 5464569291,
                    "dtInclusao": new Date("2016/06/14"),
                    "nmCliente": "Neymar Jr",
                    "nrCpfCnpj": 23453452342
                }
            ]
        };
        var teste = new Date("2016/06/20");

        if (req.params.idEtiqueta == 1) {
            etiqueta.idEtiqueta = 1;
            etiqueta.dsStatus = "Gerada";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        } else if (req.params.idEtiqueta == 2) {
            etiqueta.idEtiqueta = 2;
            etiqueta.dsStatus = "Enviada";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            etiqueta.dtEnvio = moment().add(-5, 'days').format();
            etiqueta.nrObjetoRastreio = 1231253;
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        } else if (req.params.idEtiqueta == 3) {
            etiqueta.idEtiqueta = 3;
            etiqueta.dsStatus = "Cancelada";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            etiqueta.dtEnvio = moment().add(-5, 'days').format();
            etiqueta.nrObjetoRastreio = 444343;
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        } else if (req.params.idEtiqueta == 4) {
            etiqueta.idEtiqueta = 4;
            etiqueta.dsStatus = "Finalizada - não recebida";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            etiqueta.dtEnvio = moment().add(-5, 'days').format();
            etiqueta.nrObjetoRastreio = 1231253;
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        } else if (req.params.idEtiqueta == 5) {
            etiqueta.idEtiqueta = 5;
            etiqueta.dsStatus = "Finalizada - recebida";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            etiqueta.dtEnvio = moment().add(-5, 'days').format();
            etiqueta.nrObjetoRastreio = 1231253;
            etiqueta.dtRecebimentoEmpresaGuarda = moment().add(-2, 'days').format();
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        } else if (req.params.idEtiqueta > 5) {
            etiqueta.idEtiqueta = req.params.idEtiqueta;
            etiqueta.dsStatus = "Finalizada - recebida";
            etiqueta.dtGeracao = moment().add(-10, 'days').format();
            etiqueta.dtEnvio = moment().add(-5, 'days').format();
            etiqueta.nrObjetoRastreio = 1231253;
            etiqueta.dtRecebimentoEmpresaGuarda = moment().add(-2, 'days').format();
            res.status(200).json({"etiquetaDetalhe": etiqueta});
        }
    }
};
