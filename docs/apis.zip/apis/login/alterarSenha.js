var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Serviço que altera a senha do usuário do sistema.",
        path: "/authenticate/changePassword/{idUsuario}",
        method: "POST",
        summary: "Serviço que altera a senha do usuário do sistema.",
        notes: "Serviço que altera a senha do usuário do sistema.",
        type: "alterarSenhaResponse",
        nickname: "alterarSenha",
        produces: ["application/json"],
        parameters: [paramTypes.path("idUsuario", "Identificador do usuário.", "number"),
            paramTypes.body("senhaUsuario", "Grupo com os dados necessários para alterar a senha do usuário", "senhaUsuarioRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        });
    }
};