module.exports = {
    spec: {
        description: "Executa o procedimento de logout",
        path: "/authenticate/revoke",
        method: "GET",
        summary: "Executa o procedimento de logout",
        notes: "Finaliza a sessão do usuário na aplicação.",
        type: "revokeLoginResponse",
        nickname: "revokeLogin",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Logout realizado com sucesso",
				responseModel: "revokeLoginResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar logout",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
		res.status(200).send({
		  "logout": {
			"revoked": true
		  }
		});
    }
};
