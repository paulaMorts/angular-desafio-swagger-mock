var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Executa o a recuperação de usuário",
        path: "/login/recuperarUsuario/{email}",
        method: "POST",
        summary: "Executa o a recuperação de usuário",
        notes: "Solicita, por meio do E-mail, a recuperação do usuário. ",
        type: "recuperarUsuarioResponse",
        nickname: "recuperarUsuario",
        produces: ["application/json"],
        parameters: [paramTypes.path("email", "E-mail do agente que solicita a recuperação de usuário", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Usuário não encontrado",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        })
    }
};