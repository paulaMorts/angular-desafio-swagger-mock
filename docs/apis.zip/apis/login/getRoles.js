var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Obtem as permissoes do usuario logado",
        path: "/login/getRoles/",
        method: "GET",
        summary: "Obtem as permissoes do usuario logado",
        notes: "Obtem as permissoes do usuario logado",
        type: "getRolesResponse",
        nickname: "getRoles",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Permissões retornadas com sucesso",
                responseModel: "getRolesResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter permissões",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //res.status(200).send(401);
        res.status(200).send({
                "perfil": {
                    "id_usuario": "1",
                    "role": "MASTER,MEU_ACESSO_PORT,CONS_PORTAL,PROPOSTA_PORTAL,COMENT_PORTAL,CHECAGEM_PORTAL,GEST_USUA_PORTA,CON_GEST_USUA_P,ADMINISTRADOR,ETIQUETA_PORT"
                }
            }
        );
    }
};
