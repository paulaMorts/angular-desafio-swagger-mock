var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Executa o procedimento de login",
        path: "/authenticate/execute",
        method: "POST",
        summary: "Executa o procedimento de login",
        notes: "Recebe os dados de usuario e senha e realiza a autenticação. É possível que sejam solicitados token e/ou captcha para validação do acesso. " +
        "No caso de exceção, são possíveis os cenários: <\/br><ul>" +
        "<li>- Usuario/senha/captcha incorreto. (101)<\/li>" +
        "<li>- Acesso bloqueado. (102)<\/li>" +
        "<li>- Captcha necessário. (103)<\/li>" +
        "<li>- Usuario normal bloqueado. (104)<\/li>" +
        "<li>- Usuario master bloqueado. (105)<\/li>" +
        "<\/ul>",
        type: "postLoginResponse",
        nickname: "postLogin",
        produces: ["application/json"],
        parameters: [paramTypes.body("postLoginRequest", "Informações para autenticação", "postLoginRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Login realizado com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao realizar login",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.body.login.id_user === "101") {
            res.status(500).send({
                error: {
                    code: "000-U",
                    message: "Usu&aacute;rio e&#x2f;ou senha inv&aacute;lidos&#x21;"
                }
            });
        } else if (req.body.login.id_user === "102") {
            res.status(500).send({
                error: {
                    code: "102",
                    message: "Acesso bloqueado."
                }
            });
        } else if (req.body.login.id_user === "103" && (!req.body.captcha || req.body.captcha.response == '')) {
            res.status(500).send({
                error: {
                    code: "103",
                    message: "Captcha necessário."
                }
            });
        } else if (req.body.login.id_user === "104") {
            res.status(500).send({
                error: {
                    code: "104",
                    message: "Usuario normal bloqueado."
                }
            });
        } else if (req.body.login.id_user === "105") {
            res.status(500).send({
                error: {
                    code: "105",
                    message: "Usuario master bloqueado."
                }
            });
        } else if (req.body.login.id_user === "200") {
            res.status(200).send({
                "login": {
                    "ds_url": "iframePrincipal.html?funcao=index",
                    "aviso": "",
                    "id_usuario": 1,
                    "role":"ADMINISTRADOR,FINANCEIRO_PORT,PROPOSTA_PORTAL,COMENT_PORTAL,MEU_ACESSO_PORT,CHECAGEM_PORTAL,GEST_USUA_PORTA,CONS_PORTAL,CON_GEST_USUA_P",
                    "areaNegocio":[{"id": 10, "isDefault": true, "nome": "Bens & Serviços"}, {"id": 30, "nome": "Financiamento Auto"}]

                },
                "authorization-identity": {
                    "identity": "com.viverebrasil.commons.entidades.UserIdentity@e7876f"
                }
            });
        }
        else
        {
            res.status(200).send({
                "login": {
                    "ds_url": "iframePrincipal.html?funcao=index",
                    "aviso": "",
                    "id_usuario": 1,
                    "role":"ADMINISTRADOR,FINANCEIRO_PORT,PROPOSTA_PORTAL,COMENT_PORTAL,MEU_ACESSO_PORT,CHECAGEM_PORTAL,GEST_USUA_PORTA,CONS_PORTAL,CON_GEST_USUA_P",
                    "areaNegocio":[{"id": 10, "isDefault": true, "nome": "Bens & Serviços"}, {"id": 30, "nome": "Financiamento Auto"}]

                },
                "authorization-identity": {
                    "identity": "com.viverebrasil.commons.entidades.UserIdentity@e7876f"
                }
            });
        }
    }
};