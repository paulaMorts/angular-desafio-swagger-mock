var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Executa o a recuperação de senha",
        path: "/login/recuperarSenha/{nrCpf}",
        method: "POST",
        summary: "Executa o a recuperação de senha",
        notes: "Solicita, por meio do CPF, a recuperação da senha. Caso o CPF seja inválido, o e-mail não é enviado.",
        type: "recuperarSenhaResponse",
        nickname: "recuperarSenha",
        produces: ["application/json"],
        parameters: [paramTypes.path("nrCpf", "Numero do CPF do agente que solicita a recuperação da senha", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Usuário não encontrado",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        })
    }
};