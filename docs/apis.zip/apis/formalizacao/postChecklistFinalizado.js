var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Finaliza o envio de documentos do checklist.",
        path: "/checklistPendente/finalizado/{idProposta}",
        method: "POST",
        summary: "Finaliza o envio de documentos do checklist.",
        notes: "Finaliza o envio de documentos do checklist.",
        type: "postChecklistPendenteResponse",
        nickname: "postFinalizarChecklistPendente",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Envio de documentos de checklist finalizada",
                responseModel: "postChecklistPendenteResponse"
            },
            {
                code: "500",
                reason: "Erro ao concluir o envio de documentos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.idProposta == 2) {
			res.status(500).send({
				"error": {
					"message": "Erro ao enviar checklist"
				}
			});	
		}
		else {
			res.status(200).send({
				"retorno": {
					"dsMensagem": "OK"
				}
			});	
		}
    }
};