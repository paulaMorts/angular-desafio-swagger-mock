module.exports = {
    spec: {
        description: "Retorna lista de domínio de situação de pneu.",
        path: "/dadosComplementares/getListaPneu",
        method: "GET",
        summary: "Retorna lista de domínio de situação de pneu.",
        notes: "Retorna lista de domínio de situação de pneu.",
        type: "getPneuResponse",
        nickname: "getPneu",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de pneus retornada com sucesso",
                responseModel: "getPinturaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de pneus.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaSituacaoPneu": [
                {
                    "idSitPneu": "2",
                    "dsSitPneu": "Bom estado"
                },
                {
                    "idSitPneu": "1",
                    "dsSitPneu": "Novos"
                },
                {
                    "idSitPneu": "3",
                    "dsSitPneu": "Péssimo"
                }
            ]
        });
    }
};