var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de contas correntes.",
        path: "/contaCorrente/listar/{idProposta}",
        method: "GET",
        summary: "Retorna a lista de contas correntes.",
        notes: "Recebe como parâmetro o ID da proposta e retorna a lista de contas correntes para pagamento.",
        type: "getContasCorrenteResponse",
        nickname: "getContasCorrente",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Id da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de contas corrente retornada com sucesso",
                responseModel: "getContasCorrenteResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca da lista de contas corrente",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "contasCorrentes": [
                {
                    "cdTipoConta": 1,
                    "fgContaPrincipal": false,
                    "nrAgencia": 123,
                    "nrBanco": 33,
					"dsNomeBanco": "SANTANDER",
                    "nrBancoCompensacao": 33,
                    "nrConta": 12344,
                    "nrDigitoAgencia": 1,
                    "nrDigitoConta": 3
                },
                {
                    "cdTipoConta": 1,
                    "fgContaPrincipal": true,
                    "nrAgencia": 312,
                    "nrBanco": 33,
					"dsNomeBanco": "SANTANDER",
                    "nrBancoCompensacao": 33,
                    "nrConta": 444222,
                    "nrDigitoAgencia": 3,
                    "nrDigitoConta": 4
                }
            ],
            "boleto":{
                "exibeFlagBoleto":"S"
            },
            "fgPagamentoCompartilhado": "S",
            "tabsCompartilhadas": [
                {
                  "cdTab": "1",
                  "dsTab": "VM Zona Sul"
                },
                {
                  "cdTab": "2",
                  "dsTab": "VM Zona Norte"
                },
                {
                  "cdTab": "3",
                  "dsTab": "VM Zona Leste"
                },
                {
                  "cdTab": "4",
                  "dsTab": "VM Zona Oeste"
                },
                {
                  "cdTab": "5",
                  "dsTab": "Caoa Zona Sul"
                },
                {
                  "cdTab": "6",
                  "dsTab": "Caoa Zona Norte"
                },
                {
                  "cdTab": "7",
                  "dsTab": "Caoa Zona Leste"
                },
                {
                  "cdTab": "8",
                  "dsTab": "Caoa Zona Oeste"
                }
            ]
        });
    }
};