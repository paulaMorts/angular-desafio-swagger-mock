var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de documentos (checklist).",
        path: "/checklist/get/{idProposta}",
        method: "GET",
        summary: "Retorna a lista de documentos (checklist).",
        notes: "Recebe como parâmetro o ID da proposta e retorna a lista de documentos que devem ser carregados.",
        type: "getChecklistResponse",
        nickname: "getChecklist",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Checklist retornado com sucesso",
                responseModel: "getChecklistResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca do checklist",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var fgRequired = req.params.idProposta != 1 || req.params.idProposta != 10;
        var checklistBoletos = [
            {
                "idChecklist": "90",
                "nmDocumento": "Boleto",
                "dsOrientacao": "Boleto de pagamento",
                "fgIndexado": true,
                "tipoDocumento": "CO",
                "fgRequired": true
            }
        ];
		var checklist = [
                {
                    "idChecklist": "1",
                    "nmDocumento": "CNH",
                    "dsOrientacao": "Carteira de motorista",
                    "fgIndexado": true,
                    "fgPermiteIndexar": true,
                    "tipoDocumento": "CO",
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "0",
                        "qualidade": "80",
                        "orientacao": "P"
                    },
                    "fgRequired": fgRequired,
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "2",
                    "nmDocumento": "DOCUMENTO DE IDENTIDADE",
                    "dsOrientacao": "Documento de identificação do cliente",
                    "fgIndexado": false,
                    "fgPermiteIndexar": true,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "0",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "3",
                    "nmDocumento": "COMPROVANTE DE RESIDENCIA",
                    "dsOrientacao": "Comprovante de residência",
                    "fgIndexado": false,
                    "fgPermiteIndexar": true,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "4",
                    "nmDocumento": "PESQUISA DE DÉBITOS NO CPF/CNPJ",
                    "dsOrientacao": "Pesquisa de débitos no CPF/CNPJ",
                    "fgIndexado": true,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "0",
                        "qualidade": "80"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "5",
                    "nmDocumento": "PESQUISA DE PROTESTO NO CPF/CNPJ",
                    "dsOrientacao": "Pesquisa de protestos no CPF/CNPJ",
                    "fgIndexado": false,
                    "fgPermiteIndexar": true,
                    "tipoDocumento": "CO",
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "0",
                        "qualidade": "80"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "6",
                    "nmDocumento": "CERTIDÃO DE CASAMENTO",
                    "dsOrientacao": "Certidão de casamento ou declaração de união estável pública",
                    "fgIndexado": false,
                    "fgPermiteIndexar": true,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "768",
                        "largura": "980",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "7",
                    "nmDocumento": "OUTROS DOCUMENTOS DE CRÉDITO",
                    "dsOrientacao": "Outros documentos de crédito do veículo",
                    "fgIndexado": true,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "897",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "8",
                    "nmDocumento": "CONTRATO",
                    "dsOrientacao": "Contrato do veículo",
                    "fgIndexado": true,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "6789",
                        "largura": "0",
                        "qualidade": "80"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "9",
                    "nmDocumento": "FOTO DA PLACA TRASEIRA",
                    "dsOrientacao": "Foto da placa traseira",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "809",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "10",
                    "nmDocumento": "FOTO DA TRASEIRA DO VEÍCULO",
                    "dsOrientacao": "Foto da traseira do veículo",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "9789",
                        "largura": "678",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "11",
                    "nmDocumento": "FOTO DA FRENTE DO VEÍCULO",
                    "dsOrientacao": "Foto da frente do veículo",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "7665",
                        "largura": "0",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "12",
                    "nmDocumento": "FOTO LATERAL ESQUERDA DO VEÍCULO",
                    "dsOrientacao": "Foto da lateral esquerda do veículo",
                    "fgIndexado": true,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired
                },
                {
                    "idChecklist": "13",
                    "nmDocumento": "FOTO DIREITA DO VEÍCULO",
                    "dsOrientacao": "Foto da lateral direita do veículo",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "5678",
                        "largura": "0",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "14",
                    "nmDocumento": "FOTO DO ODÔMETRO",
                    "dsOrientacao": "Foto do odômetro do veículo",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "VC",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "600",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "15",
                    "nmDocumento": "DOCUMENTO DE IDENTIDADE AVALISTA",
                    "dsOrientacao": "Documento de identificação do avalista",
                    "fgIndexado": true,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "PR",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "34",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "16",
                    "nmDocumento": "COMPROVANTE DE RESIDENCIA AVALISTA",
                    "dsOrientacao": "Comprovante de residência do avalista",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "PR",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "300",
                        "largura": "600",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "17",
                    "nmDocumento": "CNPJ",
                    "dsOrientacao": "CNPJ",
                    "fgIndexado": false,
                    "fgPermiteIndexar": false,
                    "tipoDocumento": "PR",
                    "fgRequired": fgRequired,
                    "tipoCaptura": {
                        "altura": "2400",
                        "largura": "900",
                        "qualidade": "80",
                        "orientacao": "P"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    dataAtualizacao:"",
                    dsOrientacao:"Carteira Nacional de Habilitação com validade de até 30 dias após a data de vencimento.↵A categoria deve estar compatível com a categoria do veículo financiado.↵Não é aceita carteira de habilitação estrangeira. A imagem do documento deve ser legível.",
                    fgIndexado:false,
                    "fgPermiteIndexar": false,
                    fgRequired: fgRequired,
                    idChecklist:"6.876",
                    nmDocumento:"CNH",
                    tipoDocumento:"PR",
                    "tipoCaptura": {
                        "altura": "100",
                        "largura": "300",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                }
            ];

		if (req.params.idProposta == 10) {
			checklist = checklist.slice(0,1);
		}

        res.status(200).send({
            "checklist": checklist,
            "boletos": checklistBoletos
        });
    }
};
