var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Representa o servico para a impressao do compra certa.",
        path: "/formalizacao/getCompraCerta/{idProposta}",
        method: "GET",
        summary: "Representa o servico para a impressao do compra certa.",
        notes: "Recebe o ID da proposta e retorna o compra certa para impress�o",
        type: "getCompraCertaResponse",
        nickname: "getCompraCerta",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number", true)],
        errorResponses: [
            {
                code: "200",
                reason: "Contrato de compra certa retornado com sucesso",
                responseModel: "getContratoFinanciamentoResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter contrato de compra certa",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "PCP":{
                "bsContent" : "JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovVmVyc2lvbiAvMS40Ci9QYWdlcyAyIDAgUgo+PgplbmRvYmoKMyAwIG9iago8PAo+PgplbmRvYmoKMiAwIG9iago8PAovVHlwZSAvUGFnZXMKL0tpZHMgWzQgMCBSIDUgMCBSIDYgMCBSXQovQ291bnQgMwo+PgplbmRvYmoKNCAwIG9iago8PAovVHlwZSAvUGFnZQovTWVkaWFCb3ggWzAuMCAwLjAgNjEyLjAgNzkyLjBdCi9QYXJlbnQgMiAwIFIKL0NvbnRlbnRzIDcgMCBSCi9SZXNvdXJjZXMgOCAwIFIKL0Nyb3BCb3ggWzAuMCAwLjAgNjEyLjAgNzkyLjBdCi9Sb3RhdGUgMAo+PgplbmRvYmoKNSAwIG9iago8PAovVHlwZSAvUGFnZQovTWVkaWFCb3ggWzAuMCAwLjAgNjEyLjAgNzkyLjBdCi9QYXJlbnQgMiAwIFIKL0NvbnRlbnRzIDkgMCBSCi9SZXNvdXJjZXMgMTAgMCBSCi9Dcm9wQm94IFswLjAgMC4wIDYxMi4wIDc5Mi4wXQovUm90YXRlIDAKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1R5cGUgL1BhZ2UKL01lZGlhQm94IFswLjAgMC4wIDYxMi4wIDc5Mi4wXQovUGFyZW50IDIgMCBSCi9Db250ZW50cyAxMSAwIFIKL1Jlc291cmNlcyAxMiAwIFIKL0Nyb3BCb3ggWzAuMCAwLjAgNjEyLjAgNzkyLjBdCi9Sb3RhdGUgMAo+PgplbmRvYmoKNyAwIG9iago8PAovRmlsdGVyIFsvRmxhdGVEZWNvZGVdCi9MZW5ndGggMTMgMCBSCj4+CnN0cmVhbQ0KeJzTdzNQMDVQCEnjMlBI53IK4TIyMFAA4ZAULg1nZydNhZAsLtcQLgCmKAg6DQplbmRzdHJlYW0KZW5kb2JqCjggMCBvYmoKPDwKL0ZvbnQgMTQgMCBSCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWy9GbGF0ZURlY29kZV0KL0xlbmd0aCAxNSAwIFIKPj4Kc3RyZWFtDQp4nNN3M1AwNVAISeMyUEjncgrhMjIwUADhkBQuDWfXEE2FkCwu1xAuAKbeCE4NCmVuZHN0cmVhbQplbmRvYmoKMTAgMCBvYmoKPDwKL0ZvbnQgMTYgMCBSCj4+CmVuZG9iagoxMSAwIG9iago8PAovRmlsdGVyIFsvRmxhdGVEZWNvZGVdCi9MZW5ndGggMTcgMCBSCj4+CnN0cmVhbQ0KeJzTdzNQMDVQCEnjMlBI53IK4TIyMFAA4ZAULg1nH8fQ4FAfxyBPf02FkCwu1xAuAPnLCrYNCmVuZHN0cmVhbQplbmRvYmoKMTIgMCBvYmoKPDwKL0ZvbnQgMTggMCBSCj4+CmVuZG9iagoxMyAwIG9iago0NQplbmRvYmoKMTQgMCBvYmoKPDwKL0YwIDE5IDAgUgo+PgplbmRvYmoKMTUgMCBvYmoKNDUKZW5kb2JqCjE2IDAgb2JqCjw8Ci9GMCAyMCAwIFIKPj4KZW5kb2JqCjE3IDAgb2JqCjUzCmVuZG9iagoxOCAwIG9iago8PAovRjAgMjEgMCBSCj4+CmVuZG9iagoxOSAwIG9iago8PAovVHlwZSAvRm9udAovU3VidHlwZSAvVHlwZTEKL0Jhc2VGb250IC9IZWx2ZXRpY2EtQm9sZE9ibGlxdWUKL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcKPj4KZW5kb2JqCjIwIDAgb2JqCjw8Ci9UeXBlIC9Gb250Ci9TdWJ0eXBlIC9UeXBlMQovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkT2JsaXF1ZQovRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZwo+PgplbmRvYmoKMjEgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUxCi9CYXNlRm9udCAvSGVsdmV0aWNhLUJvbGRPYmxpcXVlCi9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nCj4+CmVuZG9iagp4cmVmCjAgMjIKMDAwMDAwMDAwMCA2NTUzNSBmDQowMDAwMDAwMDE1IDAwMDAwIG4NCjAwMDAwMDAwOTkgMDAwMDAgbg0KMDAwMDAwMDA3OCAwMDAwMCBuDQowMDAwMDAwMTY4IDAwMDAwIG4NCjAwMDAwMDAzMjEgMDAwMDAgbg0KMDAwMDAwMDQ3NSAwMDAwMCBuDQowMDAwMDAwNjMwIDAwMDAwIG4NCjAwMDAwMDA3NTQgMDAwMDAgbg0KMDAwMDAwMDc4OCAwMDAwMCBuDQowMDAwMDAwOTEyIDAwMDAwIG4NCjAwMDAwMDA5NDcgMDAwMDAgbg0KMDAwMDAwMTA4MCAwMDAwMCBuDQowMDAwMDAxMTE1IDAwMDAwIG4NCjAwMDAwMDExMzQgMDAwMDAgbg0KMDAwMDAwMTE2NyAwMDAwMCBuDQowMDAwMDAxMTg2IDAwMDAwIG4NCjAwMDAwMDEyMTkgMDAwMDAgbg0KMDAwMDAwMTIzOCAwMDAwMCBuDQowMDAwMDAxMjcxIDAwMDAwIG4NCjAwMDAwMDEzODEgMDAwMDAgbg0KMDAwMDAwMTQ5MSAwMDAwMCBuDQp0cmFpbGVyCjw8Ci9Sb290IDEgMCBSCi9JbmZvIDMgMCBSCi9JRCBbPERERjAxQjMyREU1QTQ4MDRFREI4OEZDNjQ1N0IyRDM2PiA8RERGMDFCMzJERTVBNDgwNEVEQjg4RkM2NDU3QjJEMzY+XQovU2l6ZSAyMgo+PgpzdGFydHhyZWYKMTYwMQolJUVPRgo="
            }
        });
    }
};
