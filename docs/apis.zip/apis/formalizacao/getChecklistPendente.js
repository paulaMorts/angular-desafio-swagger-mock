var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de documentos pendentes (checklist).",
        path: "/checklistPendente/get/{idProposta}",
        method: "GET",
        summary: "Retorna a lista de documentos pendentes (checklist).",
        notes: "Recebe como parâmetro o ID da proposta e retorna a lista de documentos pendentes que devem ser carregados.",
        type: "getChecklistPendenteResponse",
        nickname: "getChecklistPendente",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Checklist retornado com sucesso",
                responseModel: "getChecklistPendenteResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca do checklist",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var fgRequired = req.params.idProposta != 1;

        res.status(200).send({
            "checklist": [
                {
                    "idChecklist": "1",
                    "nmDocumento": "CNH",
                    "dsOrientacao": "Carteira de motorista",
                    "fgIndexado": false,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    tipoDocumento:"PR",
                    "tipoCaptura": {
                        "altura": "100",
                        "largura": "300",
                        "qualidade": "80",
                        "orientacao": "L"
                    },
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                },
                {
                    "idChecklist": "2",
                    "nmDocumento": "DOCUMENTO DE IDENTIDADE",
                    "dsOrientacao": "Documento de identificação do cliente",
                    "fgIndexado": false,
                    "tipoDocumento": "CO",
                    "fgRequired": fgRequired,
                    tipoDocumento:"PR",
                    "dataAtualizacao": "2016-07-18T00:00:00-0300"
                }
            ]

        });
    }
};
