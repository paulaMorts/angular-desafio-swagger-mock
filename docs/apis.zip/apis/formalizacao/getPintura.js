module.exports = {
    spec: {
        description: "Retorna lista de domínio de situação de pintura.",
        path: "/dadosComplementares/getListaPintura",
        method: "GET",
        summary: "Retorna lista de domínio de situação de pintura.",
        notes: "Retorna lista de domínio de situação de pintura.",
        type: "getPinturaResponse",
        nickname: "getListaPintura",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de pinturas retornada com sucesso",
                responseModel: "getPinturaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de pinturas.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaSituacaoPintura": [
                {
                    "idSitPintura": "1",
                    "dsSitPintura": "Boa"
                },
                {
                    "idSitPintura": "2",
                    "dsSitPintura": "Danificada"
                },
                {
                    "idSitPintura": "3",
                    "dsSitPintura": "Péssima"
                }
            ]
        });
    }
};