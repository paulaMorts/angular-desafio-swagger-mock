var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o tipo de contrato.",
        path: "/formalizacao/getTipoContrato/{idProposta}",
        method: "GET",
        summary: "Retorna o tipo de contrato.",
        notes: "Retorna o tipo de contrato.",
        type: "getTipoContratoResponse",
        nickname: "getTipoContrato",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Tipo de contrato retornado com sucesso",
                responseModel: "getTipoContratoResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter o tipo de contrato",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var retorno = {};

        if(req.params.idProposta == 10) {
            retorno = {
                "tipoContrato": "MANUAL",
                "boleto": true,
                "compraCerta": true
            };
        } else {
            retorno = {
                "tipoContrato": "ELETRONICO",
                "boleto": false,
                "compraCerta": true
            };
        }

        res.status(200).send(retorno);
    }
};