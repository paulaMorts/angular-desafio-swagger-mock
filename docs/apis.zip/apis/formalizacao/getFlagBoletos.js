var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna as flags de boleto.",
        path: "/documento/getFlagBoletos/{idProposta}",
        method: "GET",
        summary: "Retorna as flags de boleto.",
        notes: "Retorna as flags de boleto.",
        type: "getFlagBoletosResponse",
        nickname: "getFlagBoletos",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de flags de boleto retornada com sucesso",
                responseModel: "getLatariasResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de flags de boleto",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "controleFlagBoleto": {
                "flagBoletoTc": req.params.idProposta == 1? "S" : "N",
                "flagBoletoTab": req.params.idProposta == 1? "N" :  "N"
            }
        });
    }
};
