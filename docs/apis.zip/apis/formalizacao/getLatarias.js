module.exports = {
    spec: {
        description: "Retorna lista de domínio de situação de lataria.",
        path: "/dadosComplementares/getListaLataria",
        method: "GET",
        summary: "Retorna lista de domínio de situação de lataria.",
        notes: "Retorna lista de domínio de situação de lataria.",
        type: "getLatariasResponse",
        nickname: "getLatarias",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de latarias retornada com sucesso",
                responseModel: "getLatariasResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de latarias",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaSituacaoLataria": [
                {
                    "idSitLataria": "1",
                    "dsSitLataria": "Boa"
                },
                {
                    "idSitLataria": "2",
                    "dsSitLataria": "Danificada"
                },
                {
                    "idSitLataria": "3",
                    "dsSitLataria": "Péssima"
                }
            ]
        });
    }
};