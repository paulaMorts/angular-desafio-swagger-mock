var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Finaliza a tela de formalização e grava os dados da conta corrente.",
        path: "/formalizacao/postFormalizacao",
        method: "POST",
        summary: "Finaliza a tela de formalização e grava os dados da conta corrente.",
        notes: "Envia os dados de pagamento para conclusão da formalização.",
        type: "postEnviarFormalizacaoResponse",
        nickname: "postEnviarFormalizacao",
        produces: ["application/json"],
        parameters: [
            paramTypes.body("postEnviarFormalizacaoRequest", "Dados de formalização", "postEnviarFormalizacaoRequest", true)
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Envio de dados de formalização realizado com sucesso",
                responseModel: "postEnviarFormalizacaoResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar o envio dos dados da formalização.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "retorno": {
                "dsMensagem": "OK"
            }
        });
    }
};