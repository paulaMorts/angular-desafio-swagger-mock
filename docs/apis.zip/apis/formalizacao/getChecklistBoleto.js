var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de documentos (boleto).",
        path: "/checklist/boleto/{idProposta}",
        method: "GET",
        summary: "Retorna a lista de documentos (boleto).",
        notes: "Recebe como parâmetro o ID da proposta e retorna a lista de documentos que devem ser carregados.",
        type: "getChecklistBoletoResponse",
        nickname: "getChecklistBoleto",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Checklist retornado com sucesso",
                responseModel: "getChecklistResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca do checklist",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "checklist": [
                {
                    "idChecklist": "90",
                    "nmDocumento": "Boleto",
                    "dsOrientacao": "Boleto de pagamento",
                    "fgIndexado": false,
                    "tipoDocumento": "CO",
                    "fgRequired": true
                }
            ]
        });
    }
};
