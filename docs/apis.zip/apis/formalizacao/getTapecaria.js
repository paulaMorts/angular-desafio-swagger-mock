module.exports = {
    spec: {
        description: "Retorna lista de domínio de situação de tapeçaria.",
        path: "/dadosComplementares/getListaTapecaria",
        method: "GET",
        summary: "Retorna lista de domínio de situação de tapeçaria",
        notes: "Retorna lista de domínio de situação de tapeçaria",
        type: "getTapecariaResponse",
        nickname: "getTapecaria",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tapeçarias retornada com sucesso",
                responseModel: "getTapecariaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de tapeçarias.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaSituacaoTapecaria": [
                {
                    "idSitTapecaria": "1",
                    "dsSitTapecaria": "Boa"
                },
                {
                    "idSitTapecaria": "2",
                    "dsSitTapecaria": "Danificada"
                },
                {
                    "idSitTapecaria": "3",
                    "dsSitTapecaria": "Péssima"
                }
            ]
        });
    }
};