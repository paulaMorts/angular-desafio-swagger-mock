var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Obtem dados complementares.",
        path: "/formalizacao/getDadosComplementares/{idProposta}",
        method: "GET",
        summary: "Obtem dados complementares.",
        notes: "Obtem dados complementares.",
        type: "getDadosComplementaresResponse",
        nickname: "getDadosComplementares",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("idProposta", "Identificador da Proposta", "number")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Dados complementares obtidos com sucesso.",
                responseModel: "getDadosComplementaresResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter dados complementares.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if(req.params.idProposta == 10) {
            setTimeout(function () {
                res.status(200).send({
                    dadosComplementares: {
                        idUfPlaca: "SP",
                        numeroChassi: "12314234242424321",
                        descricaoCor: "Preta",
                        numeroRenavam: "12313131313",
                        numeroPlaca: "ASD1233",
                        idSituacaoLataria: "1",
                        idSituacaoTapecaria: "2",
                        idSituacaoPintura: "3",
                        idSituacaoPneu: "2"
                    }
                });
            }, 500);
        }
         else {
                setTimeout(function () {
                res.status(200).send({
                    dadosComplementares: {
                        idUfPlaca: "",
                        numeroChassi: "",
                        descricaoCor: "",
                        numeroRenavam: "",
                        numeroPlaca: "",
                        idSituacaoLataria: 0,
                        idSituacaoTapecaria: 0,
                        idSituacaoPintura: 0,
                        idSituacaoPneu: 0
                    }
                });
            }, 500);
        }
    }
};