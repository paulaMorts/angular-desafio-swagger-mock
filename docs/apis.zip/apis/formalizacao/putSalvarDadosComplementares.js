var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Gravação de dados complementares.",
        path: "/dadosComplementares/salvar/{idProposta}",
        method: "POST",
        summary: "Gravação de dados complementares.",
        notes: "Realiza a verificação e armazenamento dos dados complementares de um veículo, relacionado à uma propsota.",
        type: "putSalvarDadosComplementaresResponse",
        nickname: "putSalvarDadosComplementares",
        produces: ["application/json"],
        parameters: [
			paramTypes.body("putSalvarDadosComplementaresRequest", "Dados do veículo", "putSalvarDadosComplementaresRequest", true),
			paramTypes.path("idProposta", "Identificador da Proposta", "number", true)
		],
        errorResponses: [
            {
                code: "200",
                reason: "Atualização de dados complementares realizada com sucesso.",
                responseModel: "putSalvarDadosComplementaresResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a atualização de dados complementares.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
		var numChassi = req.body.dadosComplementares.numeroChassi;
		
		if (req.body.dadosComplementares.confirmarChassi != null && req.body.dadosComplementares.confirmarChassi != "") {
			numChassi = "";
		}
		
        switch (numChassi) {
            case "11111111111111111":
                setTimeout(function() {
                    res.status(500).send({
                        "error": {
                            "code": "CE-01",
                            "description": "SNG fora do ar"
                        }
                    });
                }, 1500);
                break;
            case "22222222222222222":
                setTimeout(function() {
                    res.status(500).send({
                        "error": {
                            "code": "CE-02",
                            "description": "Chassi não localizado no SNG"
                        }
                    });
                }, 1500);
                break;
            case "33333333333333333":
                setTimeout(function() {
                    res.status(500).send({
                        "error": {
                            "code": "CE-03",
                            "description": "Dados da 'Placa' ou 'Renavam' inconsistentes com 'Chassi'"
                        }
                    });
                }, 1500);
                break;
            default:
                setTimeout(function() {
                    res.status(200).send({
                        "veiculo": {
                            "idVeiculo": "8",
                            "cdErro": "0",
                            "dsMensagem": ""
                        }
                    });
                }, 1500);
                break;
        }
    }
};