var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Grava os dados do endereço de retirada.",
        path: "/usuarios/postEnderecoRetirada",
        method: "POST",
        summary: "Grava os dados do endereço de retirada.",
        notes: "Grava os dados do endereço de retirada.",
        type: "postEnderecoRetiradaResponse",
        nickname: "postEnderecoRetirada",
        produces: ["application/json"],
        parameters: [
            paramTypes  .body("postEnderecoRetiradaRequest", "Dados do endereço de retirada", "postEnderecoRetiradaRequest", true)
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Endereço de retirada enviado com sucesso",
                responseModel: "postEnderecoRetiradaResponse"
            },
            {
                code: "500",
                reason: "Erro no envio do endereço de retirada",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "retorno": {
                "dsMensagem": "OK"
            }
        });
    }
};
