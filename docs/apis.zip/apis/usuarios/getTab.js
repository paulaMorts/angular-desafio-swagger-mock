var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
    spec: {
        description: "Retorna a Tab e o nome do usuário correspondente.",
        path: "/usuario/get",
        method: "GET",
        summary: "Retorna a Tab, o nome do usuário correspondente e seu canal.",
        notes: "Retorna a Tab, o nome do usuário correspondente e seu canal.",
        type: "getTabResponse",
        nickname: "getTab",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Usuários não encontrados",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var data = {
                    "tab": "MANO CAR COMERCIO DE AUTOMOVEIS LTDA",
                    "nome": "Jose dos Santos" + Math.floor((Math.random() * 100) + 1),
                    "canal": "Canal 11"
            };
        //TODO: Fazer o mock
        res.status(200).send({
            "usuario": data

        })
    }
};
