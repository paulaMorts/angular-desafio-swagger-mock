var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Realiza a busca de endereço com base na tab e na filial.",
        path: "/usuarios/getEnderecoRetirada",
        method: "GET",
        summary: "Realiza a busca de endereço com base tab e na filial.",
        notes: "Recebe como parâmetro o código da loja e da filial e retorna o endereço completo",
        type: "getEnderecoRetiradaResponse",
        nickname: "getEndereco",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("cdTab", "Código da Loja", "number", true),
            paramTypes.query("idFilial", "Código da Filial.", "number", true)
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Endereço retornado com sucesso.",
                responseModel: "getEnderecoRetiradaResponse"
            },
            {
                code: "500",
                reason: "Erro ao buscar endereço.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.query.cdTab === "99999") {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar a busca de municípios"
                }
            });
        }
        else {
            res.status(200).send({
                "enderecoRetirada": {
                    "cdCep": "02534020",
                    "dsLogradouro": "General Iberê Leal Ferreira",
                    "dsBairro": req.query.cdTab == "3" ? "Casa Verde Casa Verde Casa Verde Casa Verde" : "Casa Verde",
                    "dsMunicipio": "SAO PAULO",
                    "idMunicipio": 26,
                    "idUf": "SP",
                    "numero": 1042,
                    "dsComplemento":"123"
                }
            });
        }
    }
};
