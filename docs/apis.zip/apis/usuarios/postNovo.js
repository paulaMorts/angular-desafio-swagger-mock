var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Serviço para criação de usuários",
        path: "/usuarios/postNovo/",
        method: "POST",
        summary: "Serviço para criação de usuários",
        notes: "Serviço para criação de usuários",
        type: "postNovoUsuarioResponse",
        nickname: "postNovoUsuario",
        produces: ["application/json"],
        parameters: [paramTypes.body("usuarioNovo", "Grupo com os dados do Usuário para inserção", "usuarioNovoRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        });
    }
};