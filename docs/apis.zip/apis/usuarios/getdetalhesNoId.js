var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Detalhes de um usuário.",
        path: "/usuarios/getDetalhes",
        method: "GET",
        summary: "Detalhes de um usuário",
        notes: "Detalhes de um usuário",
        type: "getDetalhesRequest",
        nickname: "getDetalhesUsuario",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Usuários não encontrados",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var data = [
            {
                "idUsuario": 1,
                "identificadorFilial": 1,
                "nomeUsuario": "Edson Arantes do Nascimento",
                "email": "pele@santosfc.com.br",
                "nrCPF": "00000000000",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 2,
                "nomeUsuario": "Neymar da Silva Santos Jr",
                "email": "neymar@santosfc.com.br",
                "nrCPF": "11111111111",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "RJ",
                "cdTab": "12345"
            },
            {
                "idUsuario": 3,
                "nomeUsuario": "Jonathan Copete",
                "email": "cheguei@santosfc.com.br",
                "nrCPF": "22222222222",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 3,
                "nomeUsuario": "Dorival Junior",
                "email": "chefao@santosfc.com.br",
                "nrCPF": "33333333333",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 4,
                "nomeUsuario": "Van Der Lei",
                "email": "holandes@santosfc.com.br",
                "nrCPF": "44444444444",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 5,
                "nomeUsuario": "Vitor Ferraz",
                "email": "marco.luque.santastico@santosfc.com.br",
                "nrCPF": "55555555555",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 6,
                "nomeUsuario": "Alison Crazy Dog",
                "email": "pitbull@santosfc.com.br",
                "nrCPF": "66666666666",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "SP",
                "cdTab": "12345"
            },
            {
                "idUsuario": 7,
                "nomeUsuario": "Renato Maestro",
                "email": "joga.de.terno@santosfc.com.br",
                "nrCPF": "77777777777",
                "nrCelular": "11111111111",
                "nrTelComercial": "22222222222",
                "idMarca": 2,
                "idUf": "RJ",
                "cdTab": "12345"
            }
        ];

        res.status(200).send({
            usuario: data[0]
        });
    }
};
