var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
    spec: {
        description: "Retorna lista de usuários secundários.",
        path: "/usuarios/getLista/{nrPagina}",
        method: "GET",
        summary: "Retorna lista de usuários secundários.",
        notes: "Retorna lista de usuários secundários.",
        type: "getListaUsuariosResponse",
        nickname: "getListaUsuaios",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("nrPagina", "Número da página requisitada.", "number"),
            paramTypes.query("dsOrdenacao", "Opções de ordenação.", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Opções para direção da ordenação (asc, desc).", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Usuários não encontrados",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var data = [
            {
                "idUsuario": 1,
                "nome": "Edson Arantes do Nascimento",
                "email": "pele@santosfc.com.br",
                "nrCpf": "00000000000",
                "fgBloqueado": false
            },
            {
                "idUsuario": 2,
                "nome": "Neymar da Silva Santos Jr",
                "email": "neymar@santosfc.com.br",
                "nrCpf": "11111111111",
                "fgBloqueado": true
            },
            {
                "idUsuario": 3,
                "nome": "Jonathan Copete",
                "email": "cheguei@santosfc.com.br",
                "nrCpf": "22222222222",
                "fgBloqueado": false
            },
            {
                "idUsuario": 3,
                "nome": "Dorival Junior",
                "email": "chefao@santosfc.com.br",
                "nrCpf": "33333333333",
                "fgBloqueado": true
            },
            {
                "idUsuario": 4,
                "nome": "Van Der Lei",
                "email": "holandes@santosfc.com.br",
                "nrCpf": "44444444444",
                "fgBloqueado": false
            },
            {
                "idUsuario": 5,
                "nome": "Vitor Ferraz",
                "email": "marco.luque.santastico@santosfc.com.br",
                "nrCpf": "55555555555",
                "fgBloqueado": false
            },
            {
                "idUsuario": 6,
                "nome": "Alison Crazy Dog",
                "email": "pitbull@santosfc.com.br",
                "nrCpf": "66666666666",
                "fgBloqueado": false
            },
            {
                "idUsuario": 7,
                "nome": "Renato Maestro",
                "email": "joga.de.terno@santosfc.com.br",
                "nrCpf": "77777777777",
                "fgBloqueado": false
            }
        ];
        if(req.query.dsOrdenacao)
            data = _.orderBy(data, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

        var start = (req.params.nrPagina*5)-5;
        data = data.slice(start, start+5);

        //TODO: Fazer o mock
        res.status(200).send({
            "listaUsuarios": data,
            "paginacao": {
                "nrPagina": req.params.nrPagina,
                "qtItens": 5,
                "qtResultados": 7,
                "qtPaginas": 2
            }
        })
    }
};
