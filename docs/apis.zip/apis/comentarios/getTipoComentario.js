var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de tipos de comentários",
        path: "/tipoComentario/get/{numeroDaProposta}",
        method: "GET",
        summary: "Retorna a lista de tipos de comentários",
        notes: "Retorna a lista de tipos de comentários",
        type: "getTipoComentarioResponse",
        nickname: "getTipoComentario",
        produces: ["application/json"],
        parameters: [paramTypes.path("numeroDaProposta", "Identificador da proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tipos de comentários retornados com sucesso",
                responseModel: "getTipoComentarioResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter tipos de comentários.",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            tipoComentario: [
                {
                    cdTpComentario: 1,
                    dsTpComentario: "Ajuste"
                },
                {
                    cdTpComentario: 2,
                    dsTpComentario: "Comentário"
                }
            ]
        });
    }
};