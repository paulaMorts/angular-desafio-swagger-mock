var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Envia mensagem de comentário sobre uma proposta",
        path: "/comentarioAjuste/enviar",
        method: "POST",
        summary: "Envia mensagem de comentário sobre uma proposta",
        notes: "Recebe um texto com comentários para ajuste de uma determinada proposta e inicia o workflow para análise",
        type: "postEnviarComentarioResponse",
        nickname: "postEnviarComentario",
        produces: ["application/json"],
        parameters: [paramTypes.body("postEnviarComentarioRequest", "Comentário e identificador da proposta", "postEnviarComentarioRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Comentário enviado com sucesso",
                responseModel: "postEnviarComentarioResponse"
            },
            {
                code: "500",
                reason: "Erro ao enviar comentários",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var ret = [];
        var arr = req.body.comentario;

        for (var i = 0, len = arr.length; i < len; i++) {
            ret.push({
                nmTitulo: arr[i].tpComentario,
                dsMensagem: arr[i].dsComentario
            });
        }

        res.status(200).send({
                "cobol": {
                    "loop-cliente": "",
                    "loop-imovel": "",
                    "loop-doc-cli": "",
                    "loop-doc-imo": "",
                    "loop-doc-emp": "",
                    "loop-veiculo": {
                        "id-veiculo": "6.929",
                        "tp-veiculo": "0",
                        "ano-fabricacao": "2015",
                        "ano-modelo": "0",
                        "num-chassi": "99999999999999999",
                        "placa-atual": "HUI6769",
                        "uf-placa-atual": "SP",
                        "num-renavam": "11.111.111.111",
                        "marca": "HYUNDAI",
                        "modelo": "HB20 CONF PLUS 1.0 FLEX 12V 4P"
                    }
                    ,
                    "loop-doc-vei": "",
                    "loop-socio": ""
                },
                "mensagem": {
                    "nmTitulo": "Comentário enviado com sucesso.",
                    "dsMensagem": "Seu comentário foi enviado e será analisado."
                },
                "status": {
                    "dsStatus": "EM AJUSTE"
                }
            });
    }
};