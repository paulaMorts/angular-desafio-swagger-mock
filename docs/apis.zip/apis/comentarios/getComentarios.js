var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de comentários",
        path: "/comentario/get/{numeroDaProposta}",
        method: "GET",
        summary: "Retorna a lista de comentários",
        notes: "Retorna a lista de comentários",
        type: "getComentariosResponse",
        nickname: "getComentarios",
        produces: ["application/json"],
        parameters: [paramTypes.path("numeroDaProposta", "Identificador da proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de comentários retornados com sucesso",
                responseModel: "getComentariosResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter comentários",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var comments = [];

        for (var i = 1; i < 12; i++) {
            comments.push({
                tpObservacao: "Observação " + i,
                dhObservacao: new Date(),
                cdOperVarejo: i,
                dsObservacao: "Minha observação " + i
            });
        }

        res.status(200).send({
            comentarioProposta: {
                dsComentario: "Comentario de crédito",
				listaComentario: comments
            }
        })
        ;
    }
};