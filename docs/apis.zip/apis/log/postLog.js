var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Efetua a gravação do Log de Erro",
        path: "/common/postLog",
        method: "POST",
        summary: "Efetua a gravação do Log de Erro",
        notes: "Efetua a gravação do Log de Erro.",
        type: "postLogResponse",
        nickname: "postLog",
        produces: ["application/json"],
        parameters: [paramTypes.body("postLogRequest", "Parametros do Log", "postLogRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Log gravado com sucesso",
                responseModel: "postLogResponse"
            },
            {
                code: "500",
                reason: "Erro ao gravar Log",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        console.log("Log Realizado!");
        console.log(req.body);
        res.status(200).send({
        });
    }
};