/**
 * Created by dalton.leonardo on 10/5/2016.
 */
var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Obtem a quantidade máxima de parcelas e produtos",
        path: "/identificacao/getDadosCessao",
        method: "GET",
        summary: "Obtem a quantidade máxima de parcelas e produtos",
        notes: "Obtem a quantidade máxima de parcelas e produtos",
        type: "getDadosCessaoResponse",
        nickname: "getDadosCessao",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Dados cessão retornados com sucesso",
                responseModel: "getDadosCessaoResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter dados cessão",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //res.status(200).send(401);
        res.status(200).send({
                "dadosCessao": {
                    "qtdMaximoParcelas": 1,
                    "produtos": [{
                        "id": 1,
                        "nome": "João Hungria"
                    }]
                }
            }
        );
    }
};