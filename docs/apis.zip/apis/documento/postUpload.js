var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Executa o procedimento de upload de arquivos",
        path: "/documento/upload",
        method: "POST",
        summary: "Executa o procedimento de upload de arquivos",
        notes: "Recebe o arquivo serializado em base64 e realiza o upload.",
        type: "postUploadResponse",
        nickname: "postUpload",
        produces: ["application/json"],
        parameters: [paramTypes.body("postUploadRequest", "Informações para upload", "postUploadRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Upload realizado com sucesso",
				responseModel: "postUploadResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar upload",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {

        //var pf = [
        //    {
        //        "nome": "nome",
        //        "valor": "Edson Arantes do Nascimento",
        //        "exibir": "S"
        //    },
        //    {
        //        "nome": "numDoc",
        //        "valor": "1234569876545678",
        //        "exibir": "S"
        //    },
        //    {   "nome": "orgEmissor",
        //        "valor": "SSPSP",
        //        "exibir": "S"
        //    },
        //    {   "nome": "ufOrg",
        //        "valor": "SP",
        //        "exibir": "S"
        //    },
        //    {   "nome": "nomePai",
        //        "valor": "Everton Flumiggan",
        //        "exibir": "S"
        //    },
        //    {   "nome": "nomeMae",
        //        "valor": "Bruna Marquezine",
        //        "exibir": "S"
        //    }];

        var pf = [
            {"nome": "CPF", "valor": "40968596954", "exibir": "S"},
            {"nome": "Registro","valor": "05124844547","exibir": "S"},
            {"nome": "DataNas", "valor": "29/02/1992", "exibir": "S"},
            {"nome": "RG", "valor": "34519714","exibir": "S"},
            {"nome": "NomeC", "valor": "", "exibir": "N"}
        ];

        var pj = [
            {   "nome": "razaoSocial",
                "valor": "Sociedade dos Poetas Mortos",
                "exibir": "S"
            },
            {   "nome": "naturezaJuridica",
                "valor": "1",
                "exibir": "N"
            },
            {   "nome": "endereco",
                "valor": "Rua Iacupema",
                "exibir": "S"
            },
            {   "nome": "cep",
                "valor": "08110610",
                "exibir": "S"
            },
            {   "nome": "bairro",
                "valor": "Vila Alabama",
                "exibir": "S"
            },
            {   "nome": "numero",
                "valor": "110",
                "exibir": "N"
            },
            {   "nome": "complemento",
                "valor": "Casa",
                "exibir": "S"
            },
            {   "nome": "uf",
                "valor": "SP",
                "exibir": "S"
            },
            {   "nome": "telFixo",
                "valor": "1130303030",
                "exibir": "N"
            },
            {   "nome": "email",
                "valor": "edilson@sociedadedospoetas.com.br",
                "exibir": "N"
            },
            {   "nome": "atividadeEconomica",
                "valor": "1",
                "exibir": "S"
            },
            {   "nome": "grupoAtividadeEconomica",
                "valor": "1",
                "exibir": "S"
            }
        ];

        if(req.body.documento.idChecklist == 500) {
            res.status(500).send({
                errorCode: "500",
                errorMessage: "Erro."
            });
        } else {
            setTimeout(function() {
                res.status(200).send({
                    "retorno": {
						"dsMensagem": "OK"
					},
					"ocrResponse": req.body.documento.idChecklist == 17 ? pj : pf
                });
            }, 1000);
        }
    }
};
