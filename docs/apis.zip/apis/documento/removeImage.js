var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Remove o documento",
        path: "/documento/removeImage/{idChecklist}/{idImagem}",
        method: "POST",
        summary: "Remove o documento",
        notes: "Remove o documento",
        type: "removeImageResponse",
        nickname: "removeImage",
        produces: ["application/json"],
        parameters: [paramTypes.path("idImagem", "Identificador da imagem", "number"),
                    paramTypes.path("idChecklist", "Identificador do checklist", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Arquivo excluido com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao excluir arquivo",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if(req.params.idImagem == 500) {
            res.status(500).send({
                errorCode: "500",
                errorMessage: "Erro."
            });
        } else {
            res.status(200).send({
                "retorno": {
                    "dsMensagem": "OK"
                }
            });
        }
    }
};