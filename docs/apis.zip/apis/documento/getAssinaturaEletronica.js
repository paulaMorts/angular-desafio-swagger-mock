var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Obtem URL para assinatura do documento a partir do checklist e proposta",
        path: "/documento/getAssinaturaEletronica/{idProposta}/{idChecklist}",
        method: "GET",
        summary: "Obtem URL para assinatura do documento a partir do checklist e proposta",
        notes: "Obtem URL para assinatura do documento a partir do checklist e proposta",
        type: "getAssinaturaEletronicaResponse",
        nickname: "getAssinaturaEletronica",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("idProposta", "Identificador da Proposta", "string"),
            paramTypes.path("idChecklist", "Identificador do checklist", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "URL obtida com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao obter URL",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        setTimeout(function () {
            res.status(200).send({
                "dsUrl":"http://testlab.xyzmo.com:50100/Sign.aspx?WorkstepID=1BDA8F002B797AE646921626C375DF5141983F1A4A87E7F6F339A5DFC302D102172C6E818C38CF4B4BAE4EE23414A3D0&cna=none"
            });
        }, 1500);

    }
};