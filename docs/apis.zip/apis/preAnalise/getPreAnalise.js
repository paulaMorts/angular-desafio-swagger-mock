var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna os dados de pré-análise salvos",
        path: "/preAnalise/get/{idProposta}",
        method: "GET",
        summary: "Retorna os dados de pré-análise salvos",
        notes: "Retorna as informações de pré-análise salvas para a proposta, com base em se identificador.",
        type: "getPreAnaliseResponse",
        nickname: "getPreAnalise",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Dados da pré-análise retornados com sucesso",
                responseModel: "getPreAnaliseResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de informações de pré-análise",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.idProposta == 1) {
            res.status(200).send({
				  "proposta": {
					"nrCpfCnpj": "08726544946",
					"dsAnoFabricacao": "2011",
					"idUf": "SP",
					"idAnoCombust": 1,
					"idMarca": 1,
					"idModelo": 1,
					"idTipoVeiculo": "4",
					"fgAdaptado": true,
					"fgTaxi": false,
					"dtDataNascFund": "1980-05-18T00:00:00-0300",
					"vlBem": 30299.92
				  }
				});
        } else if (req.params.idProposta == 10) {
            res.status(500).send({
                error: {
                    code: "U-000",
                    message: "Erro ao obter dados da pré-análise"
                }
            });
        } else {
            res.status(200).send({});
        }
    }
};
