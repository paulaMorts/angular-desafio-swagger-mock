var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna as opções de marcas de veículos",
        path: "/preAnalise/getMarcas/{tipoVeiculo}",
        method: "GET",
        summary: "Retorna as opções de marcas de veículos",
        notes: "Retorna a lista de marcas de veículos, com base no tipo de veículo informado. A lista de tipos de veículos deve ser obtida através da API /preAnalise/getTipos",
        type: "getMarcasVeiculosResponse",
        nickname: "getMarcasVeiculos",
        produces: ["application/json"],
        parameters: [paramTypes.path("tipoVeiculo", "Tipo de Veículo", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de marcas retornada com sucesso",
                responseModel: "getMarcasVeiculosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de marcas de veículos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.tipoVeiculo == "4") {
            res.status(200).send({
                "marcaVeiculo": [{
                    "idMarca": 1,
                    "dsMarca": "Honda",
					"fgDefault": true
                }, {
                    "idMarca": 2,
                    "dsMarca": "Hyundai",
					"fgDefault": false
                }]
            });
        } else if(req.params.tipoVeiculo == "5") {
            res.status(200).send({
                "marcaVeiculo": [{
                    "idMarca": 3,
                    "dsMarca": "Honda",
					"fgDefault": false
                }, {
                    "idMarca": 4,
                    "dsMarca": "Yamaha",
					"fgDefault": true
                }]
            });
        } else {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar busca de marcas"
                }
            });
        }
    }
};
