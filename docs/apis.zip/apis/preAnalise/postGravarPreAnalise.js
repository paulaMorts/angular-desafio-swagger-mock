var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Efetua a gravação da pré-analise",
        path: "/preAnalise/gravaPreAnalise",
        method: "POST",
        summary: "Efetua a gravação da pré-analise",
        notes: "Recebe as informações para criação da proposta (fase de pré-anáilse) e armazena para dar prosseguimento ao processo.",
        type: "postGravarPreAnaliseResponse",
        nickname: "postGravarPreAnalise",
        produces: ["application/json"],
        parameters: [paramTypes.body("postGravarPreAnaliseRequest", "Dados da pré-análise", "postGravarPreAnaliseRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Dados da pré-análise armazenados com sucesso.",
                responseModel: "postGravarPreAnaliseResponse"
            },
            {
                code: "500",
                reason: "Erro ao armazenar dados da pré-análise",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.body.nrCpfCnpj === "22222222222") {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao armazenar dados da pré-análise."
                }
            });
        } else {
            res.status(200).send({
				proposta: {
					idProposta: 1,
                    dsMensagemRepesc: "Aviso: Usuário com nome sujo no SERASA"
				}
            });
        }
    }
};
