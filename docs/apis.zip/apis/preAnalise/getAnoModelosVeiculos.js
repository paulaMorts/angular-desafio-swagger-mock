var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna as opções de ano/modelos de veículos",
        path: "/preAnalise/getAnoModelo/{idModelo}",
        method: "GET",
        summary: "Retorna as opções de ano/modelos de veículos",
        notes: "Retorna a lista de ano/modelos de veículos, com base no modelo do veículo informado. A lista de modelos de veículos deve ser obtida através da API /preAnalise/getModelos/{idmodelo}",
        type: "getAnoModelosVeiculosResponse",
        nickname: "getAnoModelosVeiculos",
        produces: ["application/json"],
        parameters: [paramTypes.path("idModelo", "Modelo do Veículo", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de ano/modelos retornada com sucesso",
                responseModel: "getAnoModelosVeiculosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de ano/modelos de veículos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.idModelo == 1) {
            res.status(200).send({
                "anoCombustVeiculo": [{
                    "idAnoCombust": 1,
                    "dsAno": 2010,
                    "dsCombust": "Gasolina",
                    "dsZero": "Zero Km"
                }, {
                    "idAnoCombust": 2,
                    "dsAno": 2010,
                    "dsCombust": "Gasolina",
                    "dsZero": ""
                }]
            });
        } else if (req.params.idModelo == 2) {
            res.status(200).send({
                "anoCombustVeiculo": [{
                    "idAnoCombust": 2,
                    "dsAno": 2015,
                    "dsCombust": "Gasolina",
                    "dsZero": "Zero Km"
                }, {
                    "idAnoCombust": 3,
                    "dsAno": 2015,
                    "dsCombust": "Gasolina",
                    "dsZero": ""
                }]
            });
        } else {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar busca de ano/modelos"
                }
            });
        }
    }
};