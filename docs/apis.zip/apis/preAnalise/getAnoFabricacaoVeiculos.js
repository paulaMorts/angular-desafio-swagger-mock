var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna as opções de ano/fabricacao de veículos",
        path: "/preAnalise/getAnoFabricacao/{ano}",
        method: "GET",
        summary: "Retorna as opções de ano/fabricacao de veículos",
        notes: "Retorna a lista de ano/fabricacao de veículos, com base no ano do modelo do veículo informado. A lista de ano/modelos de veículos deve ser obtida através da API /preAnalise/getAnoModelo/{idModelo}",
        type: "getAnoFabricacaoVeiculosResponse",
        nickname: "getAnoFabricacaoVeiculos",
        produces: ["application/json"],
        parameters: [paramTypes.path("ano", "Ano do Modelo do Veículo", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de ano/fabricacao retornada com sucesso",
                responseModel: "getAnoFabricacaoVeiculosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de ano/fabricacao de veículos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.ano == 2010 || req.params.ano == 2015) {
            res.status(200).send({
                "anoFabricacao": [{
                    "dsAnoFabricacao": parseInt(req.params.ano)
                }, {
                    "dsAnoFabricacao": parseInt(req.params.ano) + 1
                }]
            });
        } else {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar busca de ano/fabricacao"
                }
            });
        }
    }
};