module.exports = {
    spec: {
        description: "Retorna a lista de estados (UFs)",
        path: "/preAnalise/getUF",
        method: "GET",
        summary: "Retorna a lista de estados (UFs)",
        notes: "Retorna a lista de estados (UFs), com suas siglas e nomes",
        type: "getUFsResponse",
        nickname: "getUFs",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de UFs retornada com sucesso",
                responseModel: "getUFsResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de UFs",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "uF": [
        //         {
        //         "idUf": "SP",
        //         "dsUf": "São Paulo",
			// 	"fgDefault": true
        //     }, {
        //         "idUf": "RJ",
        //         "dsUf": "Rio de Janeiro",
			// 	"fgDefault": false
        //     }
        //
        //
        //
        //     ]
        // }
        {"uF":[{"idUf":"AC","dsUf":"Acre","fgDefault":"N"},{"idUf":"AL","dsUf":"Alagoas","fgDefault":"N"},{"idUf":"AM","dsUf":"Amazonas","fgDefault":"N"},{"idUf":"AP","dsUf":"Amapa","fgDefault":"N"},{"idUf":"BA","dsUf":"Bahia","fgDefault":"N"},{"idUf":"CE","dsUf":"Ceara","fgDefault":"N"},{"idUf":"DF","dsUf":"Distrito Federal","fgDefault":"N"},{"idUf":"ES","dsUf":"Espirito Santo","fgDefault":"N"},{"idUf":"GO","dsUf":"Goias","fgDefault":"N"},{"idUf":"MA","dsUf":"Maranhao","fgDefault":"N"},{"idUf":"MG","dsUf":"Minas Gerais","fgDefault":"N"},{"idUf":"MS","dsUf":"Mato Grosso Do Sul","fgDefault":"N"},{"idUf":"MT","dsUf":"Mato Grosso","fgDefault":"N"},{"idUf":"PA","dsUf":"Para","fgDefault":"N"},{"idUf":"PB","dsUf":"Paraiba","fgDefault":"N"},{"idUf":"PE","dsUf":"Pernambuco","fgDefault":"N"},{"idUf":"PI","dsUf":"Piaui","fgDefault":"N"},{"idUf":"PR","dsUf":"Parana","fgDefault":"N"},{"idUf":"RJ","dsUf":"Rio De Janeiro","fgDefault":"N"},{"idUf":"RN","dsUf":"Rio Grande Do Norte","fgDefault":"N"},{"idUf":"RO","dsUf":"Rondonia","fgDefault":"N"},{"idUf":"RR","dsUf":"Roraima","fgDefault":"N"},{"idUf":"RS","dsUf":"Rio Grande Do Sul","fgDefault":"N"},{"idUf":"SC","dsUf":"Santa Catarina","fgDefault":"N"},{"idUf":"SE","dsUf":"Sergipe","fgDefault":"N"},{"idUf":"SP","dsUf":"Sao Paulo","fgDefault":"N"},{"idUf":"TO","dsUf":"Tocantins","fgDefault":"N"}]}
        );
    }
};