var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna as opções de modelos de veículos",
        path: "/preAnalise/getModelos/{marcaid}",
        method: "GET",
        summary: "Retorna as opções de modelos de veículos",
        notes: "Retorna a lista de modelos de veículos, com base na marca do veículo informado. A lista de marcas de veículos deve ser obtida através da API /preAnalise/getMarcas/{tipoVeiculo}",
        type: "getModelosVeiculosResponse",
        nickname: "getModelosVeiculos",
        produces: ["application/json"],
        parameters: [paramTypes.path("marcaid", "Marca do Veículo", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de modelos retornada com sucesso",
                responseModel: "getModelosVeiculosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de modelos de veículos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.marcaid > 0 && req.params.marcaid <= 2) {
            res.status(200).send({
                "modeloVeiculo": [{
                    "idModelo": 1,
                    "dsModelo": "Modelo Carro 1",
					"fgDefault": false
                }, {
                    "idModelo": 2,
                    "dsModelo": "Modelo Carro 2",
					"fgDefault": true
                }]
            });
        } else if(req.params.marcaid > 0 && req.params.marcaid <= 4) {
            res.status(200).send({
                "modeloVeiculo": [{
                    "idModelo": 3,
                    "dsModelo": "Modelo Moto 1",
					"fgDefault": true
                }, {
                    "idModelo": 4,
                    "dsModelo": "Modelo Moto 2",
					"fgDefault": false
                }]
            });
        } else {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar busca de modelos"
                }
            });
        }
    }
};
