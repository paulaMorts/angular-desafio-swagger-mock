module.exports = {
    spec: {
        description: "Retorna as opções de tipos de veículos",
        path: "/preAnalise/getTipos",
        method: "GET",
        summary: "Retorna as opções de tipos de veículos",
        notes: "Retorna quais os tipos de veículos que podem ser financiados, com seus códigos e descrições",
        type: "getTiposVeiculosResponse",
        nickname: "getTiposVeiculos",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de veículos retornada com sucesso",
                responseModel: "getTiposVeiculosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de tipos de veículos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "tipoVeiculo": [
                {
                    "idTipoVeiculo": "4",
                    "dsTipoVeiculo": "Carros & Utilitários Pequenos"
                },
                {
                    "idTipoVeiculo": "5",
                    "dsTipoVeiculo": "Motos"
                }
            ]
        });
    }
};
