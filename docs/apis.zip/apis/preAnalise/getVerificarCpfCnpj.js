var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Realiza a validação do CPF/CNPJ",
        path: "/preAnalise/verificarCpfCnpj/{cpfCnpj}",
        method: "GET",
        summary: "Realiza a validação do CPF/CNPJ",
        notes: "Realiza a validação do documento (CPF/CNPJ) informado e retorna as inforações sobre o histórico do cliente.",
        type: "getVerificarCpfCnpjResponse",
        nickname: "getVerificarCpfCnpj",
        produces: ["application/json"],
        parameters: [paramTypes.path("cpfCnpj", "Documento CPF/CNPJ", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Validação de documento realizada",
                responseModel: "getVerificarCpfCnpjResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a validação do documento",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.cpfCnpj === "11111111111") {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar validação do documento"
                }
            });
        } else {
            res.status(200).send({
                valido: true,
                cpfCnpj: req.params.cpfCnpj
            });
        }
    }
};