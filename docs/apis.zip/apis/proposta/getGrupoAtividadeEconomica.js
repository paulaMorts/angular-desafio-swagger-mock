module.exports = {
    spec: {
        description: "Devolve a lista de possíveis opções para grupo de atividade econômica.",
        path: "/proposta/getGrupoAtividadeEconomica",
        method: "GET",
        summary: "Devolve a lista de possíveis opções para grupo de atividade econômica.",
        notes: "Retorna a lista de possíveis opções para grupo de atividade econômica.",
        type: "getGrupoAtividadeEconomicaResponse",
        nickname: "getGrupoAtividadeEconomica",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de grupos de atividade econômica retornadas com sucesso",
                responseModel: "getGrupoAtividadeEconomicaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de grupos de atividade econômica",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "grupoAtividadeEconomica": [{
                "idGrpAtividadeEconomica": 1,
                "dsGrpAtividadeEconomica": "GRUPO A"
            }, {
                "idGrpAtividadeEconomica": 2,
                "dsGrpAtividadeEconomica": "GRUPO B"
            }]
        });
    }
};