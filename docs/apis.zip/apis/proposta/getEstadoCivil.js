module.exports = {
    spec: {
        description: "Devolve a lista com os possíveis estados civis",
        path: "/proposta/getEstadoCivil",
        method: "GET",
        summary: "Devolve a lista com os possíveis estados civis",
        notes: "Retorna a lista com o domínios para os possíveis estados civis.",
        type: "getEstadoCivilResponse",
        nickname: "getEstadoCivil",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de estados civis retornada com sucesso",
                responseModel: "getEstadoCivilResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de estados civis",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "estadoCivil": [
        //         {
        //         "idEstadoCivil": 1,
        //         "dsEstadoCivil": "Solteiro"
        //     }, {
        //         "idEstadoCivil": 2,
        //         "dsEstadoCivil": "Casado"
        //     }, {
        //         "idEstadoCivil": 3,
        //         "dsEstadoCivil": "Companheiro"
        //     }]
        // }
            {"estadoCivil":[{"idEstadoCivil":"1","dsEstadoCivil":"CASADO"},{"idEstadoCivil":"11","dsEstadoCivil":"COMPANHEIRO"},{"idEstadoCivil":"3","dsEstadoCivil":"DIVORCIADO"},{"idEstadoCivil":"6","dsEstadoCivil":"SEPARADO JUDICIALMENTE"},{"idEstadoCivil":"4","dsEstadoCivil":"SOLTEIRO"},{"idEstadoCivil":"5","dsEstadoCivil":"VIUVO"}]}
        );
    }
};