module.exports = {
    spec: {
        description: "Devolve a lista de documentos possíveis.",
        path: "/proposta/getTiposDocumentos",
        method: "GET",
        summary: "Devolve a lista de documentos possíveis.",
        notes: "Retorna a lista de domínio de tipos de documentos.",
        type: "getTipoDocumentosResponse",
        nickname: "getTipoDocumentos",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tipos de documentos retornada com sucesso",
                responseModel: "getTipoDocumentosResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de tipos de documentos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "tipoDocumento": [
        //         {
        //         "idDocumento": 1,
        //         "nmDocumento": "CNH"
        //     }, {
        //         "idDocumento": 2,
        //         "nmDocumento": "REGISTRO DE ESTRANGEIRO"
        //     }, {
        //         "idDocumento": 3,
        //         "nmDocumento": "DOCUMENTO DE IDENTIDADE"
        //     }
        //
        //     ]
        // }
            {"tipoDocumento":[{"idDocumento":"3","nmDocumento":"DOCUMENTO DE IDENTIDADE"},{"idDocumento":"46","nmDocumento":"REGISTRO DE ESTRANGEIRO"}]}
        );
    }
};