var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o cabeçalho da proposta corrente",
        path: "/proposta/getCabecalho",
        method: "GET",
        summary: "Retorna o cabeçalho da proposta corrente",
        notes: "Retorna o cabeçalho da proposta corrente.",
        type: "getCabecalhoPropostaResponse",
        nickname: "getCabecalhoProposta",
        produces: ["application/json"],
        parameters: [paramTypes.query("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Cabeçalho retornado com sucesso",
                responseModel: "getCabecalhoPropostaResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter cabeçalho",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.query.idProposta === 0) {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao obter cabeçalho"
                }
            });
        }
        else if (req.query.idProposta != 111) {
            res.status(200).send({
                "cabecalho": {
                    "nrCpfCnpj": req.query.idProposta % 2 === 0 ? "32245970896" : "17213396000158",
                    "dsMarca": "Honda",
                    "dsAno": "2010",
                    "dsCombust": "Gasolina",
                    "dsZero": req.query.idProposta == 2 ? "Zero Km" : "",
                    "vlFinanciamento": 53500.20,
                    "dtDataNascFund": "01/10/2010",
                    "dsModelo": "XR250",
                    "dsAnoFabricacao": 2010,
                    "vlVeiculo": 60500.20,
                    "idUfLicencia": "SP",
                    "nmProduto": "FLEX",
                    "qtParcPagamento": 12,
                    "vlPrestacao": 500.58,
                    "vlEntrada": 20000.00,
                    "cdStatus": req.query.idProposta == 2 ||  req.query.idProposta == 3 ||  req.query.idProposta == 30 ? "aberta" : "",
                    vlPrestacaoMin: 500.58,
                    vlPrestacaoMax: 590.99,
                    dsPacoteFlex: "PACOTE TESTE"
                }
            });
        }

        else {
            res.status(200).send(
                {
                    "cabecalho": {
                        "nrCpfCnpj": "73192833000175",
                        "dsMarca": "HONDA",
                        "dsAno": 2016,
                        "dsCombust": "GASOLINA",
                        "dsZero": "0Km",
                        "vlFinanciamento": 33872.29,
                        "dtDataNascFund": "04&#x2f;04&#x2f;1989",
                        "dsModelo": "CIVIC SEDAN LXS 1.8&#x2f;1.8 FLEX 16V AUT. 4P",
                        "dsAnoFabricacao": 2016,
                        "vlVeiculo": 52000.0,
                        "idUfLicencia": "SP",
                        "nmProduto": "Padr&atilde;o",
                        "qtParcPagamento": 48,
                        "vlPrestacao": 1162.54,
                        "vlEntrada": 20400.0,
                        "cdStatus": "E",
                        "vlPrestacaoMin": 0.0,
                        "vlPrestacaoMax": 0.0,
                        "dsPacoteFlex": ""
                    }
                }

            );

        }

    }
};
