module.exports = {
    spec: {
        description: "Devolve a lista com as possíveis Ocupações.",
        path: "/proposta/getOcupacao",
        method: "GET",
        summary: "Devolve a lista com as possíveis Ocupações.",
        notes: "Retorna a lista de opções de ocupação.",
        type: "getOcupacaoResponse",
        nickname: "getOcupacao",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de ocupações retornada com sucesso",
                responseModel: "getOcupacaoResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de ocupações",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "ocupacao": [{
        //         "cdNatOcup": 1,
        //         "dsNatuOcup": "Autonomo"
        //     }, {
        //         "cdNatOcup": 2,
        //         "dsNatuOcup": "Empresario / Socio"
        //     }, {
        //         "cdNatOcup": 3,
        //         "dsNatuOcup": "Aposentado / Pensionista"
        //     }, {
        //         "cdNatOcup": 4,
        //         "dsNatuOcup": "Assalariado"
        //     }]
        // }
            {"ocupacao":[{"cdNatOcup":10,"dsNatuOcup":"ANALIST TESTADOR EGL"},{"cdNatOcup":11,"dsNatuOcup":"ANALISTA EXECUTOR"},{"cdNatOcup":7,"dsNatuOcup":"APOSENTADO &#x2f; PENSIONISTA"},{"cdNatOcup":4,"dsNatuOcup":"ASSALARIADO"},{"cdNatOcup":6,"dsNatuOcup":"AUTONOMO"},{"cdNatOcup":8,"dsNatuOcup":"EMPRESARIO &#x2f; SOCIO"},{"cdNatOcup":1,"dsNatuOcup":"FUNCIONARIO PUBLICO"},{"cdNatOcup":3,"dsNatuOcup":"MILITAR"},{"cdNatOcup":9,"dsNatuOcup":"OUTROS"},{"cdNatOcup":5,"dsNatuOcup":"PROFISSIONAL LIBERAL"}]}
        );
    }
};