var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o id de etiqueta vinculada à proposta",
        path: "/proposta/getEtiquetaVinculadaProposta/{idProposta}",
        method: "GET",
        summary: "Retorna o id de etiqueta vinculada à proposta",
        notes: "Retorna o id de etiqueta vinculada à proposta",
        type: "getEtiquetaVinculadaPropostaResponse",
        nickname: "getEtiquetaVinculadaProposta",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da proposta", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Etiqueta vinculada a proposta recuperada com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao recuperar etiqueta vinculada a proposta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {


        // se for maior que 500,retorna erro, simulando o cenário onde uma proposta não foi identificada
        if(req.params.idProposta > 500) {

          res.status(500).send({
            error: {
              code: "110",
              message: "Proposta não localizada!"
            }
          });
        } // se for maior que 100 e menor que 500, simula cenário onde não há etiqueta vinculada à proposta
        else if (req.params.idProposta > 100) {
          res.status(200).json({
                            "idEtiqueta": ""
                         });
        } // se for menor que 100, simula cneario onde há uma etiqueta vinculada
        else {
            res.status(200).json({
                              "idEtiqueta": req.params.idProposta
                           });
        }
    }
};
