module.exports = {
    spec: {
        description: "Devolve a lista de possíveis opções para natureza jurídica.",
        path: "/proposta/getNaturezaJuridica",
        method: "GET",
        summary: "Devolve a lista de possíveis opções para natureza jurídica.",
        notes: "Retorna a lista de possíveis opções para natureza jurídica.",
        type: "getNaturezaJuridicaResponse",
        nickname: "getNaturezaJuridica",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de naturezas jurídicas retornadas com sucesso",
                responseModel: "getNaturezaJuridicaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de naturezas jurídicas",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
            {
            "naturezaJuridica": [
                {
                "idNaturezaJuridica": 1,
                "dsNaturezaJuridica": "SOCIEDADE ANONIMA"
            }, {
                "idNaturezaJuridica": 2,
                "dsNaturezaJuridica": "SOCIEDADE DE QUOTAS LIMITADAS"
            }, {
                "idNaturezaJuridica": 3,
                "dsNaturezaJuridica": "SOCIEDADE EM NOME COLETIVO"
            }, {
                "idNaturezaJuridica": 4,
                "dsNaturezaJuridica": "SOCIEDADE EM COMANDITA SIMPLES"
            }, {
                "idNaturezaJuridica": 5,
                "dsNaturezaJuridica": "SOCIEDADE EM COMANDITA POR AÇÕES"
            }

            ]

        }

        // {"naturezaJuridica":[{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ASSOCIACAO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"AUTARQUIA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"AUTARQUIA ESTADUAL OU DO DIST FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"AUTARQUIA FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"AUTARQUIA MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CANDIDATO A CARGO POLITICO ELETIVO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CLUBE&#x2f;FUNDO DE INVESTIMENTO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"COMISSAO DE CONCILIACAO PREVIA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"COMISSAO POLINACIONAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"COMITE FINANCEIRO DE PARTIDO POLITICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"COMUNIDADE INDIGENA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONDOMINIO EDILICIO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONSORCIO DE EMPREGADORES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONSORCIO DE SOCIEDADES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONSORCIO PUBL DE DIR PUBL &#x28;ASSOC PUBL&#x29;"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONSORCIO PUBLICO DE DIREITO PRIVADO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONSORCIO SIMPLES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"CONTRIBUINTE INDIVIDUAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESA DOMICILIADA NO EXTERIOR"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESA INDIVIDUAL IMOBILIARIA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESA INDIVIDUAL-COMERCIO&#x2f;INDUSTRIAT."},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESA INDIVIDUAL-PRESTACAO DE SERVICOS"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESA PUBLICA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"EMPRESARIO &#x28;INDIVIDUAL&#x29;"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ENTIDADE BINACIONAL ITAIPU"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ENTIDADE DE MEDIACAO E ARBITRAGEM"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ENTIDADE SINDICAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ESTAB DE EMP BINACIONAL ARGENT-BRAS"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ESTAB NO BRASIL DE FUND OU ASSOC ESTRANG"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ESTAB NO BRASIL DE SOC ESTRANGEIRA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ESTADO OU DISTRITO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FILIAL,SUCURSAL,AG.EMPRESA SEDIADA EX."},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FRENTE PLEBISCITARIA OU REFERENDARIA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND OU ASSOC DOMICILIADA NO EXTERIOR"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIR PRIV EST OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIR PRIV OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIR PUBL EST OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIREITO PRIVADO MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIREITO PUBLICO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUND PUBL DE DIREITO PUBLICO MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUNDACAO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUNDO PRIVADO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"FUNDO PUBLICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"GRUPO DE SOCIEDADES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"LEILOEIRO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"MUNICIPIO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORG DA SOC CIVIL DE INTERESSE PUBL-OSCIP"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORG INTERN&#x2f;OUTRAS INST EXTRATERRITORIAIS"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGANIZACAO INTERNACIONAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGANIZACAO RELIGIOSA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGANIZACAO SOCIAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO DE DIRECAO NAC DE PART POLITICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO DE DIRECAO REGI DE PART POLITICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL AUTONOMO EST OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL DO PODER EXECUTIVO MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL DO PODER JUDICIARIO ESTADUAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL DO PODER JUDICIARIO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL DO PODER LEG MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL DO PODER LEGISLATIVO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL PODER EXEC EST OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBL PODER LEG ESTA OU DO DIST FED"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBLICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBLICO AUTONOMO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBLICO AUTONOMO MUNICIPAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"ORGAO PUBLICO DO PODER EXECUTIVO FEDERAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"OUTRAS INSTITUICOES EXTRATERRITORIAIS"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"PARTIDO POLITICO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"PRODUTOR RURAL &#x28;PESSOA FISICA&#x29;"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"REPRESENTACAO DIPLOMATICA ESTRANGEIRA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SEGURADO ESPECIAL"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SERVICO NOTARIAL E REGISTRAL - CARTORIO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SERVICO SOCIAL AUTONOMO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. ANONIMA &#x28;CAPITAL ABERTO&#x29;"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. ANONIMA &#x28;CAPITAL FECHADO&#x29;"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. CIVIL COM FINS LUCRATIVOS"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. COMANDITA POR ACOES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. COMANDITA SIMPLES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. COOPERATIVA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. DE CAPITAL E INDUSTRIA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. DE ECONOMIA MISTA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. EM CONTA DE PARTICIPACAO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. EM NOME COLETIVO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOC. POR COTAS DE RESPONSABILIDADE LTDA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOCIEDADE SIMPLES EM COMANDITA SIMPLES"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOCIEDADE SIMPLES EM NOME COLETIVO"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOCIEDADE SIMPLES LIMITADA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"SOCIEDADE SIMPLES PURA"},{"idNaturezaJuridica":"null","dsNaturezaJuridica":"UN EXECUTORA-PROG DINH DIRETO NA ESCOLA"}]};

        );
    }
};