var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Realiza a abertura da fase de complementação de dados da proposta.",
        path: "/proposta/abrirFaseDadosComplementar/{idProposta}",
        method: "POST",
        summary: "Realiza a abertura da fase de complementação de dados da proposta.",
        notes: "Realiza a abertura da fase de complementação de dados da proposta.",
        type: "",
        nickname: "postIniciarComplementarDados",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "ID da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Fase aberta com sucesso",
                responseModel: ""
            },
            {
                code: "500",
                reason: "Erro ao abrir fase de dados a complementar",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({});
    }
};