module.exports = {
    spec: {
        description: "Devolve a lista com os tipos de telefones",
        path: "/proposta/getTipoTelefone",
        method: "GET",
        summary: "Devolve a lista com os tipos de telefones",
        notes: "Retorna a lista de tipos de telefones fixos",
        type: "getTipoTelefoneResponse",
        nickname: "getTipoTelefone",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tipos de telefone retornada com sucesso",
                responseModel: "getTipoTelefoneResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de tipos de telefone",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "tipoTelefone": [{
        //         "tpTelefone": 10,
        //         "dsTpTelefone": "DE RECADO"
        //     }, {
        //         "tpTelefone": 15,
        //         "dsTpTelefone": "PROPRIO"
        //     }]
        // }

        {"tipoTelefone":[{"tpTelefone":"2","dsTpTelefone":"DE RECADO"},{"tpTelefone":"1","dsTpTelefone":"PROPRIO"}]}
        );
    }
};