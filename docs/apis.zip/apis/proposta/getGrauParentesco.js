module.exports = {
    spec: {
        description: "Devolve a lista com os possíveis graus de parentesco.",
        path: "/proposta/getGrauParentesco",
        method: "GET",
        summary: "Devolve a lista com os possíveis graus de parentesco.",
        notes: "Retorna a lista de opções de graus de parentesco.",
        type: "getGrauParentescoResponse",
        nickname: "getGrauParentesco",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de graus de parentesco retornados com sucesso",
                responseModel: "getGrauParentesco"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de graus de parentesco",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "grauParentesco": [
        //         {
        //         "idGrauParentesco": 1,
        //         "dsGrauParentesco": "PAI/ MÃE"
        //     }, {
        //         "idGrauParentesco": 2,
        //         "dsGrauParentesco": "FILHO(A)"
        //     }, {
        //         "idGrauParentesco": 3,
        //         "dsGrauParentesco": "IRMÃO(Ã)"
        //     }, {
        //         "idGrauParentesco": 4,
        //         "dsGrauParentesco": "PRIMO(A)"
        //     }, {
        //         "idGrauParentesco": 5,
        //         "dsGrauParentesco": "TIO(A)"
        //     }, {
        //         "idGrauParentesco": 6,
        //         "dsGrauParentesco": "AMIGO(A)"
        //     }, {
        //         "idGrauParentesco": 7,
        //         "dsGrauParentesco": "CÔNJUGE/ COMPANHEIRO(A)"
        //     }, {
        //         "idGrauParentesco": 8,
        //         "dsGrauParentesco": "VIZINHO"
        //     }, {
        //         "idGrauParentesco": 9,
        //         "dsGrauParentesco": "OUTROS"
        //     }]
        // }
            {"grauParentesco":[{"idGrauParentesco":"1007","dsGrauParentesco":"AMIGO&#x28;A&#x29;"},{"idGrauParentesco":"1003","dsGrauParentesco":"CONJUGE&#x2f;COMPANH"},{"idGrauParentesco":"1002","dsGrauParentesco":"FILHO&#x28;A&#x29;"},{"idGrauParentesco":"1004","dsGrauParentesco":"IRMAO&#x28;A&#x29;"},{"idGrauParentesco":"1010","dsGrauParentesco":"OUTROS"},{"idGrauParentesco":"1005","dsGrauParentesco":"PAI&#x2f;MAE"},{"idGrauParentesco":"1008","dsGrauParentesco":"PRIMO&#x28;A&#x29;"},{"idGrauParentesco":"1009","dsGrauParentesco":"TIO&#x28;A&#x29;"},{"idGrauParentesco":"1006","dsGrauParentesco":"VIZINHO&#x28;A&#x29;"}]}
        );
    }
};