module.exports = {
    spec: {
        description: "Devolve a lista de agentes certificados.",
        path: "/proposta/getAgenteCertificado",
        method: "GET",
        summary: "Devolve a lista de agentes certificados.",
        notes: "Retorna a lista de agentes certificados.",
        type: "getAgenteCertificadoResponse",
        nickname: "getAgenteCertificado",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de agentes certificados retornada com sucesso",
                responseModel: "getAgenteCertificadoResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de agentes certificados",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
            // {
            // "agenteCertificado": [{
            //     "idAgCertificado": 1,
            //     "nmAgCertificado": "Rafael Fleming",
            //     "nrCpfAgCertificado": "32245970897"
            // }, {
            //     "idAgCertificado": 2,
            //     "nmAgCertificado": "Luis Jesus",
            //     "nrCpfAgCertificado": "00000000191"
            // }

    //         ]
    //
    //
    // }

            {"agenteCertificado":[{"idAgCertificado":178,"nmAgCertificado":"BRIANDA DE MOURA DE A SANTOS","nrCpfAgCertificado":"69.171.068.104"},{"idAgCertificado":179,"nmAgCertificado":"JOANA DARC SILVA MENDES","nrCpfAgCertificado":"87.726.342.144"},{"idAgCertificado":2,"nmAgCertificado":"JOAO BOSCO DA SILVA","nrCpfAgCertificado":"11.403.918.520"},{"idAgCertificado":160,"nmAgCertificado":"JOSE EVERTON FERNANDES","nrCpfAgCertificado":"16.927.842.349"},{"idAgCertificado":217,"nmAgCertificado":"LEONARDO MOTA DE SALES","nrCpfAgCertificado":"7.360.027.667"},{"idAgCertificado":1,"nmAgCertificado":"LEONARDO MOTA DE SALES","nrCpfAgCertificado":"7.360.027.667"},{"idAgCertificado":219,"nmAgCertificado":"MARCELO DE CERQUEIRA CARMANINI","nrCpfAgCertificado":"5.259.427.696"},{"idAgCertificado":203,"nmAgCertificado":"MARCILIO FRANCO DA SILVEIRA","nrCpfAgCertificado":"1.268.807.605"},{"idAgCertificado":218,"nmAgCertificado":"MARCIO CRISTIANO BENNEMANN","nrCpfAgCertificado":"57.861.677.056"},{"idAgCertificado":175,"nmAgCertificado":"MARCOS FERNANDO MOREIRA","nrCpfAgCertificado":"78.088.568.832"},{"idAgCertificado":254,"nmAgCertificado":"MARCOS FERNANDO MOREIRA","nrCpfAgCertificado":"78.088.569.672"},{"idAgCertificado":188,"nmAgCertificado":"MARIA TERESINHA TAUFER MERZONI","nrCpfAgCertificado":"24.952.485.888"},{"idAgCertificado":177,"nmAgCertificado":"MARINA CROZETTA","nrCpfAgCertificado":"1.771.549.181"},{"idAgCertificado":247,"nmAgCertificado":"MARINA CROZETTA","nrCpfAgCertificado":"1.771.549.181"},{"idAgCertificado":189,"nmAgCertificado":"RENATO FERNANDO XAVIER","nrCpfAgCertificado":"47.435.329.536"},{"idAgCertificado":246,"nmAgCertificado":"TERESA MITSUE SAKAKIBARA TANAKAI","nrCpfAgCertificado":"36.391.697.949"}]}
);
    }
};
