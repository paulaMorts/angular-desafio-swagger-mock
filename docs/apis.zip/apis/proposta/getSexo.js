module.exports = {
    spec: {
        description: "Retorna o sexo.",
        path: "/proposta/getSexo",
        method: "GET",
        summary: "Retorna o sexo.",
        notes: "Retorna a lista de opções de sexo.",
        type: "getSexoResponse",
        nickname: "getSexo",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de sexo retornada com sucesso",
                responseModel: "getSexoResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de sexo",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send(
        //     {
        //     "sexo": [
        //         {
        //         "idSexo": "F",
        //         "dsSexo": "Feminino"
        //     }, {
        //         "idSexo": "M",
        //         "dsSexo": "Masculino"
        //     }]
        // }
            {"sexo":[{"idSexo":"F","dsSexo":"FEMININO"},{"idSexo":"M","dsSexo":"MASCULINO"}]}
        );
    }
};