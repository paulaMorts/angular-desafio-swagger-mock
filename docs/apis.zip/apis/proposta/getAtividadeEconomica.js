var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Devolve a lista de possíveis opções para atividade econômica.",
        path: "/proposta/getAtividadeEconomica/{grpAtividadeEconomica}",
        method: "GET",
        summary: "Devolve a lista de possíveis opções para atividade econômica.",
        notes: "Retorna a lista de possíveis opções para atividade econômica.",
        type: "getAtividadeEconomicaResponse",
        nickname: "getAtividadeEconomica",
        produces: ["application/json"],
        parameters: [paramTypes.path("grpAtividadeEconomica", "Grupo de atividade econÔmica", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de atividade econômica retornadas com sucesso",
                responseModel: "getAtividadeEconomicaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de atividade econômica",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "atividadeEconomica": [{
                "idAtividadeEconomica": 1,
                "dsAtividadeEconomica": "ATIVIDADE A-" + req.params.grpAtividadeEconomica
            }, {
                "idAtividadeEconomica": 2,
                "dsAtividadeEconomica": "ATIVIDADE B-" + req.params.grpAtividadeEconomica
            }]
        });
    }
};