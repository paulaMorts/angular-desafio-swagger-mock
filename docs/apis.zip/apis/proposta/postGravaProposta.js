var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Efetua a gravação dos valores da proposta",
        path: "/proposta/gravaProposta",
        method: "POST",
        summary: "Efetua a gravação dos valores da proposta",
        notes: "Executa a gravação dos dados da proposta.",
        type: "postGravaPropostaResponse",
        nickname: "postGravaProposta",
        produces: ["application/json"],
        parameters: [paramTypes.body("postPropostaGravaPropostaRequest", "Parametros da proposta", "postPropostaGravaPropostaRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Proposta gravada com sucesso",
                responseModel: "postGravaPropostaResponse"
            },
            {
                code: "500",
                reason: "Erro ao gravar proposta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
			proposta: {
				"idProposta":req.body.proposta.idProposta ? req.body.proposta.idProposta : 0,
				"cdErro":0,
				"dsMensagem":"",
				"dsStatus": "STATUS",
				"cdStatus": req.body.proposta.idProposta == 2 ? "E" : (req.body.proposta.idProposta == 3 ? "N" : "A")	
			}
        });
    }
};