var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Realiza a busca de endereço com base no endereço.",
        path: "/proposta/getEndereco",
        method: "GET",
        summary: "Realiza a busca de endereço com base no endereço.",
        notes: "Recebe como parâmetro o CEP ou estado (UF), cidade e município e retorna o endereço completo",
        type: "getEnderecoResponse",
        nickname: "getEndereco",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("cdCep", "Código postal do endereço.", "string"),
            paramTypes.query("idUf", "Sigla do estado (UF).", "string"),
            paramTypes.query("dsMunicipio", "Município do endereço.", "string"),
            paramTypes.query("dsLogradouro", "Endereço/Logradouro.", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de endereços retornada com sucesso",
                responseModel: "getCepResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a endereços de municípios",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.query.idUf === "RJ" || req.query.cdCep === "11111111") {
            res.status(500).send({
                error: {
                    code: "101",
                    message: "Erro ao realizar a busca de municípios"
                }
            });
        }
        else if (req.query.cdCep === "22222222") {
			res.status(200).send({
				"endereco":[
					{
						"cdCep":"22222222",
						"dsMunicipio":"IPUACU",
						"dsLogradouro":" ",
						"dsBairro":"",
						"idMunicipio":"64830528",
						"idUf":"SC"
					}
				]
			});
		}
		else {
			res.status(200).send({
                "endereco": [{
                    "cdCep": "02534020",
                    "dsLogradouro": "General Iberê Leal Ferreira",
                    "dsBairro": req.query.cdCep == "22222222" ? "Casa Verde Casa Verde Casa Verde Casa Verde" : "Casa Verde",
                    "dsMunicipio": "SAO PAULO",
                    "idMunicipio": 8740628,
                    "idUf": "SP"
                }, {
                    "cdCep": "02534021",
                    "dsLogradouro": "General Iberê Leal Ferreira",
                    "dsBairro": "Casa Verde",
                    "dsMunicipio": "SAO PAULO",
                    "idMunicipio": 8740628,
                    "idUf": "SP"
                }, {
                    "cdCep": "02534022",
                    "dsLogradouro": "General Iberê Leal Ferreira",
                    "dsBairro": "Casa Verde",
                    "dsMunicipio": "SAO PAULO",
                    "idMunicipio": 8740628,
                    "idUf": "SP"
                }]
            });
        }
    }
};