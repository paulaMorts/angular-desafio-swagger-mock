var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Devolve a lista com os possíveis tipos de relacionamento com a empresa.",
        path: "/proposta/getTipoRelacionamentoEmpresa/{idNaturezaJuridica}",
        method: "GET",
        summary: "Devolve a lista com os possíveis tipos de relacionamento com a empresa.",
        notes: "Retorna a lista de opções de tipos de relacionamento com a empresa.",
        type: "getTipoRelacionamentoEmpresaResponse",
        nickname: "getTipoRelacionamentoEmpresa",
        produces: ["application/json"],
        parameters: [paramTypes.path("idNaturezaJuridica", "Identificador da Natureza Jurídica da Empresa", "number", true)],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tipos de relacionamento com a empresa retornados com sucesso",
                responseModel: "getTipoRelacionamentoEmpresa"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de tipos de relacionamento com a empresa",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        if (req.params.idNaturezaJuridica) {
			res.status(200).send(
				{"tipoRelacionamentoEmpresa":[{"idTipoRelEmpresa":"1","dsTipoRelEmpresa":"EMPRESA TEM C&#x2f; SOCIO&#x2f;COTISTA"},{"idTipoRelEmpresa":"2","dsTipoRelEmpresa":"EMPRESA TEM COMO VINC ADM"}]}
			);
		}
		else {
			res.status(500);
		}
    }
};