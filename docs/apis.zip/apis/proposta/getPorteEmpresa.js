module.exports = {
    spec: {
        description: "Devolve a lista de possíveis opções para porte da empresa.",
        path: "/proposta/getPorteEmpresa",
        method: "GET",
        summary: "Devolve a lista de possíveis opções para porte da empresa.",
        notes: "Retorna a lista de possíveis opções para porte da empresa.",
        type: "getPorteEmpresaResponse",
        nickname: "getPorteEmpresa",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de portes de empresa retornadas com sucesso",
                responseModel: "getPorteEmpresaResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca de protes de empresa",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "porteEmpresa": [{
                "idPorteEmpresa": 1,
                "dsPorteEmpresa": "MICRO"
            }, {
                "idPorteEmpresa": 2,
                "dsPorteEmpresa": "PEQUENA"
            }, {
                "idPorteEmpresa": 3,
                "dsPorteEmpresa": "MÉDIA"
            }, {
                "idPorteEmpresa": 4,
                "dsPorteEmpresa": "GRANDE"
            }]
        });
    }
};