var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
    spec: {
        description: "Retorna uma lista de propostas que não encontram-se vinculadas a etiqueta",
        path: "/proposta/getPropostasNaoVinculadasEtiqueta",
        method: "GET",
        summary: "Retorna uma lista de propostas que não encontram-se vinculadas a nenhuma etiqueta",
        notes: "Retorna uma lista de propostas que não encontram-se vinculadas a nenhuma etiqueta",
        type: "getPropostasNaoVinculadasEtiquetaResponse",
        nickname: "getPropostasNaoVinculadasEtiqueta",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("nrPagina", "Número da página requisitada.", "number"),
            paramTypes.query("dsOrdenacao", "Opções de ordenação (idProposta, dtInclusao, nmCliente, nrCpfCnpj).", "string"),
            paramTypes.query("nrProposta", "Número da proposta", "string"),
            paramTypes.query("nrCpfCnpj", "Número do cpf do cliente", "string"),
            paramTypes.query("nmCliente", "Nome do cliente", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de propostas não vinculadas a etiqueta retornada com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao recuperar de propostas não vinculadas a etiqueta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //var data = new Date("2016/06/15");
        var propostas = [
            {
                "idProposta": 222,
                "cdProposta": 9283740293,
                "dtInclusao": new Date("2016/06/10"),
                "nmCliente": "João dos Santos",
                "nrCpfCnpj": 23425467392
            },
            {
                "idProposta": 333,
                "cdProposta": 3243454562,
                "dtInclusao": new Date("2016/06/01"),
                "nmCliente": "Maria Batista",
                "nrCpfCnpj": 56401923183
            },
            {
                "idProposta": 444,
                "cdProposta": 4456567678,
                "dtInclusao": new Date("2016/06/19"),
                "nmCliente": "Jose da Silva",
                "nrCpfCnpj": 56496639069
            },
            {
                "idProposta": 555,
                "cdProposta": 1211211121,
                "dtInclusao": new Date("2016/06/03"),
                "nmCliente": "Pedro Alves",
                "nrCpfCnpj": 11930293848
            },
            {
                "idProposta": 666,
                "cdProposta": 6667678989,
                "dtInclusao": new Date("2016/06/14"),
                "nmCliente": "Neymar Jr",
                "nrCpfCnpj": 23453452342
            },
            {
                "idProposta": 777,
                "cdProposta": 4356768989,
                "dtInclusao": new Date("2016/06/23"),
                "nmCliente": "Hulk Monstro",
                "nrCpfCnpj": 56567867980
            }
        ];
        //res.status(200).json(propostas);

        // se foi passado, realiza a ordenacao
        if (req.query.dsOrdenacao)
            propostas = _.orderBy(propostas, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

        //se foi passado, realiza a paginacao (retorna resultados de 5 em 5)
        if (req.query.nrPagina) {
            var start = (req.query.nrPagina * 5) - 5;
            propostas = propostas.slice(start, start + 5);

            //retorna o resultado
            res.status(200).send({
                "propostasList": propostas,
                "paginacao": {
                    "nrPagina": req.query.nrPagina,
                    "qtItens": 5,
                    "qtResultados": 6,
                    "qtPaginas": 2
                },
                "tipoEnvio": "C"
            });
            //se nao foi passada paginacao, retorna todos os resultados
        }

        if (req.query.nrProposta){
            res.status(200).send({
                "propostasList": _.filter(propostas, function(o) { return o.idProposta == req.query.nrProposta; }),
                "paginacao": {
                    "nrPagina": 1,
                    "qtItens": 5,
                    "qtResultados": 1,
                    "qtPaginas": 1
                },
                "tipoEnvio": "C"
            });
        }

        if (req.query.nrCpfCnpj){
            res.status(200).send({
                "propostasList": _.filter(propostas, function(o) { return o.nrCpfCnpj == req.query.nrCpfCnpj; }),
                "paginacao": {
                    "nrPagina": 1,
                    "qtItens": 5,
                    "qtResultados": 1,
                    "qtPaginas": 1
                },
                "tipoEnvio": "C"
            });
        }

        if (req.query.nmCliente){
            res.status(200).send({
                "propostasList": _.filter(propostas, function(o) { return o.nmCliente == req.query.nmCliente; }),
                "paginacao": {
                    "nrPagina": 1,
                    "qtItens": 5,
                    "qtResultados": 1,
                    "qtPaginas": 1
                },
                "tipoEnvio": "C"
            });
        }

        else {
            res.status(200).send({"propostasList": propostas, "tipoEnvio": "M"});
        }


    }
};
