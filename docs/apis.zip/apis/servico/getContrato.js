var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var moment = require('moment');
var utils = require('../../utils/utils');

module.exports = {
    spec: {
        description: "Retorna detalhes de um contrato.",
        path: "/servicos/getContrato/{idContrato}",
        method: "GET",
        summary: "Retorna detalhes de um contrato.",
        notes: "Retorna detalhes de um contrato.",
        type: "getContratoResponse",
        nickname: "getContrato",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("idContrato", "Código da Loja", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Detalhe de contrato retornado com sucesso",
                responseModel: "getContratoResponse"
            },
            {
                code: "500",
                reason: "Erro ao retornar Detalhe de contrato",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "detalheContrato": {
                "idContrato": req.params.idContrato,
                "nmCliente": utils.getRandomName(),
                "dsPosicaoAtual": "Posição atual"
            }
        });
    }
};
