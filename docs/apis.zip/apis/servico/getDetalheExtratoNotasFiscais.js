var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o detalhamento de um Extrato de Notas Fiscais",
        path: "/servicos/getExtratoNotasFiscais/{idExtratoNotaFiscal}",
        method: "GET",
        summary: "Retorna o detalhamento de um Extrato de Notas Fiscais",
        notes: "Retorna o detalhamento de um Extrato de Notas Fiscais",
        type: "getExtratoNotasFiscaisResponse",
        nickname: "getExtratoNotasFiscais",
        produces: ["application/json"],
        parameters: [paramTypes.path("idExtratoNotaFiscal", "Identificador do extrato de Notas Fiscais", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Detalhe do Extrato de Notas Fiscais recuperado com sucesso"
            },
            {
                code: "500",
                reason: "Erro ao recuperar Detalhe do Extrato de Notas Fiscais",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {

      var detalheExtratoNotasFiscaisList = [
                                            {"idContrato": "12345", "nrCpfCnpjCliente": "11111111111", "dsTipoComissao": "Comis. 1", "dtPagamento": new Date("2016/06/10"),"vlBrutoEmissaoNF": 100500.30, "vlILA": 1000.99, "vlIR": 200.87, "vlISS": 300.85, "nrChassi": 99999999999999999},
                                            {"idContrato": "78912", "nrCpfCnpjCliente": "02222222222222", "dsTipoComissao": "Comis. 2", "dtPagamento": new Date("2016/06/12"),"vlBrutoEmissaoNF": 300500.30, "vlILA": 5000.99, "vlIR": 300.87, "vlISS": 400.85, "nrChassi": 88888888888888888}
      ];

        if(req.params.idEtiqueta > 500) {
            res.status(200).json();
        } else {
            res.status(200).json({
                                    "dtPeriodo": new Date("2016/06/10"),
                                    "idStatus": 1,
                                    "dsStatus": "Nota Fiscal pendente de inclusão",
                                    "vlBruto": 401000.60,
                                    "vlLiquido": 301000.60,
                                    "detalheExtratoNotasFiscaisList": detalheExtratoNotasFiscaisList
                                  });
        }
    }
};
