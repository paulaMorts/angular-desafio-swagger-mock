var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var moment = require('moment');
var utils = require('../../utils/utils');

module.exports = {
    spec: {
        description: "Retorna uma lista de extrato liberação.",
        path: "/servicos/getExtratoLiberacao",
        method: "GET",
        summary: "Retorna uma lista de extrato liberação.",
        notes: "Retorna uma lista de extrato liberação.",
        type: "getExtratoLiberacaoResponse",
        nickname: "getExtratoLiberacao",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("dtLiberacao", "Data de Início", "date"),
            paramTypes.query("nrPagina", "Número da Página", "number", true),
            paramTypes.query("cdTab", "Código da Loja", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de extrato liberação retornada com sucesso",
                responseModel: "getExtratoLiberacaoResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de extrato liberação",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var dtInicio = new Date(2016, 3, 1);
        var data = [];

        for(var i= 1; i < 41; i++) {
            data.push({
                "idLiberacao": i.toString(),
                "cdTab": utils.getRandomNumber(9),
                "dtLiberacao": moment(utils.randomDate(dtInicio, new Date())).format(),
                "nmCliente": utils.getRandomName(),
                "nrCpfCnpj": utils.getCPF(),
                "vlLiberado": utils.getRandomNumber((i+1)*243),
                "nmParticipante": utils.getRandomCompanyName(),
                "qtParcelas": utils.getRandomNumber(24),
                "vlParcela": utils.getRandomNumber((i+1)*243),
                "dtPrimeiroVencimento": moment(utils.randomDate(dtInicio, new Date())).format(),
                "cdAprovacao": utils.getRandomNumber(999999999),
                "vlTC": utils.getRandomNumber(99999),
                "idFilial": utils.getRandomNumber(999),
                "cdBordero": utils.getRandomNumber(999999999),
                "dsModalidade": i % 3 ? "Flex" : "Padrão"
            });
        }

        var filteredData = data;

        if (req.query.cdTab) {
            filteredData = _.filter(filteredData, function (o) {
                return o.cdTab == req.query.cdTab
            });
        }

        if (req.query.dtLiberacao && req.query.dtInicio !== "") {
            var pDate = moment(req.query.dtLiberacao).format("DD/MM/YYYY");
            filteredData = _.filter(filteredData, function (o) {
                return moment(o.dtLiberacao).format("DD/MM/YYYY") == pDate;
            });
        }

        var totalRecords = filteredData.length;
        var start = (req.query.nrPagina*5)-5;
        filteredData = filteredData.slice(start, start+5);
        setTimeout(function () {
            res.status(200).send({
                "listaExtratoLiberacao":filteredData,
                "paginacao": {
                    "nrPagina": req.query.nrPagina,
                    "qtItens": 5,
                    "qtResultados": totalRecords,
                    "qtPaginas": Math.ceil(totalRecords/5)
                },
                "dtAtualizacao": moment(new Date()).format()
            });
        }, 1000);
    }
};
