var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var utils = require('../../utils/utils');
var moment = require('moment');

module.exports = {
    spec: {
        description: "Retorna a lista de detalhes dos extratos comissão.",
        path: "/servicos/getDetalheExtratoComissao/{idExtratoComissao}",
        method: "GET",
        summary: "Retorna uma lista de detalhe dos extratos comissão",
        notes: "Retorna uma lista de detalhe dos extratos comissão",
        type: "getExtratoComissaoDetalheResponse",
        nickname: "getDetalheExtratoComissao",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("idExtratoComissao", "Identificador do extrato comissão", "string"),
            paramTypes.query("nrPagina", "Número da Página", "number", true),
            paramTypes.query("dsOrdenacao", "Descrição da Ordenação", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Descrição da Direção de Ordenação", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de detalhes extrato comissão retornada com sucesso",
                responseModel: "getExtratoComissaoDetalheResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista detalhes de extrato comissão",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var dtInicio = new Date(2016, 4, 1);
        var data = [];

        for(var i= 0; i < 40; i++) {
            data.push({
                "idContrato": i.toString(),
                "nrCpfCnpj": utils.getCPF(),
                "nrChassi": utils.getChassi(),
                "vlLiquido": (i+1)*143
            });
        }

        var filteredData = data;

        if(req.query.dsOrdenacao && req.query.dsOrdenacao !== "")
            filteredData = _.orderBy(filteredData, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

        var dtInicial = utils.randomDate(dtInicio, new Date());
        var _resumoExtratoComissaoDetalhe = {
            "dtInicial": moment(dtInicial).format(),
            "dtFinal": moment(utils.randomDate(dtInicio, dtInicial)).format(),
            "vlLiquidoTotal": _.sumBy(filteredData, function(o) { return o.vlLiquido; })
        };


        var totalRecords = filteredData.length;
        var start = (req.query.nrPagina*5)-5;
        filteredData = filteredData.slice(start, start+5);
        setTimeout(function () {
            res.status(200).send({
                "listaExtratoComissaoDetalhe":filteredData,
                "resumoExtratoComissaoDetalhe": _resumoExtratoComissaoDetalhe,
                "paginacao": {
                    "nrPagina": req.query.nrPagina,
                    "qtItens": 5,
                    "qtResultados": totalRecords,
                    "qtPaginas": totalRecords/5
                }
            });
        }, 2000);
    }
};
