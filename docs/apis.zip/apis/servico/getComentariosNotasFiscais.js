var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
                  spec: {
                      description: "Retorna uma lista de comentários de notas fiscais",
                      path: "/servicos/getComentariosNotasFiscais/{idNotaFiscal}",
                      method: "GET",
                      summary: "Retorna uma lista de comentários de notas fiscais",
                      notes: "Retorna uma lista de comentários de notas fiscais",
                      type: "getComentariosNotasFiscaisResponse",
                      nickname: "getComentariosNotasFiscais",
                      produces: ["application/json"],
                      parameters: [
                        paramTypes.query("idNotaFiscal", "Id da Nota Fiscal", "number")
                      ],
                      errorResponses: [
                          {
                              code: "200",
                              reason: "Lista de comentários  de Notas Fiscais retornada com sucesso"
                          },
                          {
                              code: "500",
                              reason: "Erro ao recuperar lista de comentários de Notas Fiscais",
                              responseModel: "errorResponse"
                          }
                      ]
                  },

                  action: function (req, res) {
					var comentariosList = [
                              {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
                              {"dtComentario": new Date("2016/06/04"),"dsComentario": "O documento que foi enviado não é uma Nota Fiscal"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"},
							  {"dtComentario": new Date("2016/06/05"),"dsComentario": "A Nota Fiscal encontra-se Ilegível"}
					];
	  
					res.status(200).json({
                                    "comentariosList": comentariosList
                                  });
                    
                     
                  
                } // fim do action
              }; // fim do module.exports
