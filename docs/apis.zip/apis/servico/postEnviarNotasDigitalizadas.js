var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Envia uma lista de notas fiscais digitalizadas",
        path: "/notasDigitalizadas/enviar/{idExtratoNotaFiscal}",
        method: "POST",
        summary: "Envia uma lista de notas fiscais digitalizadas",
        notes: "Recebe uma lista contendo o base64 ou URL para uma nota fiscal digitalizada e realiza o upload.",
        type: "postEnviarNotasDigitalizadasResponse",
        nickname: "postEnviarNotasDigitalizadas",
        produces: ["application/json"],
        parameters: [paramTypes.body("postEnviarNotasDigitalizadasRequest", "Lista de notas fiscais digitalizadas", "postEnviarNotasDigitalizadasRequest"),
					 paramTypes.path("idExtratoNotaFiscal", "Identificador do extrato de Notas Fiscais", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Notas digitalizadas enviadas com sucesso",
                responseModel: "postEnviarNotasDigitalizadasResponse"
            },
            {
                code: "500",
                reason: "Erro ao enviar notas fiscais",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            retorno: {
				dsMensagem: "OK"
			}
        });
    }
};