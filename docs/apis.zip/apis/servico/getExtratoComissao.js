var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var moment = require('moment');
var utils = require('../../utils/utils');

module.exports = {
    spec: {
        description: "Retorna uma lista de extratos comissão.",
        path: "/servicos/getExtratoComissao",
        method: "GET",
        summary: "Retorna uma lista de extratos comissão",
        notes: "Retorna uma lista de extratos comissão",
        type: "getExtratoComissaoResponse",
        nickname: "getExtratoComissao",
        produces: ["application/json"],
        parameters: [
            paramTypes.query("dtInicio", "Data de Início", "date"),
            paramTypes.query("dtFim", "Data de Término", "date"),
            paramTypes.query("idTipo", "Id do tipo", "string"),
            paramTypes.query("nrPagina", "Número da Página", "number", true),
            paramTypes.query("dsOrdenacao", "Descrição da Ordenação", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Descrição da Direção de Ordenação", "string"),
            paramTypes.query("cdTab", "Código da Loja", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de extrato comissão retornada com sucesso",
                responseModel: "listarResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de extrato comissão",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var dtInicio = new Date(2016, 3, 1);
        var data = [];

        for(var i= 0; i < 40; i++) {
            data.push({
                "idExtrato": i.toString(),
                "dtExtrato": moment(utils.randomDate(dtInicio, new Date())).format(),
                "idFilial": i*7,
                "nrCnpjTomador": utils.getCPF(),
                "vlBruto": (i+1)*243,
                "vlLiquido": (i+1)*143,
                "dsTipo": i % 3 ? "Leasing" : "CDC",
                "idTipo": i % 3 ? 1 : 2,
                "cdTab": i % 2 ? 1 : 2
            });
        }

        var filteredData = data;

        if (req.query.cdTab) {
            filteredData = _.filter(filteredData, function (o) {
                return o.cdTab == req.query.cdTab
            });
        }

        if (req.query.dtInicio && req.query.dtFim && (req.query.dtInicio !== "") && (req.query.dtFim !== "")) {
            var inicio = req.query.dtInicio,
                fim = req.query.dtFim;
            filteredData = _.filter(filteredData, function (o) {
                var compareDate = moment(o.dtExtrato, moment.ISO_8601);
                var startDate = moment(inicio, moment.ISO_8601);
                var endDate = moment(fim, moment.ISO_8601);
                return compareDate.isBetween(startDate, endDate);
            });
        }

        if (req.query.idTipo) {
            filteredData = _.filter(filteredData, function (o) {
                return o.idTipo == req.query.idTipo
            });
        }

        if(req.query.dsOrdenacao && req.query.dsOrdenacao !== "")
            filteredData = _.orderBy(filteredData, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

        var _resumoExtratoComissao = {
            "vlBrutoTotal": _.sumBy(filteredData, function(o) { return o.vlBruto; }),
            "vlLiquidoTotal": _.sumBy(filteredData, function(o) { return o.vlLiquido; })
        };


        var totalRecords = filteredData.length;
        var start = (req.query.nrPagina*5)-5;
        filteredData = filteredData.slice(start, start+5);
        setTimeout(function () {
            res.status(200).send({
                "listaExtratoComissao":filteredData,
                "resumoExtratoComissao": _resumoExtratoComissao,
                "paginacao": {
                    "nrPagina": req.query.nrPagina,
                    "qtItens": 5,
                    "qtResultados": totalRecords,
                    "qtPaginas": totalRecords/5
                }
            });
        }, 2000);
    }
};
