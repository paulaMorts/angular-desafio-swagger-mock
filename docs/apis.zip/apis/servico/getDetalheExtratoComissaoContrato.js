var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');
var utils = require('../../utils/utils');
var moment = require('moment');

module.exports = {
    spec: {
        description: "Retorna detalhes do contrato de extrato comissão.",
        path: "/servicos/getDetalheExtratoComissaoContrato/{idContrato}",
        method: "GET",
        summary: "Retorna detalhes do contrato de extrato comissão.",
        notes: "Retorna detalhes do contrato de extrato comissão.",
        type: "getExtratoComissaoDetalheContratoResponse",
        nickname: "getDetalheExtratoComissaoContrato",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("idContrato", "Identificador do contrato", "string")
        ],
        errorResponses: [
            {
                code: "200",
                reason: "Detalhes de contrato extrato comissão retornada com sucesso",
                responseModel: "getExtratoComissaoDetalheContratoResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar detalhes de contrato extrato comissão",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {

        var _extratoComissaoDetalheContrato = {
            "contrato":{
                "idContrato": "1234567890",
                "vlLiquido": 443221,
                "dtEmissao": moment(new Date(2016, 4, 5)).format(),
                "dtLiberacao": moment(new Date(2016, 5, 15)).format(),
                "dtPagamento": moment(new Date(2016, 6, 12)).format()
            },
            "dadosCliente" : {
                "nrCpfCnpj": "00011122233",
                "nmCliente": "Silvester Stallone Balboa",
                "nrChassi": "8225998126436024001"
            },
            "acordo": {
                "nrAcordo": "000000000",
                "dsTipoComissao": "Comissão Pugilista",
                "vlBruto": 123488.56,
                "vlIR": 88377,
                "vlISS": 12717.3,
                "pcIla": 43.4,
                "vlIla": 73621
            }
        };

        setTimeout(function () {
            res.status(200).send({
                "extratoComissaoDetalheContrato":_extratoComissaoDetalheContrato,
                "resumoExtratoComissaoDetalhe": {
                    "dtInicial": moment(new Date(2016, 4, 5)).format(),
                    "dtFinal": moment(new Date(2016, 6, 5)).format(),
                    "vlLiquidoTotal": 4332234
                }
            });
        }, 1000);
    }
};
