module.exports = {
    spec: {
        description: "Retorna lista de perguntas e respostas comuns sobre nota fiscal.",
        path: "/servicos/getFaqNotaFiscal",
        method: "GET",
        summary: "Retorna lista de perguntas e respostas comuns sobre nota fiscal.",
        notes: "Retorna lista de perguntas e respostas comuns sobre nota fiscal.",
        type: "getFaqNotaFiscalResponse",
        nickname: "getFaqNotaFiscal",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de perguntas e respostas sobre nota fiscal",
                responseModel: "getFaqNotaFiscalResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar perguntas do faq",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "faqNotaFiscal": [
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."},
                                {dsQuestao: "Porque é obrigatória a emissão de Nota Fiscal?",dsResposta: "A obrigatoriedade de emissão das Notas Fiscais está prevista em lei nº 8.846/94, que determina que a emissão da nota fiscal deverá ser efetuada no momento da efetivação da operação, ou seja, prestação do serviço."},
                                {dsQuestao: "A partir de quando é necessária é obrigatória a emissão de Nota Fiscal? ",dsResposta: "Desde que entrou em vigor a lei nº 8.846/94 que dispõe sobre a obrigatoriedade de emissão de nota fiscal. Assim, todos os Correspondentes que não apresentarem a nota fiscal referente aos serviços prestados não fará jus ao recebimento de comissão."}

        ]
        });
    }
};
