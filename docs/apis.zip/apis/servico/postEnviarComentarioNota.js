var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Envia mensagem de comentário sobre uma nota fiscal",
        path: "/comentarioNota/enviar",
        method: "POST",
        summary: "Envia mensagem de comentário sobre uma nota fiscal",
        notes: "Recebe um texto com comentários para ajuste de uma determinada nota e inicia o workflow para análise",
        type: "postEnviarComentarioNotaResponse",
        nickname: "postEnviarComentarioNota",
        produces: ["application/json"],
        parameters: [paramTypes.body("postEnviarComentarioNotaRequest", "Comentário e identificador da nota", "postEnviarComentarioNotaRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Comentário enviado com sucesso",
                responseModel: "postEnviarComentarioNotaResponse"
            },
            {
                code: "500",
                reason: "Erro ao enviar comentários",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            retorno: {
				dsMensagem: "OK"
			}
        });
    }
};