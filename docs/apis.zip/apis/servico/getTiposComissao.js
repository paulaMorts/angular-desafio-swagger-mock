module.exports = {
    spec: {
        description: "Retorna lista de tipos de comissão",
        path: "/servicos/getTiposComissao",
        method: "GET",
        summary: "Retorna lista de tipos de comissão",
        notes: "Retorna lista de tipos de comissão",
        type: "getTiposComissaoResponse",
        nickname: "getTiposComissao",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tipos de comissão retornada com sucesso",
                responseModel: "getTiposComissaoResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar tipos de comissãos",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "tiposComissao": [
                {
                    "idTipo": "1",
                    "dsTipo": "Leasing"
                },
                {
                    "idTipo": "2",
                    "dsTipo": "CDC"
                }
            ]
        });
    }
};
