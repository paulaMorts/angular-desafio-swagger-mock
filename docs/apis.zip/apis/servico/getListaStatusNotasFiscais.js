var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de status de Notas Fiscais",
        path: "/servicos/getListaStatusNotasFiscais",
        method: "GET",
        summary: "Retorna a lista de status de Notas Fiscais",
        notes: "Retorna a lista de status de Notas Fiscais",
        type: "getListaStatusNotasFiscaisResponse",
        nickname: "getListaStatusNotasFiscais",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de status de notas fiscais retornada com sucesso",
                responseModel: "getListaStatusNotasFiscaisResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de status de notas fiscais",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "statusNotasFiscaisList": [
                                        {idStatus: 1,dsStatus: "Nota Fiscal pendente de inclusão"},
                                        {idStatus: 2,dsStatus: "Nota Fiscal em análise"},
                                        {idStatus: 3,dsStatus: "Nota Fiscal irregular"},
                                        {idStatus: 4,dsStatus: "Nota Fiscal aprovada, aguardando documento físico"},
                                        {idStatus: 5,dsStatus: "Nota Fiscal aprovada, documento físico recebido"},
                                        {idStatus: 6,dsStatus: "Nota Fiscal aprovada, documento físico irregular"},
                                        {idStatus: 7,dsStatus: "Nota Fiscal aprovada"},
                                        {idStatus: 8,dsStatus: "Contrato(s) estornado(s), Nota Fiscal enviada no mês anterior"},
                                        {idStatus: 9,dsStatus: "Registro duplicado indevidamente"}

            ]
        });
    }
};
