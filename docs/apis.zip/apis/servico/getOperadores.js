var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a lista de operadores e suas tabs",
        path: "/servicos/getOperadores",
        method: "GET",
        summary: "Retorna a lista de operadores e suas tabs",
        notes: "Retorna a lista de operadores e suas tabs",
        type: "getOperadoresResponse",
        nickname: "getOperadores",
        produces: ["application/json"],
        parameters: [paramTypes.query("filtro", "Filtro que deverá ser utilizado na busca de operadores", "string", true)],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de tabs e operadores",
                responseModel: "getOperadoresResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de operadores",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
		var tabList = [
				{
					"dsNome": "Tab 048593",
					"listaOperadores": [
						{
							"dsNome": "José dos Santos Albuquerque"
						}
					]
				},
				{
					"dsNome": "Tab 256381",
					"listaOperadores": [
						{
							"dsNome": "Joseane de Assis 1"
						},
						{
							"dsNome": "Joseane de Assis 2"
						},
						{
							"dsNome": "Joseane de Assis 3"
						},
						{
							"dsNome": "Joseane de Assis 4"
						},
						{
							"dsNome": "Joseane de Assis 5"
						},
						{
							"dsNome": "Joseane de Assis 6"
						},
						{
							"dsNome": "Joseane de Assis 7"
						},
						{
							"dsNome": "Joseane de Assis 8"
						}
					]
				}
			];
		
		if (req.query.filtro && req.query.filtro.length > 0) {
			tabList.pop();
		}
		
        res.status(200).send({
            "tabs": tabList
        });
    }
};
