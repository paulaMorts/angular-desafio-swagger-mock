var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
                  spec: {
                      description: "Retorna uma lista de notas fiscais disponíveis",
                      path: "/servicos/getExtratoNotasFiscais",
                      method: "GET",
                      summary: "Retorna uma lista de notas fiscais disponíveis",
                      notes: "Retorna uma lista de notas fiscais disponíveis",
                      type: "getExtratoNotasFiscaisResponse",
                      nickname: "getExtratoNotasFiscais",
                      produces: ["application/json"],
                      parameters: [
                        paramTypes.query("nrPagina", "Número da página requisitada.", "number"),
                        paramTypes.query("dsOrdenacao", "Opções de ordenação (dtPeriodo, nrCNPJTomador etc.).", "string"),
                        paramTypes.query("dsDirecaoOrdenacao", "Opções para direção da ordenação (asc, desc).", "string"),
                        paramTypes.query("cdTab", "Código da Tab (Loja) - Ex: 1 e 2", "string"),
                        paramTypes.query("dtFim", "Data fim do Período", "string"),
                        paramTypes.query("dtInicio", "Data Inicio do Período", "string"),
                        paramTypes.query("idStatus", "Id do Status", "number")
                      ],
                      errorResponses: [
                          {
                              code: "200",
                              reason: "Lista de Notas Fiscais retornada com sucesso"
                          },
                          {
                              code: "500",
                              reason: "Erro ao recuperar lista de Notas Fiscais",
                              responseModel: "errorResponse"
                          }
                      ]
                  },

                  action: function (req, res) {

                    var extratoNotasFiscais = [];
                    var totalExtratoNotasFiscaisStatus = [];

                    // Se informar o código da tab = 1 ou não informar nada, retorna os registros abaixo.
                    if (req.query.cdTab == 1 || !req.query.cdTab) {
                            extratoNotasFiscais.push(
                                                        {"idExtratoNotaFiscal": 1,"dtPeriodo":  new Date("2016/04/10"),"nrCNPJTomador":  "01111111111111","nrCNPJBeneficiario":  "01111111111122","nrCpfCnpjCliente": "11111111111","vlBrutoEmissaoNF": 200070.99,"dtLimiteEnvioNF": new Date("2016/07/10"),
                                                        //"dsStatus": "Nota Fiscal aprovada, aguardando documento físico"
                                                        "idStatus": 1,"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                        {"idExtratoNotaFiscal": 2,"dtPeriodo":  new Date("2016/06/15"),"nrCNPJTomador":  "02211111111111","nrCNPJBeneficiario":  "02211111111122","nrCpfCnpjCliente": "22222222222","vlBrutoEmissaoNF": 342070.00,"dtLimiteEnvioNF": new Date("2016/07/15"),
                                                        "idStatus": 1,"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                        {"idExtratoNotaFiscal": 3,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 3,"dsStatus": "Nota Fiscal irregular"},
                                                        {"idExtratoNotaFiscal": 4,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 865070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 3,"dsStatus": "Nota Fiscal irregular"},
                                                        {"idExtratoNotaFiscal": 5,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 4,"dsStatus": "Nota Fiscal aprovada, aguardando documento físico"},
                                                        {"idExtratoNotaFiscal": 6,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 4,"dsStatus": "Nota Fiscal aprovada, aguardando documento físico"},
                                                        {"idExtratoNotaFiscal": 7,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 6,"dsStatus": "Nota Fiscal aprovada, documento físico irregular"},
                                                        {"idExtratoNotaFiscal": 8,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 6,"dsStatus": "Nota Fiscal aprovada, documento físico irregular"},
                                                        {"idExtratoNotaFiscal": 9,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 1,"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                        {"idExtratoNotaFiscal": 10,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 1,"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                        {"idExtratoNotaFiscal": 11,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),
                                                        "idStatus": 1,"dsStatus": "Nota Fiscal pendente de inclusão"}
                                                    );
                            totalExtratoNotasFiscaisStatus = [
                                                        {idStatus: 1,dsStatus: "Nota Fiscal pendente de inclusão", nrQtdTotalNF: 4},
                                                        {idStatus: 3,dsStatus: "Nota Fiscal irregular", nrQtdTotalNF: 2},
                                                        {idStatus: 4,dsStatus: "Nota Fiscal aprovada, aguardando documento físico", nrQtdTotalNF: 2},
                                                        {idStatus: 6,dsStatus: "Nota Fiscal aprovada, documento físico irregular", nrQtdTotalNF: 2}
                            ];
                    };

                    // Se informar o código da tab = 2 ou não informar nada, retorna os registros abaixo.
                    if (req.query.cdTab == 2 || !req.query.cdTab) {
                          extratoNotasFiscais.push(
                                                      {"idExtratoNotaFiscal": 12,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 13,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 14,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 15,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 15,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 16,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 17,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 18,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 19,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"},
                                                      {"idExtratoNotaFiscal": 21,"dtPeriodo":  new Date("2016/06/16"),"nrCNPJTomador":  "03311111111111","nrCNPJBeneficiario":  "03311111111122","nrCpfCnpjCliente": "33333333333","vlBrutoEmissaoNF": 965070.00,"dtLimiteEnvioNF": new Date("2016/07/16"),"dsStatus": "Nota Fiscal pendente de inclusão"}
                                                  );
                          totalExtratoNotasFiscaisStatus = [
                                                      {idStatus: 1,dsStatus: "Nota Fiscal pendente de inclusão", nrQtdTotalNF: 10},
                                                      {idStatus: 3,dsStatus: "Nota Fiscal irregular", nrQtdTotalNF: 0},
                                                      {idStatus: 4,dsStatus: "Nota Fiscal aprovada, aguardando documento físico", nrQtdTotalNF: 0},
                                                      {idStatus: 6,dsStatus: "Nota Fiscal aprovada, documento físico irregular", nrQtdTotalNF: 0}
                          ];


                    };

                    //se não informou o cdTab, retorna todos.
                    if (!req.query.cdTab) {
                        totalExtratoNotasFiscaisStatus = [
                          {idStatus: 1,dsStatus: "Nota Fiscal pendente de inclusão", nrQtdTotalNF: 33},
                          {idStatus: 3,dsStatus: "Nota Fiscal irregular", nrQtdTotalNF: 21},
                          {idStatus: 4,dsStatus: "Nota Fiscal aprovada, aguardando documento físico", nrQtdTotalNF: 06},
                          {idStatus: 6,dsStatus: "Nota Fiscal aprovada, documento físico irregular", nrQtdTotalNF: 10}
                        ];
                    }

                    // se foi passado, realiza a ordenacao
                    if(req.query.dsOrdenacao)
                        extratoNotasFiscais = _.orderBy(extratoNotasFiscais, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);


                    if(req.query.idStatus){
                      extratoNotasFiscais = _.filter(extratoNotasFiscais, function(item){
                                                      return item.idStatus == req.query.idStatus
                                                    });
                      //console.log("entrando no cdtab");
                      //console.log(extratoNotasFiscais);
                    };


                    //se foi passado, realiza a paginacao (retorna resultados de 5 em 5)
                    if(req.query.nrPagina){
                        var start = (req.query.nrPagina*10)-10;
                        extratoNotasFiscais = extratoNotasFiscais.slice(start, start+10);

                        //retorna o resultado
                        res.status(200).send(
                                              {
                                                "extratoNotasFiscaisList": extratoNotasFiscais,
                                                "totalExtratoNotasFiscaisStatusList": totalExtratoNotasFiscaisStatus,
                                                "paginacao": {
                                                  "nrPagina": req.query.nrPagina,
                                                  "qtItens": 10,
                                                  "qtResultados": 21,
                                                  "qtPaginas": 3
                                                }
                                              }
                                            );
                  }
                  //se nao foi passada paginacao, retorna todos os resultados
                  else {
                    //res.status(200).send({"extratoNotasFiscaisList": extratoNotasFiscais});
                      res.status(200).send(
                                            {
                                              "extratoNotasFiscaisList": extratoNotasFiscais,
                                              "totalExtratoNotasFiscaisStatusList": totalExtratoNotasFiscaisStatus,
                                              "paginacao": {
                                                //"nrPagina": req.query.nrPagina,
                                                "qtItens": 10,
                                                "qtResultados": 21,
                                                "qtPaginas": 3
                                              }
                                            }
                     );
                  };
                } // fim do action
              }; // fim do module.exports
