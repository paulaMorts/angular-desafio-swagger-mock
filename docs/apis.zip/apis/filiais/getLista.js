var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna lista de filiais para o usuário.",
        path: "/filiais/getLista",
        method: "GET",
        summary: "Retorna lista de filiais para o usuário.",
        notes: "Retorna lista de filiais para o usuário.",
        type: "getFiliaisResponse",
        nickname: "getFiliais",
        produces: ["application/json"],
        parameters: [],
        errorResponses: [
            {
                code: "200",
                reason: "Lista de filiais retornada com sucesso",
                responseModel: "getLojasResponse"
            },
            {
                code: "500",
                reason: "Erro ao carregar lista de filiais",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "listaFiliais": [
                {
                    "idFilial": "1",
                    "nmFilial": "VW Norte"
                },
                {
                    "idFilial": "2",
                    "nmFilial": "VW Centro"
                },
                {
                    "idFilial": "3",
                    "nmFilial": "VW Leste"
                }
            ]
        });
    }
};
