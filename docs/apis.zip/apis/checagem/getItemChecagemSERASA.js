var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna os detalhes de um item da checagem para a proposta.",
        path: "/serasa/resumo/",
        method: "POST",
        summary: "Retorna os detalhes de um item da checagem para a proposta.",
        notes: "Recebe como parâmetro o documento da pessoa e realiza a avaliação no SERASA.",
        type: "getItemChecagemResponse",
        nickname: "getItemChecagem",
        produces: ["application/json"],
        parameters: [paramTypes.body("postItemChecagemSERASARequest", "Mensagem contendo o CPF/CNPJ da pessoa que deve ser avaliada.", "postItemChecagemSERASARequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Detalhes do item de checagem do SERASA retornado com sucesso",
                responseModel: "getItemChecagemResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca dos detalhes do item da checagem do SERASA",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "itemChecagem": {
                resumo: {
                    nome: "Nome Resumo de Negativo",
                    cpf: "33318984817",
                    nascimento: new Date(),
                    endereco: "RUA SÃO VICENTE, 855, apto. 82",
                    dataInfo: new Date(),
                    dataInfoTimestamp: "2016-07-04-12.37.25.540749",
                    usuario: "T668663",
                    classificacao: "B",
                    quantidade: 304,
                    situacao: "Ativo",
                    avaliacaoList: [
                        {
                            quantidade: 110,
                            codigo: "001",
                            descricao: "PENDENCIA DE PAGAMENTO",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 15.01,
                            maior: 2783433.50
                        },
                        {
                            quantidade: 19,
                            codigo: "002",
                            descricao: "PROTESTO",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 150.01,
                            maior: 27433.50
                        },
                        {
                            quantidade: 32,
                            codigo: "003",
                            descricao: "ACAO JUDICIAL",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 115.01,
                            maior: 83433.50
                        },
                        {
                            quantidade: 32,
                            codigo: "004",
                            descricao: "PARTICIPACAO EM FALENCIA",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 115.01,
                            maior: 83433.50
                        },
                        {
                            quantidade: 32,
                            codigo: "005",
                            descricao: "DIVIDA VENCIDA",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 115.01,
                            maior: 83433.50
                        },
                        {
                            quantidade: 32,
                            codigo: "006",
                            descricao: "CHEQUE SEM FUNDO",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 115.01,
                            maior: 83433.50
                        }
                    ]
                }
            }
        });
    }
};
