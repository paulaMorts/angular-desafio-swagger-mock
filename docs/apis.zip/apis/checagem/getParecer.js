var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o parecer da proposta.",
        path: "/parecer/get/{idProposta}",
        method: "GET",
        summary: "Retorna o parecer da proposta.",
        notes: "Recebe como parâmetro o ID da proposta e retorna o parecer dela.",
        type: "getParecerResponse",
        nickname: "getParecer",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Parecer retornado com sucesso",
                responseModel: "getParecerResponse"
            },
            {
                code: "500",
                reason: "Erro ao obter o parecer da proposta",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "parecer": {
                "parecerList": [
                    {
                        "cdPerfilUsuario": "ADSC",
                        "cdUsuario": "X056159",
                        "nmUsuario": "Usuario teste",
                        "dtParecer": new Date(),
                        "dsParecer1": "TESTE DE PARECER 1",
                        "dsParecer2": "TESTE DE PARECER 2",
                        "dsParecer3": "TESTE DE PARECER 3",
                        "dsParecer4": "TESTE DE PARECER 4",
                        "dsParecer5": "TESTE DE PARECER 5",
                        "dsParecer6": "TESTE DE PARECER 6",
                        "dsParecer7": "TESTE DE PARECER 7",
                        "dsParecer8": "TESTE DE PARECER 8",
                        "dsParecer9": "TESTE DE PARECER 9",
                        "dsParecer10": "TESTE DE PARECER 10",
                        "dsParecer11": "TESTE DE PARECER 11",
                        "dsParecer12": "TESTE DE PARECER 12"
                    }
                ]
            }
        });
    }
};
