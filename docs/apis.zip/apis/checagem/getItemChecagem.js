var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna os detalhes de um item da checagem para a proposta.",
        path: "/checagem/get/{idProposta}/{itemChecagem}/{cdTipoParte}",
        method: "GET",
        summary: "Retorna os detalhes de um item da checagem para a proposta.",
        notes: "Recebe como parâmetro o ID da proposta e o item de checagem e retorna os detalhes do seu item.",
        type: "getItemChecagemResponse",
        nickname: "getItemChecagem",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number"),
                     paramTypes.path("itemChecagem", "Identificador do item da checagem", "string"),
					 paramTypes.path("cdTipoParte", "Tipo da parte sendo consultada", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Detalhes do item de checagem retornado com sucesso",
                responseModel: "getItemChecagemResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca dos detalhes do item da checagem",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "itemChecagem": req.params.itemChecagem.toUpperCase() === "SPC" || req.params.itemChecagem.toUpperCase() === "SER" ? {
                resumo: {
                    nome: req.params.itemChecagem.toUpperCase() === "SPC" ?  "Nome Resumo de Negativo" : "Teste do Serasa",
                    cpf: "33318984817",
                    nascimento: new Date(),
                    endereco: "RUA SÃO VICENTE, 855, apto. 82",
                    dataInfo: new Date(),
                    usuario: "T668663",
                    classificacao: "B",
                    quantidade: 304,
                    situacao: "Ativo",
                    avaliacaoList: [
                        {
                            quantidade: 110,
                            descricao: "Pendência de Pagamento 1",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 15.01,
                            maior: 2783433.50
                        },
                        {
                            quantidade: 19,
                            descricao: "Pendência de Pagamento 2",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 150.01,
                            maior: 27433.50
                        },
                        {
                            quantidade: 32,
                            descricao: "Pendência de Pagamento 3",
                            desde: new Date(),
                            ate: new Date(),
                            menor: 115.01,
                            maior: 83433.50
                        }
                    ]
                }
            } : {
                comentarios: [
                    {
                        codigo: "000",
                        dataHora: new Date(),
                        descricao: "meu comentário",
                        usuario: "01234567",
                        comentario: "Mussum Ipsum, cacilds vidis litro abertis. Quem manda na minha terra sou Euzis! Si num tem leite então bota uma pinga aí cumpadi! Delegadis gente finis, bibendum egestas augue arcu ut est. Todo mundo vê os porris que eu tomo, mas ninguém vê os tombis que eu levo!"
                    },
                    {
                        codigo: "000",
                        dataHora: new Date(),
                        descricao: "meu comentário",
                        usuario: "01234567",
                        comentario: "Mussum Ipsum, cacilds vidis litro abertis. Quem manda na minha terra sou Euzis! Si num tem leite então bota uma pinga aí cumpadi! Delegadis gente finis, bibendum egestas augue arcu ut est. Todo mundo vê os porris que eu tomo, mas ninguém vê os tombis que eu levo!"
                    }
                ]
            }
        });
    }
};
