var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna a checagem para a proposta.",
        path: "/checagem/get/{idProposta}",
        method: "GET",
        summary: "Retorna a checagem para a proposta.",
        notes: "Recebe como parâmetro o ID da proposta e retorna a checagem para o proponente e possíveis avalistas.",
        type: "getChecagemResponse",
        nickname: "getChecagem",
        produces: ["application/json"],
        parameters: [paramTypes.path("idProposta", "Identificador da Proposta", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Checagem retornado com sucesso",
                responseModel: "getChecagemResponse"
            },
            {
                code: "500",
                reason: "Erro ao realizar a busca da checagem",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        res.status(200).send({
            "checagem": {
                vlMercado: 5000.00,
                dsAvaliacaoRisco: "Alta",
                proponente: {
                    dsNome: "Nome do Proponente",
                    dsTipo: "Cliente",
                    nrCpfCnpj: "33318984817",
                    nrGrauSeveridade: 5,
                    dsExperiencia: "Ótima",
                    avaliacao: {
                        lr1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        lt2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        lt1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        lr2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        cr: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        spc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        rf1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        rf2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        bc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                        ser: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N"
                    }
                },
				avaliacaoAvalistaList: [{
                            lr1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lt2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lt1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lr2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            cr: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            spc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            rf1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            rf2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            bc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            ser: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N"
                        },
						{
                            lr1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lt2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lt1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            lr2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            cr: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            spc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            rf1: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            rf2: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            bc: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N",
                            ser: Math.random().toFixed(0) % 2 == 0 ?  "S" : "N"
                        }
				],
                avalistaList: [
                    {
                        dsNome: "Nome do Avalista 1",
                        dsTipo: "Avalista 1",
                        nrCpfCnpj: "33318984817",
                        nrGrauSeveridade: 5,
                        dsExperiencia: "Ótima"
                    },
                    {
                        dsNome: "Nome do Avalista 2",
                        dsTipo: "Avalista 2",
                        nrCpfCnpj: "33318984817",
                        nrGrauSeveridade: 5,
                        dsExperiencia: "Ótima"
                    }
                ]
            }
        });
    }
};