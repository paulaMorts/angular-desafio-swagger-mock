var paramTypes = require("swagger-node-express").paramTypes;
var _ = require('lodash');

module.exports = {
    spec: {
        description: "Retorna a lista de agentes certificados para uma TAB.",
        path: "/agenteCertificado/getLista/{nrPagina}",
        method: "GET",
        summary: "Retorna a lista de agentes certificados para uma TAB.",
        notes: "Retorna a lista de agentes certificados para uma TAB..",
        type: "getListaAgenteCertificadoResponse",
        nickname: "getListaAgenteCertificado",
        produces: ["application/json"],
        parameters: [
            paramTypes.path("nrPagina", "Número da página requisitada.", "number"),
            paramTypes.query("dsOrdenacao", "Opções de ordenação (nrCpfCnpj, nmAgente, dtVencimento).", "string"),
            paramTypes.query("dsDirecaoOrdenacao", "Opções para direção da ordenação (asc, desc).", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Agentes não encontrados para a TAB",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        var data = [
            {
                "idAgCertificado": 1,
                "nmAgente": "Edson Arantes do Nascimento",
                "nrCpf": "00000000000",
                "dtValidadeCert": "2016-05-16T16:35:19-03:00"
            },
            {
                "idAgCertificado": 2,
                "nmAgente": "Neymar da Silva Santos Junior",
                "nrCpf": "11111111111",
                "dtValidadeCert": "2016-05-16T16:35:19-03:00"
            },
            {
                "idAgCertificado": 3,
                "nmAgente": "Edjan Souza Santos",
                "nrCpf": "22222222222",
                "dtValidadeCert": "2016-05-14T12:35:19-03:00"
            },
            {
                "idAgCertificado": 4,
                "nmAgente": "Ricardo Pastor Oliveira",
                "nrCpf": "33333333333",
                "dtValidadeCert": "2016-04-18T16:55:19-03:00"
            },
            {
                "idAgCertificado": 5,
                "nmAgente": "Giovanni Messias",
                "nrCpf": "77777777777",
                "dtValidadeCert": "2016-05-14T12:35:19-03:00"
            },
            {
                "idAgCertificado": 6,
                "nmAgente": "Monstronildo Gigante Hulk",
                "nrCpf": "99999999999",
                "dtValidadeCert": "2015-04-18T16:55:19-03:00"
            },
            {
                "idAgCertificado": 7,
                "nmAgente": "Hulk Vem Monstro BJJ",
                "nrCpf": "55555555555",
                "dtValidadeCert": "2015-04-18T16:55:19-03:00"
            }
        ];
        if(req.query.dsOrdenacao)
            data = _.orderBy(data, [req.query.dsOrdenacao], [req.query.dsDirecaoOrdenacao]);

        var start = (req.params.nrPagina*6)-6;
        data = data.slice(start, start+6);

        //TODO: Fazer o mock
        res.status(200).send({
            "agentesCertificados": data,
            "paginacao": {
                "nrPagina": req.params.nrPagina,
                "qtItens": 6,
                "qtResultados": 7,
                "qtPaginas": 2
            }
        })
    }
};
