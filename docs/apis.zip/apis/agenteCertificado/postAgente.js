var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Vincula um agente certificado a uma TAB",
        path: "/agenteCertificado/postAgente/",
        method: "POST",
        summary: "Vincula um agente certificado a uma TAB",
        notes: "Vincula um agente certificado a uma TAB",
        type: "postAgenteResponse",
        nickname: "postAgente",
        produces: ["application/json"],
        parameters: [paramTypes.body("postAgenteRequest", "Grupo com os dados do Agente Certificado para inserção na base", "postAgenteRequest")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Agentes não encontrados para a TAB",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        });
    }
};