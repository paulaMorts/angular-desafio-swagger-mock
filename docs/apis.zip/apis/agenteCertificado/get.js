var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Retorna o agente certificado.",
        path: "/agenteCertificado/get/{nrCpf}",
        method: "GET",
        summary: "Retorna o agente certificado.",
        notes: "Retorna o agente certificado.",
        type: "getAgenteCertificadoResponse",
        nickname: "getAgenteCertificado",
        produces: ["application/json"],
        parameters: [paramTypes.path("nrCpf", "Número do CPF do agente certificado a ser encontrado.", "string")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Agentes não encontrados para a TAB",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
			"agenteCertificado" : {
				"dsAbrangencia": "",
				"dsCertPrincipal": "",
				"cdAgente": 0,
				"cdIntermediario": 0,
				"cdSituacao": "",
				"fgDefaultInterm": false,
				"dtFimVinculo": "",
				"dtRelacionamento": "",
				"dtValidadeCert": "2016-05-18T17:20:39-03:00",
				"dhRelacionamento": "",
				"nmAgente": "Edson Arantes do Nascimento",
				"nrCertificado": "",
				"nrCpf": "34794296886",
				"nrPrzDiasVenc": 0,
				"nrQteFimValidade": 0,
				"nrQteFimVinculo": 0
			}
        });
    }
};