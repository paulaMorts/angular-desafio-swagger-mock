var paramTypes = require("swagger-node-express").paramTypes;

module.exports = {
    spec: {
        description: "Desvincula o agente certificado da TAB.",
        path: "/agenteCertificado/delete/{idAgCertificado}",
        method: "POST",
        summary: "Desvincula o agente certificado da TAB.",
        notes: "Desvincula o agente certificado da TAB.",
        type: "deleteAgenteCertificadoResponse",
        nickname: "deleteAgenteCertificado",
        produces: ["application/json"],
        parameters: [paramTypes.path("idAgCertificado", "Identificador do Agente Certificado", "number")],
        errorResponses: [
            {
                code: "200",
                reason: "Retorno OK"
            },
            {
                code: "400",
                reason: "Parametros invalidos",
                responseModel: "errorResponse"
            },
            {
                code: "404",
                reason: "Agentes não encontrados para a TAB",
                responseModel: "errorResponse"
            },
            {
                code: "500",
                reason: "Erro do servidor",
                responseModel: "errorResponse"
            }
        ]
    },
    action: function (req, res) {
        //TODO: Fazer o mock
        res.status(200).send({
            "retorno" : {
                "dsMensagem": "OK"
            }
        });
    }
};